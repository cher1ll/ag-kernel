#!/usr/bin/env python3
"""
Final speed comparison: Original vs Optimized vs Ultra-Fast Batch
"""
import time
import sys
from pathlib import Path

# Add paths
sys.path.append(str(Path(__file__).parent / "strategies"))
sys.path.append(str(Path(__file__).parent / "python"))

def compare_all_approaches():
    """Compare all three approaches on small dataset."""
    
    from strategies.framework import WalkForwardAnalyzer
    from strategies.H01_Bollinger_Reversion import bollinger_reversion_logic
    from strategies.optimized_bollinger import bollinger_reversion_logic_optimized
    from strategies.ultra_fast_bollinger import bollinger_reversion_batch_logic
    
    data_path = "examples/data/btcusdt_aggtrades_sample.csv"
    
    if not Path(data_path).exists():
        print(f"Data file not found: {data_path}")
        return
    
    # Small parameter grid for fair comparison
    param_grid = {
        'bb_period': [15, 20],
        'bb_std': [1.5, 2.0],
        'risk_percent': [0.01],
        'reward_ratio': [1.5],
        'position_size': [0.05]
    }
    
    print("=" * 60)
    print("SPEED COMPARISON - ALL APPROACHES")
    print("=" * 60)
    print(f"Data: {data_path}")
    print(f"Parameters: {len(param_grid['bb_period']) * len(param_grid['bb_std']) * len(param_grid['risk_percent']) * len(param_grid['reward_ratio']) * len(param_grid['position_size'])} combinations")
    
    results = {}
    
    # Test each approach
    approaches = [
        ("Original (tick-by-tick)", bollinger_reversion_logic),
        ("Optimized (pandas)", bollinger_reversion_logic_optimized), 
        ("Ultra-Fast (batch)", bollinger_reversion_batch_logic)
    ]
    
    for name, strategy_func in approaches:
        print(f"\n{name}:")
        print("-" * 40)
        
        try:
            wfa = WalkForwardAnalyzer(
                data_path=data_path,
                is_days=5,
                oos_days=2,
                step_days=3
            )
            
            start_time = time.time()
            
            wfa_results = wfa.run_full_wfa(
                strategy_logic=strategy_func,
                param_grid=param_grid,
                bucket_ms=5000
            )
            
            elapsed = time.time() - start_time
            
            summary = wfa_results.get('summary', {})
            
            results[name] = {
                'time': elapsed,
                'trades': summary.get('total_oos_trades', 0),
                'return': summary.get('avg_oos_return', 0),
                'pf': summary.get('avg_oos_pf', 0)
            }
            
            print(f"  Time: {elapsed:.2f}s")
            print(f"  OOS Trades: {results[name]['trades']}")
            print(f"  OOS Return: {results[name]['return']:.2f}%")
            print(f"  OOS PF: {results[name]['pf']:.2f}")
            
        except Exception as e:
            print(f"  ❌ Failed: {e}")
            results[name] = {'time': float('inf'), 'trades': 0, 'return': 0, 'pf': 0}
    
    # Summary
    print("\n" + "=" * 60)
    print("PERFORMANCE SUMMARY")
    print("=" * 60)
    
    fastest_time = min(r['time'] for r in results.values() if r['time'] != float('inf'))
    
    for name, result in results.items():
        if result['time'] != float('inf'):
            speedup = fastest_time / result['time'] if result['time'] > 0 else 0
            print(f"{name:25} | {result['time']:6.2f}s | {speedup:4.1f}x speed")
        else:
            print(f"{name:25} | FAILED")
    
    print("\n🚀 Ultra-Fast Batch processing is the winner!")

if __name__ == "__main__":
    compare_all_approaches()
