#!/usr/bin/env python3
"""
Test ultra-fast Bollinger strategy with batch processing.
"""
import time
import sys
from pathlib import Path

# Add paths
sys.path.append(str(Path(__file__).parent / "strategies"))
sys.path.append(str(Path(__file__).parent / "python"))

from strategies.framework import WalkForwardAnalyzer
from strategies.ultra_fast_bollinger import bollinger_reversion_batch_logic

def main():
    print("=" * 60)
    print("ULTRA-FAST WFA TEST - BATCH BOLLINGER REVERSION")
    print("=" * 60)
    
    # Configuration
    data_path = "examples/data/btcusdt_vision_30d.csv"
    
    # Small parameter grid for testing
    param_grid = {
        'bb_period': [15, 20],
        'bb_std': [1.5, 2.0],
        'risk_percent': [0.01],
        'reward_ratio': [1.5, 2.0],
        'position_size': [0.05]
    }
    
    print(f"\nStrategy: Ultra_Fast_Bollinger_Batch")
    print(f"Data: {data_path}")
    print(f"Parameters to optimize: {param_grid}")
    
    # Initialize WFA
    wfa = WalkForwardAnalyzer(
        data_path=data_path,
        is_days=15,
        oos_days=7,
        step_days=10
    )
    
    # Prepare windows
    wfa.prepare_windows()
    print(f"Created {len(wfa.windows)} walk-forward windows")
    
    # Measure total time
    start_time = time.time()
    
    # Run WFA with batch processing
    results = wfa.run_full_wfa(
        strategy_logic=bollinger_reversion_batch_logic,
        param_grid=param_grid,
        bucket_ms=5000
    )
    
    total_time = time.time() - start_time
    
    # Save results
    wfa.save_results(results, 'outputs/wfa_test_ultra_fast.json')
    
    print(f"\n🚀 ULTRA-FAST TEST COMPLETED! 🚀")
    print(f"Total time: {total_time:.2f}s")
    print(f"Results saved to: outputs/wfa_test_ultra_fast.json")
    
    # Show summary
    summary = results.get('summary', {})
    print(f"\nQuick Results:")
    print(f"  Avg OOS Return: {summary.get('avg_oos_return', 0):.2f}%")
    print(f"  Avg OOS PF: {summary.get('avg_oos_pf', 0):.2f}")
    print(f"  Total OOS Trades: {summary.get('total_oos_trades', 0)}")

if __name__ == "__main__":
    main()
