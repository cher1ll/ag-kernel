"""
Cache management utilities for Parquet files.
"""

import os
import time
from pathlib import Path
from typing import List, Optional


def clean_old_cache(
    data_dir: Path,
    max_age_hours: float = 24.0,
    dry_run: bool = False,
    verbose: bool = True
) -> List[Path]:
    """
    Clean old Parquet cache files.
    
    Args:
        data_dir: Directory to scan for cache files
        max_age_hours: Remove files older than this (hours)
        dry_run: If True, only show what would be deleted
        verbose: Print progress
        
    Returns:
        List of files that were (or would be) deleted
    """
    if not data_dir.exists():
        return []
    
    cutoff_time = time.time() - (max_age_hours * 3600)
    deleted_files = []
    
    # Find cache files (pattern: *_b*ms_t*.parquet)
    cache_files = list(data_dir.glob("*_b*ms_t*.parquet"))
    
    for cache_file in cache_files:
        if cache_file.stat().st_mtime < cutoff_time:
            deleted_files.append(cache_file)
            
            if dry_run:
                if verbose:
                    print(f"Would delete: {cache_file.name}")
            else:
                try:
                    cache_file.unlink()
                    if verbose:
                        print(f"Deleted: {cache_file.name}")
                except OSError as e:
                    if verbose:
                        print(f"Failed to delete {cache_file.name}: {e}")
    
    if verbose and deleted_files:
        total_size = sum(f.stat().st_size for f in deleted_files if f.exists())
        print(f"{'Would free' if dry_run else 'Freed'} {total_size / 1024 / 1024:.1f} MB")
    
    return deleted_files


def list_cache_files(data_dir: Path, show_size: bool = True) -> None:
    """List all cache files in directory."""
    if not data_dir.exists():
        print(f"Directory not found: {data_dir}")
        return
    
    cache_files = list(data_dir.glob("*_b*ms_t*.parquet"))
    
    if not cache_files:
        print("No cache files found")
        return
    
    print(f"Found {len(cache_files)} cache files:")
    
    total_size = 0
    for cache_file in sorted(cache_files):
        size_mb = cache_file.stat().st_size / 1024 / 1024
        total_size += size_mb
        
        age_hours = (time.time() - cache_file.stat().st_mtime) / 3600
        
        if show_size:
            print(f"  {cache_file.name:<50} {size_mb:>6.1f} MB  {age_hours:>5.1f}h old")
        else:
            print(f"  {cache_file.name}")
    
    if show_size:
        print(f"Total cache size: {total_size:.1f} MB")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Manage Parquet cache files")
    parser.add_argument("command", choices=["list", "clean"], help="Command to run")
    parser.add_argument("--dir", type=Path, default="examples/data", help="Data directory")
    parser.add_argument("--max-age", type=float, default=24.0, help="Max age in hours")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be deleted")
    
    args = parser.parse_args()
    
    if args.command == "list":
        list_cache_files(args.dir)
    elif args.command == "clean":
        clean_old_cache(args.dir, args.max_age, args.dry_run)
