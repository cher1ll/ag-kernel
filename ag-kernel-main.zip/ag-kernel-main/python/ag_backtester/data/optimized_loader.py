"""
Optimized data loader with automatic format detection and batch processing.

Provides unified interface for loading financial data with maximum performance.
"""

import numpy as np
from pathlib import Path
from typing import Union, Optional, Tuple
import time

from .aggtrades import AggTradesFeed
from .tick_aggregator import aggregate_ticks_vectorized
from .converter import convert_to_parquet, load_dataset


class OptimizedDataLoader:
    """
    High-performance data loader with automatic Parquet conversion and batch processing.
    
    Features:
    - Automatic CSV → Parquet conversion with 70% size reduction
    - Sub-100ms loading for 1M+ ticks from Parquet
    - Vectorized tick aggregation using numpy
    - Memory-efficient chunked processing for large datasets
    """
    
    def __init__(
        self,
        data_path: Union[str, Path],
        tick_size: float = 1.0,
        auto_convert: bool = True,
        force_csv: bool = False,
        verbose: bool = True,
    ):
        """
        Initialize optimized data loader.
        
        Args:
            data_path: Path to data file (CSV or Parquet)
            tick_size: Price tick size for quantization
            auto_convert: Automatically convert CSV to Parquet
            force_csv: Force CSV loading (disable Parquet optimization)
            verbose: Print loading progress and performance stats
        """
        self.data_path = Path(data_path)
        self.tick_size = tick_size
        self.auto_convert = auto_convert
        self.force_csv = force_csv
        self.verbose = verbose
        
        if not self.data_path.exists():
            raise FileNotFoundError(f"Data file not found: {self.data_path}")
    
    def load_for_batch_processing(
        self,
        bucket_ms: Optional[int] = None,
    ) -> Tuple[dict[str, np.ndarray], dict]:
        """
        Load data optimized for batch processing with performance metrics.
        
        Args:
            bucket_ms: Optional time bucketing in milliseconds
            
        Returns:
            Tuple of (data_dict, metrics_dict)
            - data_dict: numpy arrays ready for engine.step_batch()
            - metrics_dict: loading performance statistics
        """
        start_time = time.time()
        
        # Store bucket_ms for cache key generation
        self.bucket_ms = bucket_ms or 0
        
        # Initialize metrics
        metrics = {
            'load_method': 'unknown',
            'conversion_time': 0.0,
            'load_time': 0.0,
            'aggregation_time': 0.0,
            'total_time': 0.0,
            'num_raw_ticks': 0,
            'num_final_ticks': 0,
            'file_size_mb': self.data_path.stat().st_size / (1024 * 1024),
        }
        
        # Load raw data
        data, load_metrics = self._load_raw_data()
        metrics.update(load_metrics)
        
        # Apply tick aggregation if requested
        if bucket_ms is not None:
            agg_start = time.time()
            data = self._aggregate_data(data, bucket_ms)
            metrics['aggregation_time'] = time.time() - agg_start
            metrics['num_final_ticks'] = len(data['timestamp'])
        else:
            metrics['num_final_ticks'] = metrics['num_raw_ticks']
        
        # Prepare for batch processing
        data = self._prepare_for_batch(data)
        
        metrics['total_time'] = time.time() - start_time
        
        if self.verbose:
            self._print_metrics(metrics)
            
        return data, metrics
    
    def _load_raw_data(self) -> Tuple[dict[str, np.ndarray], dict]:
        """Load raw data with optimal method."""
        # Create cache-friendly parquet name with parameters
        base_name = self.data_path.stem
        cache_suffix = f"_b{self.bucket_ms}ms_t{self.tick_size:.1f}".replace('.', 'p')
        parquet_path = self.data_path.parent / f"{base_name}{cache_suffix}.parquet"
        
        # Determine loading strategy
        if self.force_csv or self.data_path.suffix.lower() != '.csv':
            if self.data_path.suffix.lower() == '.parquet':
                return self._load_parquet(self.data_path)
            else:
                return self._load_csv_direct()
        
        # CSV input - check for Parquet optimization
        if parquet_path.exists() and not self.force_csv:
            # Use existing Parquet if newer than CSV
            if parquet_path.stat().st_mtime >= self.data_path.stat().st_mtime:
                if self.verbose:
                    print(f"Using cached Parquet: {parquet_path.name}")
                return self._load_parquet(parquet_path)
        
        # Convert CSV to Parquet if auto_convert enabled
        if self.auto_convert:
            # Clean old cache files occasionally (5% chance)
            if np.random.random() < 0.05:
                try:
                    from ..userland.cache_manager import clean_old_cache
                    clean_old_cache(self.data_path.parent, max_age_hours=24.0, verbose=False)
                except ImportError:
                    pass
            
            conv_start = time.time()
            try:
                if self.verbose:
                    print(f"Converting to cached Parquet: {parquet_path.name}")
                convert_to_parquet(self.data_path, parquet_path, compression='zstd')
                conv_time = time.time() - conv_start
                
                data, load_metrics = self._load_parquet(parquet_path)
                load_metrics['conversion_time'] = conv_time
                load_metrics['load_method'] = 'csv_converted_to_parquet'
                
                return data, load_metrics
            except Exception as e:
                if self.verbose:
                    print(f"Warning: Parquet conversion failed ({e}), using CSV")
        
        # Fallback to CSV
        return self._load_csv_direct()
    
    def _load_parquet(self, path: Path) -> Tuple[dict[str, np.ndarray], dict]:
        """Load data from Parquet file."""
        load_start = time.time()
        data = load_dataset(path)
        load_time = time.time() - load_start
        
        metrics = {
            'load_method': 'parquet',
            'load_time': load_time,
            'num_raw_ticks': len(data['timestamp']),
        }
        
        return data, metrics
    
    def _load_csv_direct(self) -> Tuple[dict[str, np.ndarray], dict]:
        """Load data directly from CSV."""
        load_start = time.time()
        
        feed = AggTradesFeed(
            self.data_path, 
            tick_size=self.tick_size,
            auto_convert=False,
            force_csv=True
        )
        data = feed.load_batch()
        
        load_time = time.time() - load_start
        
        metrics = {
            'load_method': 'csv_direct',
            'load_time': load_time,
            'num_raw_ticks': len(data['timestamp']),
        }
        
        return data, metrics
    
    def _aggregate_data(
        self, 
        data: dict[str, np.ndarray], 
        bucket_ms: int
    ) -> dict[str, np.ndarray]:
        """Apply vectorized tick aggregation."""
        agg_data = aggregate_ticks_vectorized(data, bucket_ms, self.tick_size)
        
        # Convert back to standard format
        return {
            'timestamp': agg_data['timestamp'],
            'price': agg_data['price_tick'] * self.tick_size,  # Convert back to price
            'qty': agg_data['qty'],
            'side': agg_data['side']
        }
    
    def _prepare_for_batch(self, data: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
        """Prepare data for engine.step_batch()."""
        # Convert prices to price_ticks for engine
        price_ticks = np.round(data['price'] / self.tick_size).astype(np.int64)
        
        return {
            'timestamp': data['timestamp'].astype(np.int64),
            'price_ticks': price_ticks,
            'qty': data['qty'].astype(np.float64),
            'side': data['side'].astype(np.uint8)
        }
    
    def _print_metrics(self, metrics: dict):
        """Print performance metrics."""
        print(f"\n📊 Data Loading Performance:")
        print(f"  Method: {metrics['load_method']}")
        print(f"  File size: {metrics['file_size_mb']:.2f} MB")
        print(f"  Raw ticks: {metrics['num_raw_ticks']:,}")
        print(f"  Final ticks: {metrics['num_final_ticks']:,}")
        
        if metrics['conversion_time'] > 0:
            print(f"  Conversion time: {metrics['conversion_time']:.3f}s")
        
        print(f"  Load time: {metrics['load_time']:.3f}s")
        
        if metrics['aggregation_time'] > 0:
            print(f"  Aggregation time: {metrics['aggregation_time']:.3f}s")
        
        print(f"  Total time: {metrics['total_time']:.3f}s")
        
        # Calculate throughput
        if metrics['total_time'] > 0:
            throughput = metrics['num_final_ticks'] / metrics['total_time']
            print(f"  Throughput: {throughput:,.0f} ticks/s")


def load_data_optimized(
    data_path: Union[str, Path],
    tick_size: float = 1.0,
    bucket_ms: Optional[int] = None,
    auto_convert: bool = True,
    force_csv: bool = False,
    verbose: bool = True,
) -> Tuple[dict[str, np.ndarray], dict]:
    """
    Convenience function for optimized data loading.
    
    Args:
        data_path: Path to data file
        tick_size: Price tick size
        bucket_ms: Optional time bucketing
        auto_convert: Auto-convert CSV to Parquet
        force_csv: Force CSV loading
        verbose: Print performance stats
        
    Returns:
        Tuple of (batch_data, metrics)
    """
    loader = OptimizedDataLoader(
        data_path=data_path,
        tick_size=tick_size,
        auto_convert=auto_convert,
        force_csv=force_csv,
        verbose=verbose,
    )
    
    return loader.load_for_batch_processing(bucket_ms=bucket_ms)
