"""
Tick aggregation utilities with vectorized operations.

Aggregates raw ticks into time-bucketed, price-level volumes.
"""

import numpy as np
from typing import Iterator, List, Union
from collections import defaultdict

from .feeds import Tick


def aggregate_ticks_vectorized(
    data: dict[str, np.ndarray],
    bucket_ms: int,
    tick_size: float,
) -> dict[str, np.ndarray]:
    """
    Vectorized tick aggregation using numpy for high performance.
    
    Args:
        data: Dictionary with numpy arrays (timestamp, price, qty, side)
        bucket_ms: Time bucket size in milliseconds
        tick_size: Price tick size for quantization
        
    Returns:
        Dictionary with aggregated numpy arrays
    """
    timestamps = data['timestamp']
    prices = data['price'] 
    qtys = data['qty']
    sides = data['side']
    
    # Vectorized bucket calculation
    bucket_timestamps = (timestamps // bucket_ms) * bucket_ms
    
    # Vectorized price quantization
    price_ticks = np.round(prices / tick_size).astype(np.int64)
    
    # Create unique keys for grouping
    # Combine bucket_ts, price_tick, and side into single array for grouping
    max_price_tick = np.max(price_ticks) + 1
    max_side = 2  # 0=BUY, 1=SELL
    
    # Create composite keys: bucket_ts * scale + price_tick * max_side + side
    scale = max_price_tick * max_side
    composite_keys = bucket_timestamps * scale + price_ticks * max_side + sides
    
    # Get unique keys and their indices
    unique_keys, inverse_indices = np.unique(composite_keys, return_inverse=True)
    
    # Aggregate quantities using bincount
    aggregated_qtys = np.bincount(inverse_indices, weights=qtys)
    
    # Decode composite keys back to components
    result_bucket_timestamps = unique_keys // scale
    remainder = unique_keys % scale
    result_price_ticks = remainder // max_side
    result_sides = remainder % max_side
    
    return {
        'timestamp': result_bucket_timestamps,
        'price_tick': result_price_ticks,
        'qty': aggregated_qtys,
        'side': result_sides
    }


def aggregate_ticks(
    trades: Union[Iterator[Tick], dict[str, np.ndarray]],
    bucket_ms: int,
    tick_size: float,
) -> List[Tick]:
    """
    Aggregate ticks into time-bucketed volumes per (time, price_level, side).
    
    Supports both iterator input (legacy) and numpy array input (optimized).

    Args:
        trades: Iterator of Tick objects OR dict with numpy arrays
        bucket_ms: Time bucket size in milliseconds
        tick_size: Price tick size for quantization

    Returns:
        List of aggregated Tick objects, sorted by (timestamp, price_tick_i64, side)
    """
    # Check if input is numpy arrays (optimized path)
    if isinstance(trades, dict) and 'timestamp' in trades:
        return _aggregate_ticks_vectorized_to_list(trades, bucket_ms, tick_size)
    else:
        return _aggregate_ticks_legacy(trades, bucket_ms, tick_size)


def _aggregate_ticks_vectorized_to_list(
    data: dict[str, np.ndarray],
    bucket_ms: int, 
    tick_size: float,
) -> List[Tick]:
    """Convert vectorized aggregation result to Tick list."""
    agg_data = aggregate_ticks_vectorized(data, bucket_ms, tick_size)
    
    result = []
    for i in range(len(agg_data['timestamp'])):
        side_str = 'SELL' if agg_data['side'][i] == 1 else 'BUY'
        
        result.append(Tick(
            ts_ms=int(agg_data['timestamp'][i]),
            price_tick_i64=int(agg_data['price_tick'][i]),
            qty=float(agg_data['qty'][i]),
            side=side_str
        ))
    
    # Sort by timestamp, price_tick, side
    result.sort(key=lambda t: (t.ts_ms, t.price_tick_i64, t.side))
    return result


def _aggregate_ticks_legacy(
    trades: Iterator[Tick],
    bucket_ms: int,
    tick_size: float,
) -> List[Tick]:
    """
    Legacy tick aggregation using iterator input.
    
    Algorithm:
        1. Bucket timestamp: bucket_ts = (ts_ms // bucket_ms) * bucket_ms
        2. Quantize price: tick_i64 = round(price / tick_size)
        3. Map side: 'SELL' if is_buyer_maker else 'BUY'
        4. Accumulate qty for each unique (bucket_ts, tick_i64, side) tuple
    """
    # Accumulator: {(bucket_ts, tick_i64, side): total_qty}
    buckets = defaultdict(float)

    for tick in trades:
        # Calculate bucket timestamp
        bucket_ts = (tick.ts_ms // bucket_ms) * bucket_ms

        # Re-quantize price if tick_size changed
        price_reconstructed = tick.price_tick_i64 * tick_size
        tick_i64 = round(price_reconstructed / tick_size)

        # Create bucket key
        key = (bucket_ts, tick_i64, tick.side)

        # Accumulate quantity
        buckets[key] += tick.qty

    # Convert to list of Tick objects
    result = []
    for (bucket_ts, tick_i64, side), total_qty in buckets.items():
        result.append(Tick(
            ts_ms=bucket_ts,
            price_tick_i64=tick_i64,
            qty=total_qty,
            side=side
        ))

    # Sort by timestamp, then price level, then side
    result.sort(key=lambda t: (t.ts_ms, t.price_tick_i64, t.side))

    return result
