"""
AggTrades data feed implementation.

Parses Binance-style aggregate trades CSV files with Parquet optimization.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Iterator, Union, Optional

from .feeds import BaseFeed, Tick
from .converter import convert_to_parquet, load_dataset


class AggTradesFeed(BaseFeed):
    """
    Data feed for aggregate trades from CSV files.

    Expected CSV columns:
        - timestamp: Unix timestamp in milliseconds
        - price: Trade price (float)
        - qty: Trade quantity (float)
        - is_buyer_maker: Boolean indicating if buyer was maker (1/0 or True/False)

    The feed converts aggTrades into raw ticks without aggregation.
    For tick aggregation, use tick_aggregator.aggregate_ticks().
    """

    def __init__(
        self,
        data_path: Union[str, Path],
        tick_size: float = 1.0,
        auto_convert: bool = True,
        force_csv: bool = False,
    ):
        """
        Initialize AggTradesFeed with Parquet optimization.

        Args:
            data_path: Path to CSV or Parquet file with aggTrades data
            tick_size: Price tick size for quantization
            auto_convert: Automatically convert CSV to Parquet for faster loading
            force_csv: Force CSV loading (skip Parquet optimization)
        """
        self.data_path = Path(data_path)
        self.tick_size = tick_size
        self.auto_convert = auto_convert
        self.force_csv = force_csv

        if not self.data_path.exists():
            raise FileNotFoundError(f"Data file not found: {self.data_path}")

        # Determine optimal loading strategy
        self._setup_loading_strategy()

    def _setup_loading_strategy(self):
        """Determine optimal loading strategy (Parquet vs CSV)."""
        self.use_parquet = False
        self.parquet_path = None
        
        if self.force_csv:
            return
            
        # If input is already Parquet, use it directly
        if self.data_path.suffix.lower() == '.parquet':
            self.use_parquet = True
            self.parquet_path = self.data_path
            return
            
        # If input is CSV, check for Parquet version
        if self.data_path.suffix.lower() == '.csv':
            parquet_path = self.data_path.with_suffix('.parquet')
            
            if parquet_path.exists():
                # Use existing Parquet if newer than CSV
                if parquet_path.stat().st_mtime >= self.data_path.stat().st_mtime:
                    self.use_parquet = True
                    self.parquet_path = parquet_path
                    return
                    
            # Auto-convert CSV to Parquet if enabled
            if self.auto_convert:
                try:
                    convert_to_parquet(self.data_path, parquet_path, compression='zstd')
                    self.use_parquet = True
                    self.parquet_path = parquet_path
                except Exception as e:
                    print(f"Warning: Parquet conversion failed ({e}), using CSV")

    def load_batch(self) -> dict[str, np.ndarray]:
        """
        Load all data as numpy arrays for batch processing.
        
        Returns:
            Dictionary with numpy arrays:
            {
                'timestamp': np.array(dtype=int64),
                'price': np.array(dtype=float64), 
                'qty': np.array(dtype=float64),
                'side': np.array(dtype=uint8)  # 0=BUY, 1=SELL
            }
        """
        if self.use_parquet:
            return load_dataset(self.parquet_path)
        else:
            return self._load_csv_batch()
            
    def _load_csv_batch(self) -> dict[str, np.ndarray]:
        """Load CSV data as numpy arrays."""
        df = pd.read_csv(self.data_path)
        
        # Validate columns
        required_cols = {'timestamp', 'price', 'qty', 'is_buyer_maker'}
        missing_cols = required_cols - set(df.columns)
        if missing_cols:
            raise ValueError(f"Missing columns: {missing_cols}")
            
        # Convert to numpy arrays
        timestamps = df['timestamp'].to_numpy().astype(np.int64)
        prices = df['price'].to_numpy().astype(np.float64)
        qtys = df['qty'].to_numpy().astype(np.float64)
        
        # Convert is_buyer_maker to side (0=BUY, 1=SELL)
        sides = df['is_buyer_maker'].astype(bool).astype(np.uint8)
        
        return {
            'timestamp': timestamps,
            'price': prices,
            'qty': qtys,
            'side': sides
        }

    def iter_ticks(self) -> Iterator[Tick]:
        """
        Parse data and yield Tick objects.
        
        For large datasets, consider using load_batch() for better performance.
        """
        if self.use_parquet:
            yield from self._iter_ticks_parquet()
        else:
            yield from self._iter_ticks_csv()
            
    def _iter_ticks_parquet(self) -> Iterator[Tick]:
        """Iterate ticks from Parquet data."""
        data = load_dataset(self.parquet_path)
        
        for i in range(len(data['timestamp'])):
            ts_ms = int(data['timestamp'][i])
            price = float(data['price'][i])
            qty = float(data['qty'][i])
            side_int = int(data['side'][i])
            
            # Quantize price
            price_tick_i64 = round(price / self.tick_size)
            
            # Convert side: 0=BUY, 1=SELL
            side = 'SELL' if side_int == 1 else 'BUY'
            
            yield Tick(
                ts_ms=ts_ms,
                price_tick_i64=price_tick_i64,
                qty=qty,
                side=side
            )
            
    def _iter_ticks_csv(self) -> Iterator[Tick]:
        """Parse CSV and yield Tick objects with memory-efficient chunked reading."""
        chunk_size = 100_000

        # Validate columns
        first_chunk = pd.read_csv(self.data_path, nrows=1)
        required_cols = ['timestamp', 'price', 'qty', 'is_buyer_maker']
        missing_cols = set(required_cols) - set(first_chunk.columns)
        if missing_cols:
            raise ValueError(f"Missing columns: {missing_cols}")

        # Process in chunks
        for chunk_df in pd.read_csv(self.data_path, chunksize=chunk_size):
            chunk_df = chunk_df.sort_values('timestamp').reset_index(drop=True)

            for row in chunk_df.itertuples(index=False):
                ts_ms = int(row.timestamp)
                price = float(row.price)
                qty = float(row.qty)
                is_buyer_maker = bool(row.is_buyer_maker)

                price_tick_i64 = round(price / self.tick_size)
                side = 'SELL' if is_buyer_maker else 'BUY'

                yield Tick(
                    ts_ms=ts_ms,
                    price_tick_i64=price_tick_i64,
                    qty=qty,
                    side=side
                )

    def load(self) -> list:
        """
        Load all ticks into a list.

        Returns:
            List of Tick objects
        """
        return list(self.iter_ticks())
