#!/usr/bin/env python3
"""
Quick cache management script.
"""

import os
import time
from pathlib import Path


def list_cache_files(data_dir: Path) -> int:
    """List cache files and return count."""
    cache_files = list(data_dir.glob("*_b*ms_t*.parquet"))
    
    if not cache_files:
        return 0
    
    total_size = 0
    for cache_file in sorted(cache_files):
        size_mb = cache_file.stat().st_size / 1024 / 1024
        total_size += size_mb
        
        age_hours = (time.time() - cache_file.stat().st_mtime) / 3600
        print(f"  {cache_file.name:<50} {size_mb:>6.1f} MB  {age_hours:>5.1f}h old")
    
    print(f"  Total: {total_size:.1f} MB")
    return len(cache_files)


def clean_old_cache(data_dir: Path, max_age_hours: float = 24.0) -> int:
    """Clean old cache files."""
    cutoff_time = time.time() - (max_age_hours * 3600)
    cache_files = list(data_dir.glob("*_b*ms_t*.parquet"))
    
    deleted_count = 0
    freed_size = 0
    
    for cache_file in cache_files:
        if cache_file.stat().st_mtime < cutoff_time:
            size_mb = cache_file.stat().st_size / 1024 / 1024
            try:
                cache_file.unlink()
                print(f"  Deleted: {cache_file.name} ({size_mb:.1f} MB)")
                deleted_count += 1
                freed_size += size_mb
            except OSError as e:
                print(f"  Failed to delete {cache_file.name}: {e}")
    
    if deleted_count > 0:
        print(f"  Freed {freed_size:.1f} MB")
    
    return deleted_count


def main():
    data_dirs = [
        Path("examples/data"),
        Path("outputs"),
        Path("."),
    ]
    
    print("=== Parquet Cache Status ===")
    
    total_files = 0
    for data_dir in data_dirs:
        if data_dir.exists():
            cache_files = list(data_dir.glob("*_b*ms_t*.parquet"))
            if cache_files:
                print(f"\n{data_dir}:")
                count = list_cache_files(data_dir)
                total_files += count
    
    if total_files == 0:
        print("No cache files found")
    else:
        print(f"\nTotal: {total_files} cache files")
        
        # Offer to clean old files
        try:
            response = input("\nClean files older than 24h? [y/N]: ").strip().lower()
            if response == 'y':
                print("\nCleaning old cache files...")
                total_deleted = 0
                for data_dir in data_dirs:
                    if data_dir.exists():
                        deleted = clean_old_cache(data_dir, max_age_hours=24.0)
                        total_deleted += deleted
                
                if total_deleted == 0:
                    print("No old files to clean")
                else:
                    print(f"Cleaned {total_deleted} files total")
        except KeyboardInterrupt:
            print("\nCancelled")


if __name__ == "__main__":
    main()
