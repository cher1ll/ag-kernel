#!/usr/bin/env python3
"""Download aggTrades from Binance API"""
import requests
import pandas as pd
from datetime import datetime
import sys


def download_binance_aggtrades(symbol='BTCUSDT', start_time=None, end_time=None, limit=1000):
    """
    Download aggTrades from Binance API

    Args:
        symbol: Trading pair (e.g., 'BTCUSDT')
        start_time: Start timestamp in milliseconds
        end_time: End timestamp in milliseconds
        limit: Max records per request (max 1000)

    Returns:
        pandas.DataFrame with columns: timestamp, price, qty, is_buyer_maker
    """

    url = "https://api.binance.com/api/v3/aggTrades"
    all_trades = []

    current_time = start_time

    while current_time < end_time:
        params = {
            'symbol': symbol,
            'startTime': current_time,
            'limit': limit
        }

        print(f"Fetching from {datetime.fromtimestamp(current_time/1000)}...")
        response = requests.get(url, params=params)

        if response.status_code != 200:
            print(f"Error: {response.status_code} - {response.text}")
            break

        trades = response.json()

        if not trades:
            print("No more trades available")
            break

        all_trades.extend(trades)
        current_time = trades[-1]['T'] + 1  # Next batch starts after last trade

        if current_time >= end_time:
            break

        # Progress
        if len(all_trades) % 10000 == 0:
            print(f"  Downloaded {len(all_trades)} trades...")

    # Convert to DataFrame
    df = pd.DataFrame([{
        'timestamp': t['T'],
        'price': float(t['p']),
        'qty': float(t['q']),
        'is_buyer_maker': t['m']
    } for t in all_trades])

    return df


if __name__ == '__main__':
    # Parse command line args
    if len(sys.argv) > 1:
        symbol = sys.argv[1]
    else:
        symbol = 'BTCUSDT'

    # Example: Download 1 hour of recent data
    end_time = int(datetime.now().timestamp() * 1000)
    start_time = end_time - (86400 * 1000)  # 86400

    print(f"{'='*60}")
    print(f"Downloading {symbol} aggTrades from Binance")
    print(f"{'='*60}")
    print(f"Start: {datetime.fromtimestamp(start_time/1000)}")
    print(f"End:   {datetime.fromtimestamp(end_time/1000)}\n")

    df = download_binance_aggtrades(symbol, start_time, end_time)

    print(f"\n{'='*60}")
    print(f"Downloaded {len(df)} trades")
    print(f"{'='*60}")

    # Save to CSV
    output_file = f'examples/data/{symbol.lower()}_recent.csv'
    df.to_csv(output_file, index=False)
    print(f"Saved to {output_file}")

    # Show first few rows
    print(f"\nFirst few rows:")
    print(df.head())
