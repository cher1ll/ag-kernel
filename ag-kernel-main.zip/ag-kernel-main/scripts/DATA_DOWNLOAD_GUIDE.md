# Binance Data Download Guide

Два способа загрузки исторических данных aggTrades от Binance:

## 1. Binance Data Vision (Рекомендуется для истории)

**Файл:** `download_binance_vision.py`

**Когда использовать:**
- ✅ Загрузка больших исторических датасетов (неделя, месяц, год)
- ✅ Данные старше 3 дней
- ✅ Когда нужна максимальная скорость
- ✅ Нет ограничений API

**Преимущества:**
- 🚀 **Очень быстро**: 400k+ трейдов/сек
- 💰 **Бесплатно**: официальные публичные архивы
- 🔓 **Без лимитов**: нет rate limits
- 📦 **Архивы**: данные упакованы в ZIP (экономия траффика)

**Недостатки:**
- ⏰ **Задержка 2-3 дня**: свежие данные недоступны
- 📅 **Только дневные/месячные**: нельзя получить "последние 6 часов"

**Использование:**
```bash
# Последние 7 дней (с задержкой 3 дня)
python scripts/download_binance_vision.py BTCUSDT 7

# Последний месяц
python scripts/download_binance_vision.py BTCUSDT 30

# Последние 3 месяца
python scripts/download_binance_vision.py BTCUSDT 90

# Год данных
python scripts/download_binance_vision.py BTCUSDT 365

# Другая пара
python scripts/download_binance_vision.py ETHUSDT 30
```

**Производительность:**
- 7 дней (2.6M трейдов): **6.7 секунд** = 395k трейдов/сек
- 30 дней (~12M трейдов): **~25-30 секунд**
- 90 дней (~36M трейдов): **~2 минуты**

---

## 2. Binance API (Live данные)

**Файл:** `download_binance_data_async.py`

**Когда использовать:**
- ✅ Нужны **самые свежие** данные (последние 1-3 дня)
- ✅ Точный временной диапазон (например, "с 10:00 до 14:00")
- ✅ Небольшие датасеты (несколько часов)

**Преимущества:**
- 🕒 **Актуальность**: данные доступны сразу
- 🎯 **Точность**: можно указать точное время до миллисекунды
- ⚡ **Быстрый старт**: нет задержки ожидания архивов

**Недостатки:**
- ⚠️ **Rate limits**: можно получить бан (Error 418)
- 🐌 **Медленнее для больших объемов**: ~8k трейдов/сек
- ⏳ **Лимит на большие датасеты**: месяц данных = риск бана

**Использование:**
```bash
# Последние 24 часа
python scripts/download_binance_data_async.py BTCUSDT 24

# Последние 48 часов
python scripts/download_binance_data_async.py BTCUSDT 48

# Последние 3 дня (максимум без риска бана)
python scripts/download_binance_data_async.py BTCUSDT 72

# Другая пара
python scripts/download_binance_data_async.py ETHUSDT 24
```

**⚠️ ВАЖНО:** Не используйте для загрузки больших периодов (неделя+), иначе получите бан!

**Производительность:**
- 24 часа (252k трейдов): **40 секунд** = 6.3k трейдов/сек
- 48 часов (650k трейдов): **80 секунд** = 8.1k трейдов/сек

**Текущий статус бана:**
Если получили ошибку:
```
Error 418: IP banned until 1767304914810
```
Бан автоматически снимется через указанное время (unix timestamp в миллисекундах).

---

## Рекомендации

### Для бэктестинга (исторические данные):

**✅ Используйте Data Vision**
```bash
# Загрузить 3 месяца для бэктестинга стратегии
python scripts/download_binance_vision.py BTCUSDT 90
```

### Для live trading / свежих данных:

**✅ Используйте API** (с осторожностью)
```bash
# Последние 24 часа для тестирования на свежих данных
python scripts/download_binance_data_async.py BTCUSDT 24
```

### Гибридный подход (лучшее из обоих):

1. **Исторические данные**: Data Vision (месяцы назад)
2. **Свежие данные**: API (последние 1-2 дня)
3. **Объединение**: Merge файлов вручную

```bash
# Шаг 1: Исторические данные (Data Vision)
python scripts/download_binance_vision.py BTCUSDT 90

# Шаг 2: Свежие данные (API)
python scripts/download_binance_data_async.py BTCUSDT 24

# Шаг 3: Объединить файлы (pandas)
# Merge btcusdt_vision_90d.csv + btcusdt_recent_24h.csv
```

---

## Формат выходных данных

Оба скрипта создают CSV с одинаковым форматом:

```csv
timestamp,price,qty,is_buyer_maker
1767215502683,87713.53,0.00034,False
1767215502844,87713.53,0.00011,False
...
```

**Колонки:**
- `timestamp`: Unix timestamp в **миллисекундах**
- `price`: Цена трейда (float)
- `qty`: Объем трейда (float)
- `is_buyer_maker`: True = агрессор продавал, False = агрессор покупал

**Совместимость:**
Файлы совместимы с `AggTradesFeed`:

```python
from ag_backtester.data.aggtrades import AggTradesFeed

feed = AggTradesFeed('examples/data/btcusdt_vision_90d.csv', tick_size=0.01)
for tick in feed.iter_ticks():
    print(tick)
```

---

## Устранение проблем

### Error 418 (IP Banned)

**Проблема:**
```
❌ Error 418: Way too much request weight used; IP banned until ...
```

**Решение:**
1. Подождите до указанного времени (обычно 10-60 минут)
2. Используйте Data Vision вместо API
3. Уменьшите `max_concurrent` в async скрипте (с 50 до 20)

### 404 Not Found (Data Vision)

**Проблема:**
```
⚠️  BTCUSDT-aggTrades-2026-01-01.zip: Not available (404)
```

**Причина:**
- Data Vision имеет задержку 2-3 дня
- Свежие данные еще не опубликованы

**Решение:**
- Используйте более старые даты
- Для свежих данных используйте API скрипт

### Много дубликатов при объединении

**Проблема:**
```
Removed 2,552,804 duplicates
```

**Причина:**
- Data Vision архивы могут перекрываться
- Скрипт автоматически удаляет дубликаты по timestamp

**Решение:**
- Это нормально, дедупликация автоматическая
- Финальный файл корректен

---

## Сравнительная таблица

| Критерий | Data Vision | API |
|----------|-------------|-----|
| **Скорость** | 400k trades/sec | 8k trades/sec |
| **Лимиты** | Нет | Есть (ban risk) |
| **Задержка данных** | 2-3 дня | Real-time |
| **Макс. период** | Годы | 2-3 дня (безопасно) |
| **Стоимость** | Бесплатно | Бесплатно (но лимиты) |
| **Рекомендуется для** | История, бэктест | Live, свежие данные |

---

## Примеры использования

### Пример 1: Бэктестинг стратегии за 6 месяцев

```bash
# Data Vision - безопасно и быстро
python scripts/download_binance_vision.py BTCUSDT 180
# Результат: btcusdt_vision_180d.csv (~50M трейдов за ~5 минут)
```

### Пример 2: Тестирование на свежих данных

```bash
# API - последние 48 часов
python scripts/download_binance_data_async.py BTCUSDT 48
# Результат: btcusdt_recent_48h.csv (~650k трейдов за 80 сек)
```

### Пример 3: Сравнение нескольких пар

```bash
# Загрузить 30 дней для 3 пар параллельно
python scripts/download_binance_vision.py BTCUSDT 30 &
python scripts/download_binance_vision.py ETHUSDT 30 &
python scripts/download_binance_vision.py BNBUSDT 30 &
wait
# Все 3 загрузятся параллельно за ~30 секунд
```

---

**Создано:** 2026-01-02
**Версия скриптов:** v2.0 (optimized)
