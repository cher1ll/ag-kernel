#!/usr/bin/env python3
"""
Download historical data from Binance Data Vision (official public archives).

This is the CORRECT way to download large historical datasets:
- No API rate limits
- Much faster (direct S3 downloads)
- Official Binance data source
- Available in daily/monthly archives

Data source: https://data.binance.vision
"""
import asyncio
import aiohttp
import aiofiles
import zipfile
import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Tuple
import sys
from io import BytesIO


class BinanceVisionDownloader:
    """
    Download historical aggTrades from Binance Data Vision.

    Data Vision provides:
    - Daily archives: https://data.binance.vision/data/spot/daily/aggTrades/SYMBOL/SYMBOL-aggTrades-YYYY-MM-DD.zip
    - Monthly archives: https://data.binance.vision/data/spot/monthly/aggTrades/SYMBOL/SYMBOL-aggTrades-YYYY-MM.zip

    Format inside ZIP (CSV):
    agg_trade_id,price,quantity,first_trade_id,last_trade_id,timestamp,is_buyer_maker,is_best_match
    """

    BASE_URL = "https://data.binance.vision/data/spot"

    def __init__(
        self,
        symbol: str = 'BTCUSDT',
        output_dir: Path = Path('examples/data'),
        max_concurrent: int = 10,
        use_monthly: bool = True  # Use monthly archives when possible (faster)
    ):
        self.symbol = symbol
        self.output_dir = output_dir
        self.max_concurrent = max_concurrent
        self.use_monthly = use_monthly
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.semaphore = asyncio.Semaphore(max_concurrent)

        # Stats
        self.stats = {
            'files_downloaded': 0,
            'files_failed': 0,
            'total_trades': 0,
            'total_bytes': 0
        }

    def generate_date_range(
        self,
        start_date: datetime,
        end_date: datetime
    ) -> List[Tuple[str, str]]:
        """
        Generate list of (url, filename) for date range.

        Returns:
            List of (download_url, output_filename) tuples
        """
        urls = []

        if self.use_monthly:
            # Use monthly archives for full months
            current = start_date.replace(day=1)
            end_month = end_date.replace(day=1)

            while current <= end_month:
                year_month = current.strftime('%Y-%m')
                url = f"{self.BASE_URL}/monthly/aggTrades/{self.symbol}/{self.symbol}-aggTrades-{year_month}.zip"
                filename = f"{self.symbol}-aggTrades-{year_month}.zip"
                urls.append((url, filename))

                # Next month
                if current.month == 12:
                    current = current.replace(year=current.year + 1, month=1)
                else:
                    current = current.replace(month=current.month + 1)
        else:
            # Use daily archives
            current = start_date
            while current <= end_date:
                date_str = current.strftime('%Y-%m-%d')
                url = f"{self.BASE_URL}/daily/aggTrades/{self.symbol}/{self.symbol}-aggTrades-{date_str}.zip"
                filename = f"{self.symbol}-aggTrades-{date_str}.zip"
                urls.append((url, filename))
                current += timedelta(days=1)

        return urls

    async def download_and_extract(
        self,
        session: aiohttp.ClientSession,
        url: str,
        filename: str
    ) -> pd.DataFrame:
        """
        Download ZIP file and extract CSV data.

        Args:
            session: aiohttp session
            url: Download URL
            filename: Filename for logging

        Returns:
            DataFrame with trades (or empty if failed)
        """
        async with self.semaphore:
            try:
                print(f"⏬ Downloading {filename}...")

                async with session.get(url, timeout=300) as response:
                    if response.status == 200:
                        # Download to memory
                        zip_data = await response.read()
                        self.stats['total_bytes'] += len(zip_data)

                        # Extract CSV from ZIP
                        with zipfile.ZipFile(BytesIO(zip_data)) as zf:
                            # Get CSV filename (should be only file in archive)
                            csv_filename = zf.namelist()[0]
                            csv_data = zf.read(csv_filename)

                        # Parse CSV
                        df = pd.read_csv(
                            BytesIO(csv_data),
                            names=[
                                'agg_trade_id', 'price', 'quantity',
                                'first_trade_id', 'last_trade_id',
                                'timestamp', 'is_buyer_maker', 'is_best_match'
                            ]
                        )

                        # Convert to our format
                        # Note: Binance Vision uses microseconds, convert to milliseconds
                        timestamps = df['timestamp'].astype(int)
                        # Check if timestamps are in microseconds (16 digits) or milliseconds (13 digits)
                        if timestamps.iloc[0] > 10**15:
                            timestamps = timestamps // 1000  # Convert microseconds to milliseconds

                        df_converted = pd.DataFrame({
                            'timestamp': timestamps,
                            'price': df['price'].astype(float),
                            'qty': df['quantity'].astype(float),
                            'is_buyer_maker': df['is_buyer_maker'].astype(bool)
                        })

                        self.stats['files_downloaded'] += 1
                        self.stats['total_trades'] += len(df_converted)

                        print(f"  ✅ {filename}: {len(df_converted):,} trades ({len(zip_data)/1024/1024:.1f} MB)")
                        return df_converted

                    elif response.status == 404:
                        print(f"  ⚠️  {filename}: Not available (404)")
                        self.stats['files_failed'] += 1
                        return pd.DataFrame()

                    else:
                        print(f"  ❌ {filename}: HTTP {response.status}")
                        self.stats['files_failed'] += 1
                        return pd.DataFrame()

            except asyncio.TimeoutError:
                print(f"  ❌ {filename}: Timeout")
                self.stats['files_failed'] += 1
                return pd.DataFrame()

            except Exception as e:
                print(f"  ❌ {filename}: {e}")
                self.stats['files_failed'] += 1
                return pd.DataFrame()

    async def download_range(
        self,
        start_date: datetime,
        end_date: datetime,
        output_file: Path
    ) -> pd.DataFrame:
        """
        Download historical data for date range.

        Args:
            start_date: Start date
            end_date: End date
            output_file: Output CSV file

        Returns:
            Combined DataFrame
        """
        # Generate download URLs
        urls = self.generate_date_range(start_date, end_date)

        print(f"📦 Found {len(urls)} archives to download")
        print(f"🚀 Downloading with {self.max_concurrent} parallel connections\n")

        # Download all files in parallel
        async with aiohttp.ClientSession() as session:
            tasks = [
                self.download_and_extract(session, url, filename)
                for url, filename in urls
            ]

            results = await asyncio.gather(*tasks)

        # Combine all DataFrames
        print(f"\n📊 Combining data...")
        dfs = [df for df in results if not df.empty]

        if not dfs:
            print("❌ No data downloaded!")
            return pd.DataFrame()

        combined_df = pd.concat(dfs, ignore_index=True)

        # Sort by timestamp and remove duplicates
        print(f"🔄 Sorting and deduplicating...")
        combined_df = combined_df.sort_values('timestamp').reset_index(drop=True)
        original_len = len(combined_df)
        combined_df = combined_df.drop_duplicates(subset=['timestamp'])

        if len(combined_df) < original_len:
            print(f"  Removed {original_len - len(combined_df):,} duplicates")

        # Save to CSV
        print(f"💾 Saving to {output_file}...")
        combined_df.to_csv(output_file, index=False)

        return combined_df

    def print_stats(self):
        """Print download statistics."""
        print(f"\n{'='*60}")
        print("📊 Download Statistics")
        print(f"{'='*60}")
        print(f"Files downloaded: {self.stats['files_downloaded']}")
        print(f"Files failed:     {self.stats['files_failed']}")
        print(f"Total trades:     {self.stats['total_trades']:,}")
        print(f"Total data:       {self.stats['total_bytes']/1024/1024:.1f} MB")
        print(f"{'='*60}")


async def main():
    """Main entry point."""
    # Parse command line args
    if len(sys.argv) < 2:
        print("Usage: python download_binance_vision.py SYMBOL [DAYS]")
        print("\nExamples:")
        print("  python download_binance_vision.py BTCUSDT 30    # Last 30 days")
        print("  python download_binance_vision.py ETHUSDT 90    # Last 90 days")
        print("  python download_binance_vision.py BTCUSDT 365   # Last year")
        sys.exit(1)

    symbol = sys.argv[1]
    days = int(sys.argv[2]) if len(sys.argv) > 2 else 30

    # Calculate date range
    # Binance Vision has 2-3 day delay, use data from 3 days ago
    end_date = datetime.now() - timedelta(days=3)
    start_date = end_date - timedelta(days=days-1)

    # Output file
    output_file = Path(f'examples/data/{symbol.lower()}_vision_{days}d.csv')

    print(f"{'='*60}")
    print(f"🚀 Binance Data Vision Downloader")
    print(f"{'='*60}")
    print(f"Symbol:      {symbol}")
    print(f"Start date:  {start_date.strftime('%Y-%m-%d')}")
    print(f"End date:    {end_date.strftime('%Y-%m-%d')}")
    print(f"Period:      {days} days")
    print(f"Output:      {output_file}")
    print(f"{'='*60}\n")

    # Initialize downloader
    # Use daily archives for recent data (monthly may not be ready yet)
    use_monthly = days >= 60  # Use monthly for 2+ months of data

    downloader = BinanceVisionDownloader(
        symbol=symbol,
        max_concurrent=10,
        use_monthly=use_monthly
    )

    print(f"Archive type: {'Monthly' if use_monthly else 'Daily'}\n")

    # Download
    start_time = datetime.now()
    df = await downloader.download_range(start_date, end_date, output_file)
    elapsed = (datetime.now() - start_time).total_seconds()

    # Results
    print(f"\n{'='*60}")
    print(f"✅ Download Complete!")
    print(f"{'='*60}")
    print(f"Downloaded:  {len(df):,} trades")
    print(f"Time:        {elapsed:.1f}s")
    print(f"Rate:        {len(df)/elapsed if elapsed > 0 else 0:.0f} trades/sec")
    print(f"Output:      {output_file}")
    print(f"{'='*60}")

    # Stats
    downloader.print_stats()

    # Preview
    if not df.empty:
        print(f"\n📋 First 5 trades:")
        print(df.head())
        print(f"\n📋 Last 5 trades:")
        print(df.tail())

        # Date range
        first_ts = df['timestamp'].min()
        last_ts = df['timestamp'].max()
        print(f"\n📅 Data range:")
        print(f"  First: {datetime.fromtimestamp(first_ts/1000)}")
        print(f"  Last:  {datetime.fromtimestamp(last_ts/1000)}")


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n⚠️  Download interrupted!")
