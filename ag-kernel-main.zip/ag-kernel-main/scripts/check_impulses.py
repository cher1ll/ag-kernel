#!/usr/bin/env python3
"""Check impulse patterns in data"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "python"))

from ag_backtester.data import AggTradesFeed, aggregate_ticks
from ag_backtester.userland import calculate_auto_ticksize
import pandas as pd
from collections import deque

data_path = 'examples/data/btcusdt_recent.csv'

# Auto tick size
df_peek = pd.read_csv(data_path, nrows=1)
first_price = df_peek['price'].iloc[0]
tick_size = calculate_auto_ticksize(first_price, target_ticks=20)
print(f"Tick size: {tick_size}")

# Load data
feed = AggTradesFeed(data_path, tick_size=tick_size)
trades = feed.load()
print(f"Loaded {len(trades):,} trades")

# Aggregate ticks
bucket_ms = 1000
ticks = aggregate_ticks(trades, bucket_ms=bucket_ms, tick_size=tick_size)
print(f"Aggregated to {len(ticks):,} ticks\n")

# Analyze impulses
lookback = 5
price_history = deque(maxlen=lookback)
impulses = []

for i, tick in enumerate(ticks[:1000]):  # Check first 1000 ticks
    price = tick.price_tick_i64 * tick_size
    price_history.append(price)

    if len(price_history) >= lookback:
        price_now = price_history[-1]
        price_ago = price_history[0]
        impulse = (price_now - price_ago) / price_ago
        impulses.append(impulse)

if impulses:
    impulses_sorted = sorted(impulses, reverse=True)
    print(f"Sample of {len(impulses)} impulses:")
    print(f"  Max impulse: {max(impulses)*100:+.4f}%")
    print(f"  Min impulse: {min(impulses)*100:+.4f}%")
    print(f"  Top 10 positive impulses:")
    for imp in impulses_sorted[:10]:
        print(f"    {imp*100:+.4f}%")

    # Count impulses above different thresholds
    for threshold in [0.0001, 0.0005, 0.001, 0.002, 0.003]:
        count = sum(1 for imp in impulses if imp > threshold)
        print(f"  Impulses > {threshold*100:.2f}%: {count} ({count/len(impulses)*100:.1f}%)")
