#!/usr/bin/env python3
"""
Validate final strategy on new/unseen data using locked parameters.
This script ensures no parameter optimization - only validation.
"""
import sys
import json
import argparse
from pathlib import Path
from datetime import datetime
sys.path.insert(0, 'strategies')

from framework import WalkForwardAnalyzer
from hypotheses.batch_strategies import get_batch_strategy

def load_final_config():
    """Load final strategy configuration."""
    config_file = Path('final_strategy_config.json')
    
    if not config_file.exists():
        raise FileNotFoundError(
            "final_strategy_config.json not found. "
            "Run select_final_strategy.py first to choose final configuration."
        )
    
    with open(config_file) as f:
        return json.load(f)

def validate_strategy(data_path, config, is_days=7, oos_days=3, step_days=7, output_dir=None):
    """
    Validate strategy using LOCKED parameters - NO optimization allowed.
    """
    strategy_name = config['final_strategy']
    final_params = config['final_parameters']
    
    print("="*80)
    print("🔒 FINAL STRATEGY VALIDATION - NO OPTIMIZATION")
    print("="*80)
    print(f"Strategy: {strategy_name}")
    print(f"Data: {data_path}")
    print(f"Locked Parameters: {json.dumps(final_params, indent=2)}")
    print(f"WFA: IS={is_days}d, OOS={oos_days}d, Step={step_days}d")
    print("")
    print("⚠️  CRITICAL: Using LOCKED parameters - NO optimization performed!")
    print("")
    
    # Get strategy class
    strategy = get_batch_strategy(strategy_name)
    
    # Create WFA analyzer
    wfa = WalkForwardAnalyzer(data_path, is_days=is_days, oos_days=oos_days, step_days=step_days)
    wfa.prepare_windows()
    
    # Run validation with LOCKED parameters only
    # Create single-parameter grid (no optimization)
    locked_grid = {key: [value] for key, value in final_params.items()}
    
    print("🔒 Running validation with locked parameters...")
    results = wfa.run_full_wfa(
        strategy_logic=strategy.generate_logic(),
        param_grid=locked_grid,  # Single parameter set - no optimization!
        bucket_ms=final_params['bucket_ms']
    )
    
    summary = results['summary']
    
    # Validation results
    print(f"\n{'='*80}")
    print("📊 VALIDATION RESULTS")
    print(f"{'='*80}")
    print(f"Profit Factor: {summary['avg_oos_pf']:.2f}")
    print(f"Return: {summary['avg_oos_return']:+.2f}%")
    print(f"Sharpe Ratio: {summary['avg_oos_sharpe']:.2f}")
    print(f"Max Drawdown: {summary['avg_oos_max_dd']:.1f}%")
    print(f"Total Trades: {summary['total_oos_trades']}")
    
    # New detailed metrics
    if 'avg_oos_trades_per_day' in summary:
        print(f"Trades per Day: {summary['avg_oos_trades_per_day']:.1f}")
        print(f"Avg Trade Size: ${summary.get('avg_oos_trade_size_usd', 0):,.0f}")
        print(f"Total Volume: ${summary.get('avg_oos_total_volume_usd', 0):,.0f}")
    
    print(f"Consistency: {summary['consistency']*100:.0f}% ({summary['num_windows']} windows)")
    print(f"Robustness: {summary['robustness_score']:.2f}")
    print(f"MVS Check: {'✅ PASS' if summary['mvs_check']['passes'] else '❌ FAIL'}")
    
    # Calculate and display trading costs
    from framework.metrics import calculate_trading_costs
    
    # Create metrics dict for cost calculation
    cost_metrics = {
        'total_trades': summary['total_oos_trades'],
        'return_pct': summary['avg_oos_return'],
        'avg_trade_size_usd': summary.get('avg_oos_trade_size_usd', 1500)  # Default estimate
    }
    
    # Calculate costs for different scenarios
    print(f"\n{'='*80}")
    print("💰 TRADING COST ANALYSIS")
    print(f"{'='*80}")
    
    cost_scenarios = [
        ('Binance Futures', 0.0002, 0.0004, 1.0),
        ('Binance Spot', 0.001, 0.001, 2.0),
        ('High Slippage', 0.0002, 0.0004, 5.0)
    ]
    
    for scenario_name, maker_fee, taker_fee, slippage in cost_scenarios:
        costs = calculate_trading_costs(cost_metrics, maker_fee, taker_fee, slippage)
        viable = "✅ YES" if costs['economically_viable'] else "❌ NO"
        print(f"{scenario_name:<15} Net Return: {costs['net_return_pct']:+6.2f}% "
              f"Cost: ${costs['total_trading_cost']:8,.0f} "
              f"Viable: {viable}")
    
    # Compare with original results
    original_metrics = config['validation_metrics']
    
    print(f"\n{'='*80}")
    print("📈 PERFORMANCE COMPARISON")
    print(f"{'='*80}")
    print(f"{'Metric':<15} {'Original':<12} {'Validation':<12} {'Difference':<12}")
    print("-"*80)
    
    metrics_comparison = [
        ('Sharpe', original_metrics['sharpe'], summary['avg_oos_sharpe']),
        ('Return %', original_metrics['return'], summary['avg_oos_return']),
        ('Profit Factor', original_metrics['pf'], summary['avg_oos_pf']),
        ('Max DD %', original_metrics['max_dd'], summary['avg_oos_max_dd']),
        ('Trades', original_metrics['trades'], summary['total_oos_trades'])
    ]
    
    validation_score = 0
    total_metrics = len(metrics_comparison)
    
    for metric_name, original, validation in metrics_comparison:
        if original != 0:
            diff_pct = ((validation - original) / abs(original)) * 100
            diff_str = f"{diff_pct:+.1f}%"
            
            # Score validation (closer to original = better)
            if abs(diff_pct) <= 20:  # Within 20%
                validation_score += 1
                status = "✅"
            elif abs(diff_pct) <= 50:  # Within 50%
                validation_score += 0.5
                status = "⚠️"
            else:
                status = "❌"
        else:
            diff_str = "N/A"
            status = "❓"
        
        print(f"{metric_name:<15} {original:<12.2f} {validation:<12.2f} {diff_str:<12} {status}")
    
    validation_percentage = (validation_score / total_metrics) * 100
    
    print(f"\n{'='*80}")
    print("🎯 VALIDATION ASSESSMENT")
    print(f"{'='*80}")
    print(f"Validation Score: {validation_score:.1f}/{total_metrics} ({validation_percentage:.0f}%)")
    
    if validation_percentage >= 80:
        assessment = "🟢 EXCELLENT - Strategy validates well on new data"
    elif validation_percentage >= 60:
        assessment = "🟡 GOOD - Strategy shows reasonable consistency"
    elif validation_percentage >= 40:
        assessment = "🟠 MODERATE - Some performance degradation observed"
    else:
        assessment = "🔴 POOR - Significant performance degradation"
    
    print(f"Assessment: {assessment}")
    
    # Save validation results
    if output_dir:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        validation_report = {
            'validation_timestamp': datetime.now().isoformat(),
            'data_path': data_path,
            'final_config': config,
            'validation_results': summary,
            'comparison': {
                'original_metrics': original_metrics,
                'validation_metrics': {
                    'sharpe': summary['avg_oos_sharpe'],
                    'return': summary['avg_oos_return'],
                    'pf': summary['avg_oos_pf'],
                    'max_dd': summary['avg_oos_max_dd'],
                    'trades': summary['total_oos_trades'],
                    'mvs_pass': summary['mvs_check']['passes']
                },
                'validation_score': validation_score,
                'validation_percentage': validation_percentage,
                'assessment': assessment
            },
            'wfa_results': results
        }
        
        # Save detailed results
        with open(output_path / 'validation_report.json', 'w') as f:
            json.dump(validation_report, f, indent=2, default=str)
        
        # Save summary
        with open(output_path / 'validation_summary.json', 'w') as f:
            json.dump({
                'strategy': strategy_name,
                'validation_score': validation_percentage,
                'assessment': assessment,
                'sharpe': summary['avg_oos_sharpe'],
                'return': summary['avg_oos_return'],
                'pf': summary['avg_oos_pf'],
                'timestamp': datetime.now().isoformat()
            }, f, indent=2)
        
        print(f"\n💾 Validation results saved to: {output_dir}")
    
    return results, validation_percentage

def main():
    parser = argparse.ArgumentParser(description="Validate final strategy on new data")
    parser.add_argument('data_path', help='Path to validation dataset (must be different from training data)')
    parser.add_argument('--is-days', type=int, default=7, help='In-sample days for validation WFA')
    parser.add_argument('--oos-days', type=int, default=3, help='Out-of-sample days for validation WFA')
    parser.add_argument('--step-days', type=int, default=7, help='Step days for validation WFA')
    parser.add_argument('--output', help='Output directory for validation results')
    
    args = parser.parse_args()
    
    # Generate output directory if not specified
    if args.output is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        args.output = f"outputs/validation_{timestamp}"
    
    try:
        # Load final configuration
        config = load_final_config()
        
        # Validate strategy
        results, score = validate_strategy(
            args.data_path, config, 
            args.is_days, args.oos_days, args.step_days,
            args.output
        )
        
        print(f"\n🏁 VALIDATION COMPLETE")
        print(f"Final Score: {score:.0f}%")
        
        if score >= 60:
            print("✅ Strategy validation PASSED - Ready for live trading consideration")
        else:
            print("❌ Strategy validation FAILED - Requires further analysis")
            
    except Exception as e:
        print(f"❌ Validation failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
