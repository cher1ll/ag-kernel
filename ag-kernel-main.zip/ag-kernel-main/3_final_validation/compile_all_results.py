#!/usr/bin/env python3
"""
Compile all strategy results across different datasets and create comparison report.
"""
import json
import glob
from pathlib import Path

def load_results():
    """Load all test results from outputs directory."""
    results = {}

    # Pattern: outputs/*/{strategy}_{period}/summary.json
    for summary_file in glob.glob('outputs/**/summary.json', recursive=True):
        path = Path(summary_file)

        try:
            with open(summary_file) as f:
                data = json.load(f)

            strategy = data.get('strategy', 'unknown')

            # Extract period from path
            folder_name = path.parent.name
            
            # Handle different folder naming patterns
            if folder_name.startswith('strategy_'):
                # Pattern: strategy_h03d_20260106_011446 -> extract from data_path
                data_path = data.get('data_path', '')
                if 'btcusdt_vision_7d' in data_path:
                    period = '7d'
                elif 'btcusdt_vision_30d' in data_path:
                    period = '30d'
                elif 'btcusdt_vision_90d' in data_path:
                    period = '90d'
                elif 'btcusdt_vision_180d' in data_path:
                    period = '180d'
                elif 'btcusdt_vision_365d' in data_path:
                    period = '365d'
                else:
                    # Fallback: use timestamp as identifier
                    parts = folder_name.split('_')
                    if len(parts) >= 4:
                        period = f"{parts[3]}"  # Use timestamp part
                    else:
                        period = 'unknown'
            elif '_bucket_' in folder_name:
                # Pattern: h03b_bucket_600000ms -> extract bucket size
                parts = folder_name.split('_bucket_')
                period = parts[1] if len(parts) > 1 else 'unknown'
            else:
                # Pattern: h03_30d, parallel_30d_*/h03_30d -> extract last part
                parts = folder_name.split('_')
                period = parts[-1] if parts else 'unknown'

            # Store results - use IS data if OOS is empty, but don't overwrite better results
            oos_pf = data.get('avg_oos_pf', 0)
            oos_trades = data.get('total_oos_trades', 0)
            
            # Extract folder info for unique identification
            folder_info = ""
            if folder_name.startswith('strategy_'):
                parts = folder_name.split('_')
                if len(parts) >= 4:
                    folder_info = f"_{parts[2]}_{parts[3]}"  # Add date_time
            elif folder_name.startswith('parallel_'):
                folder_info = f"_{folder_name}"
            else:
                folder_info = f"_{folder_name}"
            
            # Include folder info in period for display
            display_period = period + folder_info
            key = f"{strategy}_{display_period}"
            
            # If OOS has no trades, try to get IS results from wfa_results.json
            if oos_trades == 0 and oos_pf == 0:
                wfa_path = path.parent / 'wfa_results.json'
                if wfa_path.exists():
                    try:
                        with open(wfa_path) as f:
                            wfa_data = json.load(f)
                        
                        # Get IS metrics from first window
                        if wfa_data.get('windows') and len(wfa_data['windows']) > 0:
                            is_metrics = wfa_data['windows'][0].get('is_metrics', {})
                            is_trades = is_metrics.get('total_trades', 0)
                            if is_trades > 0:
                                # Use IS results with a note
                                results[key] = {
                                    'strategy': strategy,
                                    'period': display_period + '_IS',  # Mark as IS data
                                    'pf': is_metrics.get('profit_factor', 0),
                                    'return': is_metrics.get('return_pct', 0),
                                    'sharpe': is_metrics.get('sharpe_ratio', 0),
                                    'max_dd': is_metrics.get('max_drawdown_pct', 0),
                                    'trades': is_trades,
                                    'consistency': data.get('consistency', 0) * 100,
                                    'robustness': data.get('robustness_score', 0),
                                    'mvs': data.get('mvs_check', False),
                                    'bucket_ms': data.get('bucket_ms', 0)
                                }
                                continue
                    except Exception as e:
                        pass
            
            # Use OOS results (default)
            results[key] = {
                'strategy': strategy,
                'period': display_period,
                'pf': oos_pf,
                'return': data.get('avg_oos_return', 0),
                'sharpe': data.get('avg_oos_sharpe', 0),
                'max_dd': data.get('avg_oos_max_dd', 0),
                'trades': oos_trades,
                'consistency': data.get('consistency', 0) * 100,
                'robustness': data.get('robustness_score', 0),
                'mvs': data.get('mvs_check', False),
                'bucket_ms': data.get('bucket_ms', 0)
            }
        except Exception as e:
            print(f"Error loading {summary_file}: {e}")

    return results

def main():
    results = load_results()

    if not results:
        print("No results found. Make sure tests have completed.")
        return

    # Group by strategy and period
    strategies = sorted(set(r['strategy'] for r in results.values()))
    periods = sorted(set(r['period'] for r in results.values()))

    print("="*140)
    print("STRATEGY PERFORMANCE ACROSS DATASETS")
    print("="*140)

    for strategy in strategies:
        print(f"\n📊 {strategy.upper()}")
        print("-"*140)
        print(f"{'Period':<10} {'PF':>7} {'Return':>9} {'Sharpe':>8} {'MaxDD':>8} {'Trades':>7} {'Consist':>9} {'Robust':>8} {'MVS':>5} {'Bucket':>10}")
        print("-"*140)

        strategy_results = {k: v for k, v in results.items() if v['strategy'] == strategy}

        for key in sorted(strategy_results.keys(), key=lambda k: strategy_results[k]['period']):
            r = strategy_results[key]
            mvs_icon = '✅' if r['mvs'] else '❌'
            bucket_h = r['bucket_ms'] / 3600000 if r['bucket_ms'] > 0 else 0

            print(f"{r['period']:<10} {r['pf']:7.2f} {r['return']:+8.2f}% {r['sharpe']:8.2f} "
                  f"{r['max_dd']:7.2f}% {r['trades']:7d} {r['consistency']:8.0f}% "
                  f"{r['robustness']:8.2f} {mvs_icon:>5} {bucket_h:9.1f}h")

    print("\n" + "="*140)
    print("\n🏆 BEST PERFORMANCE BY DATASET:")
    print("-"*140)

    for period in periods:
        period_results = {k: v for k, v in results.items() if v['period'] == period}

        if not period_results:
            continue

        # Find best by Sharpe
        best_sharpe = max(period_results.values(), key=lambda x: x['sharpe'])
        best_return = max(period_results.values(), key=lambda x: x['return'])
        best_pf = max(period_results.values(), key=lambda x: x['pf'])

        print(f"\n{period}:")
        print(f"  Best Sharpe: {best_sharpe['strategy']} (Sharpe={best_sharpe['sharpe']:.2f}, Return={best_sharpe['return']:+.2f}%)")
        print(f"  Best Return: {best_return['strategy']} (Return={best_return['return']:+.2f}%, Sharpe={best_return['sharpe']:.2f})")
        print(f"  Best PF:     {best_pf['strategy']} (PF={best_pf['pf']:.2f}, Return={best_pf['return']:+.2f}%)")

    print("\n" + "="*140)

if __name__ == '__main__':
    main()
