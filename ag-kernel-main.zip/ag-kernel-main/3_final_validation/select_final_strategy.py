#!/usr/bin/env python3
"""
Select final strategy configuration based on comprehensive scoring.
"""
import json
import glob
from pathlib import Path
from collections import defaultdict

def load_strategy_details():
    """Load detailed strategy results with parameters."""
    strategies = []
    
    for summary_file in glob.glob('outputs/**/summary.json', recursive=True):
        path = Path(summary_file)
        
        try:
            with open(summary_file) as f:
                summary = json.load(f)
            
            # Try to load WFA results for parameters
            wfa_file = path.parent / 'wfa_results.json'
            best_params = None
            
            if wfa_file.exists():
                with open(wfa_file) as f:
                    wfa_data = json.load(f)
                    if wfa_data.get('windows'):
                        best_params = wfa_data['windows'][0].get('best_params', {})
            
            strategy = {
                'name': summary.get('strategy', 'unknown'),
                'period': summary.get('bucket_ms', 0),
                'period_str': path.parent.name.split('_')[-1],
                'path': str(path.parent),
                'sharpe': summary.get('avg_oos_sharpe', 0),
                'return': summary.get('avg_oos_return', 0),
                'pf': summary.get('avg_oos_pf', 0),
                'max_dd': summary.get('avg_oos_max_dd', 0),
                'trades': summary.get('total_oos_trades', 0),
                'consistency': summary.get('consistency', 0),
                'robustness': summary.get('robustness_score', 0),
                'mvs': summary.get('mvs_check', False),
                'params': best_params,
                'timestamp': summary.get('timestamp', '')
            }
            
            # Filter valid strategies
            if (strategy['sharpe'] > 0 and 
                strategy['return'] > 0 and 
                strategy['trades'] > 100 and
                not str(strategy['sharpe']) == 'nan'):
                strategies.append(strategy)
                
        except Exception as e:
            print(f"Error loading {summary_file}: {e}")
    
    return strategies

def calculate_composite_score(strategy):
    """Calculate composite score for strategy ranking."""
    # Normalize metrics (0-1 scale)
    sharpe_norm = min(strategy['sharpe'] / 2.0, 1.0)  # Cap at 2.0
    return_norm = min(strategy['return'] / 10.0, 1.0)  # Cap at 10%
    pf_norm = min(strategy['pf'] / 15.0, 1.0)  # Cap at 15.0
    consistency_norm = strategy['consistency']
    robustness_norm = strategy['robustness']
    
    # Penalty factors
    dd_penalty = max(0, 1 - strategy['max_dd'] / 15.0)  # Penalty for >15% DD
    trades_bonus = min(strategy['trades'] / 1000.0, 1.0)  # Bonus for more trades
    mvs_bonus = 1.2 if strategy['mvs'] else 1.0
    
    # Weighted composite score
    score = (
        sharpe_norm * 0.3 +
        return_norm * 0.25 +
        pf_norm * 0.15 +
        consistency_norm * 0.15 +
        robustness_norm * 0.15
    ) * dd_penalty * trades_bonus * mvs_bonus
    
    return score

def main():
    strategies = load_strategy_details()
    
    if not strategies:
        print("No valid strategies found.")
        return
    
    # Calculate scores
    for s in strategies:
        s['score'] = calculate_composite_score(s)
    
    # Sort by score
    strategies.sort(key=lambda x: x['score'], reverse=True)
    
    print("="*120)
    print("FINAL STRATEGY SELECTION - COMPREHENSIVE RANKING")
    print("="*120)
    print(f"{'Rank':<5} {'Strategy':<10} {'Period':<12} {'Score':<7} {'Sharpe':<8} {'Return':<9} {'PF':<7} {'MVS':<5} {'Trades':<7}")
    print("-"*120)
    
    for i, s in enumerate(strategies[:10]):  # Top 10
        rank = f"🥇 {i+1}" if i == 0 else f"🥈 {i+1}" if i == 1 else f"🥉 {i+1}" if i == 2 else f"{i+1}."
        mvs_icon = '✅' if s['mvs'] else '❌'
        period_h = s['period'] / 3600000 if s['period'] > 0 else 0
        
        print(f"{rank:<5} {s['name']:<10} {period_h:>9.1f}h {s['score']:<7.3f} "
              f"{s['sharpe']:<8.2f} {s['return']:+8.2f}% {s['pf']:<7.2f} "
              f"{mvs_icon:<5} {s['trades']:<7}")
    
    # Show winner details
    winner = strategies[0]
    print(f"\n{'='*120}")
    print("🏆 FINAL STRATEGY SELECTION")
    print(f"{'='*120}")
    print(f"Strategy: {winner['name']}")
    print(f"Period: {winner['period']/3600000:.1f}h ({winner['period']}ms)")
    print(f"Score: {winner['score']:.3f}")
    print(f"Sharpe: {winner['sharpe']:.2f}")
    print(f"Return: {winner['return']:+.2f}%")
    print(f"Profit Factor: {winner['pf']:.2f}")
    print(f"Max Drawdown: {winner['max_dd']:.2f}%")
    print(f"Trades: {winner['trades']}")
    print(f"Consistency: {winner['consistency']*100:.0f}%")
    print(f"Robustness: {winner['robustness']:.2f}")
    print(f"MVS Check: {'✅ PASS' if winner['mvs'] else '❌ FAIL'}")
    print(f"Path: {winner['path']}")
    
    if winner['params']:
        print(f"\n📋 FINAL PARAMETERS:")
        for key, value in winner['params'].items():
            if key != 'bucket_ms':  # Already shown above
                print(f"  {key}: {value}")
    
    # Save final config
    final_config = {
        'final_strategy': winner['name'],
        'final_period_ms': winner['period'],
        'final_parameters': winner['params'],
        'selection_score': winner['score'],
        'selection_timestamp': winner['timestamp'],
        'validation_metrics': {
            'sharpe': winner['sharpe'],
            'return': winner['return'],
            'pf': winner['pf'],
            'max_dd': winner['max_dd'],
            'trades': winner['trades'],
            'mvs_pass': winner['mvs']
        }
    }
    
    with open('final_strategy_config.json', 'w') as f:
        json.dump(final_config, f, indent=2)
    
    print(f"\n💾 Final configuration saved to: final_strategy_config.json")
    print(f"\n🎯 NEXT STEPS:")
    print(f"1. Use this configuration for all future backtests")
    print(f"2. Run validation on new/unseen data with these exact parameters")
    print(f"3. Do NOT re-optimize - use as-is for true out-of-sample testing")

if __name__ == '__main__':
    main()
