#!/usr/bin/env python3
"""
Operational Risk Analysis for H03B Strategy
Analyzes exchange limits, API constraints, and operational failure modes.
"""
import json
import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta

def load_latest_validation_data():
    """Load the most recent validation results."""
    outputs_dir = Path('outputs')
    validation_dirs = [d for d in outputs_dir.glob('validation_*') if d.is_dir()]
    
    if not validation_dirs:
        return None
    
    latest_dir = max(validation_dirs, key=lambda x: x.name)
    
    # Try to load validation report with detailed metrics
    report_file = latest_dir / 'validation_report.json'
    if report_file.exists():
        with open(report_file) as f:
            return json.load(f)
    
    return None

def analyze_exchange_limits():
    """Analyze Binance exchange limits and constraints."""
    
    # Real Binance limits (as of 2024)
    binance_limits = {
        'spot': {
            'orders_per_second': 10,
            'orders_per_day': 200000,
            'weight_per_minute': 1200,
            'raw_requests_per_5min': 6100
        },
        'futures': {
            'orders_per_second': 20,
            'orders_per_day': 300000,
            'weight_per_minute': 2400,
            'raw_requests_per_5min': 12200
        }
    }
    
    return binance_limits

def calculate_api_usage(trades_per_day, avg_trade_duration_minutes):
    """Calculate API usage patterns and risk levels."""
    
    # Estimate API calls per trade
    # Typical sequence: market data request + order placement + order status + position check
    api_calls_per_trade = 4
    
    # Calculate usage patterns
    api_calls_per_day = trades_per_day * api_calls_per_trade
    api_calls_per_second = api_calls_per_day / (24 * 60 * 60)
    api_calls_per_minute = api_calls_per_second * 60
    
    # Peak usage (assuming trades cluster during active hours)
    # Assume 80% of trades happen in 8 hours (active trading)
    peak_multiplier = 3.0  # 3x normal rate during peak
    peak_api_calls_per_second = api_calls_per_second * peak_multiplier
    peak_api_calls_per_minute = peak_api_calls_per_second * 60
    
    return {
        'api_calls_per_day': api_calls_per_day,
        'api_calls_per_second': api_calls_per_second,
        'api_calls_per_minute': api_calls_per_minute,
        'peak_api_calls_per_second': peak_api_calls_per_second,
        'peak_api_calls_per_minute': peak_api_calls_per_minute
    }

def assess_operational_risks(trades_per_day, api_usage, exchange_limits):
    """Assess operational risks and failure modes."""
    
    risks = {}
    
    # API Rate Limiting Risk
    spot_limit = exchange_limits['spot']['orders_per_second']
    futures_limit = exchange_limits['futures']['orders_per_second']
    
    risks['rate_limit_spot'] = {
        'usage_pct': (api_usage['peak_api_calls_per_second'] / spot_limit) * 100,
        'risk_level': 'HIGH' if api_usage['peak_api_calls_per_second'] > spot_limit * 0.8 else 'MEDIUM' if api_usage['peak_api_calls_per_second'] > spot_limit * 0.5 else 'LOW',
        'margin_safety': spot_limit - api_usage['peak_api_calls_per_second']
    }
    
    risks['rate_limit_futures'] = {
        'usage_pct': (api_usage['peak_api_calls_per_second'] / futures_limit) * 100,
        'risk_level': 'HIGH' if api_usage['peak_api_calls_per_second'] > futures_limit * 0.8 else 'MEDIUM' if api_usage['peak_api_calls_per_second'] > futures_limit * 0.5 else 'LOW',
        'margin_safety': futures_limit - api_usage['peak_api_calls_per_second']
    }
    
    # Daily Volume Risk
    daily_orders = trades_per_day * 2  # Entry + Exit
    
    risks['daily_volume_spot'] = {
        'usage_pct': (daily_orders / exchange_limits['spot']['orders_per_day']) * 100,
        'risk_level': 'HIGH' if daily_orders > exchange_limits['spot']['orders_per_day'] * 0.8 else 'LOW'
    }
    
    risks['daily_volume_futures'] = {
        'usage_pct': (daily_orders / exchange_limits['futures']['orders_per_day']) * 100,
        'risk_level': 'HIGH' if daily_orders > exchange_limits['futures']['orders_per_day'] * 0.8 else 'LOW'
    }
    
    # Account Flagging Risk (heuristic based on trading patterns)
    if trades_per_day > 100:
        account_risk = 'HIGH'
    elif trades_per_day > 50:
        account_risk = 'MEDIUM'
    else:
        account_risk = 'LOW'
    
    risks['account_flagging'] = {
        'risk_level': account_risk,
        'reason': f'{trades_per_day:.1f} trades/day may trigger algorithmic trading detection'
    }
    
    return risks

def analyze_failure_modes():
    """Analyze potential operational failure modes."""
    
    failure_modes = [
        {
            'mode': 'API Rate Limit Hit',
            'probability': 'MEDIUM',
            'impact': 'HIGH',
            'consequence': 'Orders rejected, missed opportunities, potential losses',
            'mitigation': 'Implement request queuing, reduce trade frequency'
        },
        {
            'mode': 'Network Connectivity Loss',
            'probability': 'LOW',
            'impact': 'CRITICAL',
            'consequence': 'Unable to close positions, unlimited risk exposure',
            'mitigation': 'Redundant connections, stop-loss orders, position monitoring'
        },
        {
            'mode': 'Exchange Maintenance',
            'probability': 'MEDIUM',
            'impact': 'HIGH',
            'consequence': 'Trading halted, positions stuck, market risk',
            'mitigation': 'Monitor maintenance schedules, reduce positions before maintenance'
        },
        {
            'mode': 'Account Suspension',
            'probability': 'LOW',
            'impact': 'CRITICAL',
            'consequence': 'Complete trading halt, funds locked',
            'mitigation': 'Comply with exchange rules, diversify across exchanges'
        },
        {
            'mode': 'Market Data Lag',
            'probability': 'HIGH',
            'impact': 'MEDIUM',
            'consequence': 'Stale signals, poor entry/exit timing',
            'mitigation': 'Multiple data feeds, latency monitoring'
        }
    ]
    
    return failure_modes

def main():
    print("⚙️  OPERATIONAL RISK ANALYSIS - H03B Strategy")
    print("="*80)
    
    # Real data from best H03B run (600000ms on 90d dataset)
    total_oos_trades = 3238
    wfa_windows = 8
    oos_days_per_window = 2
    total_oos_days = wfa_windows * oos_days_per_window  # 16 days
    
    trades_per_day = total_oos_trades / total_oos_days  # Real calculation
    
    print(f"📊 TRADING ACTIVITY PROFILE (Real Data - Best H03B Run)")
    print("-"*80)
    print(f"Total OOS Trades: {total_oos_trades}")
    print(f"Total OOS Days: {total_oos_days}")
    print(f"Trades per Day: {trades_per_day:.1f}")
    print(f"WFA Windows: {wfa_windows}")
    print(f"OOS Days per Window: {oos_days_per_window}")
    print("")
    
    # Analyze exchange limits
    exchange_limits = analyze_exchange_limits()
    
    print(f"🏦 EXCHANGE LIMITS")
    print("-"*80)
    print(f"{'Exchange':<12} {'Orders/sec':<12} {'Orders/day':<12} {'Weight/min':<12}")
    print("-"*80)
    for exchange, limits in exchange_limits.items():
        print(f"{exchange.title():<12} {limits['orders_per_second']:<12} "
              f"{limits['orders_per_day']:<12} {limits['weight_per_minute']:<12}")
    print("")
    
    # Calculate API usage
    avg_duration = 30  # Assume 30 minutes average trade duration
    api_usage = calculate_api_usage(trades_per_day, avg_duration)
    
    print(f"📡 API USAGE ANALYSIS")
    print("-"*80)
    print(f"API Calls per Day: {api_usage['api_calls_per_day']:.0f}")
    print(f"API Calls per Second (avg): {api_usage['api_calls_per_second']:.2f}")
    print(f"API Calls per Second (peak): {api_usage['peak_api_calls_per_second']:.2f}")
    print(f"API Calls per Minute (peak): {api_usage['peak_api_calls_per_minute']:.1f}")
    print("")
    
    # Assess risks
    risks = assess_operational_risks(trades_per_day, api_usage, exchange_limits)
    
    print(f"⚠️  OPERATIONAL RISK ASSESSMENT")
    print("-"*80)
    print(f"{'Risk Category':<20} {'Spot Risk':<12} {'Futures Risk':<15} {'Safety Margin'}")
    print("-"*80)
    
    spot_rate = risks['rate_limit_spot']
    futures_rate = risks['rate_limit_futures']
    print(f"{'Rate Limiting':<20} {spot_rate['risk_level']:<12} "
          f"{futures_rate['risk_level']:<15} "
          f"{futures_rate['margin_safety']:.1f} req/s")
    
    spot_vol = risks['daily_volume_spot']
    futures_vol = risks['daily_volume_futures']
    print(f"{'Daily Volume':<20} {spot_vol['risk_level']:<12} "
          f"{futures_vol['risk_level']:<15} "
          f"{futures_vol['usage_pct']:.1f}% used")
    
    account_risk = risks['account_flagging']
    print(f"{'Account Flagging':<20} {account_risk['risk_level']:<12} "
          f"{account_risk['risk_level']:<15} "
          f"Pattern detection")
    print("")
    
    # Failure mode analysis
    failure_modes = analyze_failure_modes()
    
    print(f"🚨 FAILURE MODE ANALYSIS")
    print("-"*80)
    print(f"{'Failure Mode':<20} {'Probability':<12} {'Impact':<10} {'Mitigation Priority'}")
    print("-"*80)
    
    for mode in failure_modes:
        priority = 'CRITICAL' if mode['impact'] == 'CRITICAL' else 'HIGH' if mode['probability'] == 'HIGH' or mode['impact'] == 'HIGH' else 'MEDIUM'
        print(f"{mode['mode']:<20} {mode['probability']:<12} "
              f"{mode['impact']:<10} {priority}")
    
    print("")
    
    # Overall assessment
    high_risks = sum(1 for risk in risks.values() if isinstance(risk, dict) and risk.get('risk_level') == 'HIGH')
    
    print(f"🎯 OPERATIONAL READINESS ASSESSMENT")
    print("-"*80)
    
    if high_risks == 0:
        print("✅ OPERATIONAL READY - Low operational risk profile")
        print("✅ Recommended: Proceed with live trading")
    elif high_risks <= 2:
        print("⚠️  OPERATIONAL CAUTION - Medium risk profile")
        print("⚠️  Recommended: Implement risk mitigations before live trading")
    else:
        print("❌ OPERATIONAL RISK - High risk profile")
        print("❌ Recommended: Reduce trading frequency or redesign strategy")
    
    print(f"\nHigh Risk Categories: {high_risks}")
    print(f"Recommended Exchange: {'Binance Futures' if futures_rate['risk_level'] != 'HIGH' else 'Consider alternatives'}")
    
    # Specific recommendations
    print(f"\n📋 SPECIFIC RECOMMENDATIONS")
    print("-"*80)
    
    if futures_rate['risk_level'] == 'LOW':
        print("✅ Binance Futures: Sufficient API headroom")
    else:
        print("⚠️  Consider API request optimization or rate limiting")
    
    if trades_per_day > 50:
        print("⚠️  High frequency may trigger exchange monitoring")
        print("   → Consider position sizing optimization to reduce trade count")
    
    if account_risk['risk_level'] == 'HIGH':
        print("⚠️  Account flagging risk detected")
        print("   → Implement human-like trading patterns")
        print("   → Add random delays between trades")

if __name__ == "__main__":
    main()
