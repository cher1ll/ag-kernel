#!/usr/bin/env python3
"""
Analyze return calculation periods from validation results.
"""
import json
from pathlib import Path
from datetime import datetime, timedelta

def analyze_return_periods():
    """Analyze what the return percentages represent."""
    
    validation_dirs = [
        "outputs/validation_20260105_214611",  # 90d
        "outputs/validation_20260105_214719",  # 180d
        "outputs/validation_20260105_214503",  # 7d
    ]
    
    print("📊 RETURN PERIOD ANALYSIS")
    print("="*80)
    
    for val_dir in validation_dirs:
        val_path = Path(val_dir)
        if not val_path.exists():
            continue
            
        # Load validation report
        report_file = val_path / 'validation_report.json'
        if not report_file.exists():
            continue
            
        with open(report_file) as f:
            report = json.load(f)
        
        data_path = report['data_path']
        dataset_name = Path(data_path).name
        
        validation_results = report['validation_results']
        num_windows = validation_results['num_windows']
        avg_return = validation_results.get('avg_oos_return', 0)
        
        # Load WFA details if available
        wfa_file = val_path / 'validation_report.json'
        wfa_results = report.get('wfa_results', {})
        windows = wfa_results.get('windows', [])
        
        print(f"\n📈 {dataset_name}")
        print("-" * 50)
        print(f"Total Windows: {num_windows}")
        print(f"Average OOS Return: {avg_return:+.2f}%")
        
        if windows:
            print(f"Window Details:")
            total_oos_days = 0
            
            for i, window in enumerate(windows[:3]):  # Show first 3 windows
                oos_period = window.get('oos_period', 'Unknown')
                oos_metrics = window.get('oos_metrics', {})
                oos_return = oos_metrics.get('return_pct', 0)
                
                print(f"  Window {i}: {oos_period} → Return: {oos_return:+.2f}%")
                
                # Calculate OOS period length
                if 'to' in oos_period:
                    try:
                        start_str, end_str = oos_period.split(' to ')
                        start_date = datetime.strptime(start_str.strip(), '%Y-%m-%d')
                        end_date = datetime.strptime(end_str.strip(), '%Y-%m-%d')
                        days = (end_date - start_date).days
                        total_oos_days += days
                        print(f"    OOS Period: {days} days")
                    except:
                        pass
            
            if total_oos_days > 0 and num_windows > 0:
                avg_oos_days = total_oos_days / min(len(windows), 3)
                print(f"  Average OOS Period: ~{avg_oos_days:.0f} days per window")
                
                # Annualized return calculation
                if avg_oos_days > 0:
                    periods_per_year = 365 / avg_oos_days
                    annualized_return = ((1 + avg_return/100) ** periods_per_year - 1) * 100
                    print(f"  Annualized Return: ~{annualized_return:+.1f}% per year")
        
        print(f"\n💡 INTERPRETATION:")
        print(f"  - Return {avg_return:+.2f}% is the AVERAGE per OOS window")
        print(f"  - Each OOS window is typically 3 days")
        print(f"  - This represents return per 3-day period")
        print(f"  - NOT monthly or total period return")

def calculate_theoretical_returns():
    """Calculate what returns would look like over different periods."""
    
    print(f"\n" + "="*80)
    print("🧮 THEORETICAL RETURN PROJECTIONS")
    print("="*80)
    
    # Use 180d validation results as most reliable
    avg_3day_return = 4.84  # From 180d validation
    
    print(f"Base: {avg_3day_return:+.2f}% per 3-day OOS window")
    print()
    
    periods = [
        ("1 week", 7/3),
        ("1 month", 30/3), 
        ("3 months", 90/3),
        ("6 months", 180/3),
        ("1 year", 365/3)
    ]
    
    print(f"{'Period':<12} {'Simple':<12} {'Compound':<12} {'Note'}")
    print("-" * 60)
    
    for period_name, multiplier in periods:
        # Simple calculation (linear)
        simple_return = avg_3day_return * multiplier
        
        # Compound calculation (more realistic)
        compound_return = ((1 + avg_3day_return/100) ** multiplier - 1) * 100
        
        note = "⚠️ High" if compound_return > 100 else "✅ Reasonable" if compound_return > 20 else "📊 Conservative"
        
        print(f"{period_name:<12} {simple_return:+8.1f}%   {compound_return:+8.1f}%   {note}")
    
    print(f"\n⚠️  IMPORTANT NOTES:")
    print(f"- These are THEORETICAL projections")
    print(f"- Real trading has slippage, fees, market changes")
    print(f"- Past performance ≠ future results")
    print(f"- Use for relative comparison only")

if __name__ == '__main__':
    analyze_return_periods()
    calculate_theoretical_returns()
