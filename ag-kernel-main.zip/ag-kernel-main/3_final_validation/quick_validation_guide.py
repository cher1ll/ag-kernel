#!/usr/bin/env python3
"""
Quick validation test for final strategy.
"""
import json
from pathlib import Path

def quick_validation_test():
    """Run quick validation on different datasets."""
    
    # Check if final config exists
    config_file = Path('final_strategy_config.json')
    if not config_file.exists():
        print("❌ final_strategy_config.json not found!")
        print("Run: python strategies/select_final_strategy.py")
        return
    
    with open(config_file) as f:
        config = json.load(f)
    
    print("🎯 FINAL STRATEGY VALIDATION TESTS")
    print("="*60)
    print(f"Strategy: {config['final_strategy']}")
    print(f"Parameters: {json.dumps(config['final_parameters'], indent=2)}")
    print("")
    
    # Available datasets for validation
    datasets = [
        ("examples/data/btcusdt_vision_7d.csv", "7 days (small test)"),
        ("examples/data/btcusdt_vision_90d.csv", "90 days (large validation)"),
        ("examples/data/btcusdt_vision_180d.csv", "180 days (full validation)"),
    ]
    
    print("📊 AVAILABLE VALIDATION DATASETS:")
    for i, (path, desc) in enumerate(datasets, 1):
        file_path = Path(path)
        if file_path.exists():
            size_mb = file_path.stat().st_size / (1024*1024)
            print(f"{i}. {desc} - {path} ({size_mb:.0f}MB)")
        else:
            print(f"{i}. {desc} - {path} (❌ NOT FOUND)")
    
    print(f"\n🚀 VALIDATION COMMANDS:")
    print("="*60)
    
    for i, (path, desc) in enumerate(datasets, 1):
        if Path(path).exists():
            print(f"\n{i}. {desc}:")
            print(f"   python strategies/validate_final_strategy.py {path}")
            print(f"   # Fast test (smaller windows):")
            print(f"   python strategies/validate_final_strategy.py {path} --is-days 3 --oos-days 1 --step-days 3")
    
    print(f"\n📋 MANUAL SINGLE RUN (for debugging):")
    print("="*60)
    params = config['final_parameters']
    print(f"python strategies/run_strategy.py {config['final_strategy']} \\")
    print(f"  --data examples/data/btcusdt_vision_7d.csv \\")
    print(f"  --bucket-ms {params['bucket_ms']} \\")
    print(f"  --output outputs/manual_validation_test")
    
    print(f"\n⚠️  IMPORTANT NOTES:")
    print("- Use DIFFERENT data than training (btcusdt_vision_30d.csv)")
    print("- Parameters are LOCKED - no optimization allowed")
    print("- Validation score >60% = PASS, <60% = FAIL")

if __name__ == '__main__':
    quick_validation_test()
