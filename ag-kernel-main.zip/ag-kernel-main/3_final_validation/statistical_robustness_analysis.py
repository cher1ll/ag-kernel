#!/usr/bin/env python3
"""
Statistical Robustness Analysis for H03B Strategy
Analyzes stability across different market regimes and time periods.
"""
import json
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import matplotlib.pyplot as plt

def load_all_h03b_results():
    """Load all H03B results from outputs directory."""
    outputs_dir = Path('outputs')
    results = []
    
    # Find all H03B bucket test directories
    for test_dir in outputs_dir.glob('bucket_test_*'):
        if not test_dir.is_dir():
            continue
            
        # Look for H03B results in each test
        for bucket_dir in test_dir.glob('h03b_bucket_*'):
            summary_file = bucket_dir / 'summary.json'
            if summary_file.exists():
                with open(summary_file) as f:
                    data = json.load(f)
                    data['test_dir'] = test_dir.name
                    data['bucket_dir'] = bucket_dir.name
                    results.append(data)
    
    return results

def analyze_performance_stability(results):
    """Analyze stability of performance across different datasets and periods."""
    
    # Group by bucket size
    by_bucket = {}
    for result in results:
        bucket_ms = result['bucket_ms']
        if bucket_ms not in by_bucket:
            by_bucket[bucket_ms] = []
        by_bucket[bucket_ms].append(result)
    
    stability_analysis = {}
    
    for bucket_ms, bucket_results in by_bucket.items():
        if len(bucket_results) < 2:
            continue
            
        # Extract key metrics
        sharpes = [r['avg_oos_sharpe'] for r in bucket_results]
        returns = [r['avg_oos_return'] for r in bucket_results]
        pfs = [r['avg_oos_pf'] for r in bucket_results]
        trades = [r['total_oos_trades'] for r in bucket_results]
        
        # Calculate stability metrics
        stability_analysis[bucket_ms] = {
            'num_tests': len(bucket_results),
            'sharpe_mean': np.mean(sharpes),
            'sharpe_std': np.std(sharpes),
            'sharpe_cv': np.std(sharpes) / np.mean(sharpes) if np.mean(sharpes) != 0 else float('inf'),
            'return_mean': np.mean(returns),
            'return_std': np.std(returns),
            'return_cv': np.std(returns) / np.mean(returns) if np.mean(returns) != 0 else float('inf'),
            'pf_mean': np.mean(pfs),
            'pf_std': np.std(pfs),
            'trades_mean': np.mean(trades),
            'trades_std': np.std(trades),
            'all_positive_sharpe': all(s > 0 for s in sharpes),
            'all_positive_return': all(r > 0 for r in returns),
            'all_mvs_pass': all(r.get('mvs_check', False) for r in bucket_results)
        }
    
    return stability_analysis

def analyze_market_regime_sensitivity(results):
    """Analyze sensitivity to different market conditions."""
    
    # Extract dataset information from test directory names
    regime_analysis = {}
    
    for result in results:
        test_name = result['test_dir']
        
        # Extract dataset period from name
        if '90d' in test_name:
            regime = '90d_medium'
        elif '180d' in test_name:
            regime = '180d_long'
        elif '365d' in test_name:
            regime = '365d_very_long'
        else:
            regime = 'unknown'
        
        if regime not in regime_analysis:
            regime_analysis[regime] = []
        
        regime_analysis[regime].append({
            'bucket_ms': result['bucket_ms'],
            'sharpe': result['avg_oos_sharpe'],
            'return': result['avg_oos_return'],
            'pf': result['avg_oos_pf'],
            'trades': result['total_oos_trades'],
            'mvs_pass': result.get('mvs_check', False)
        })
    
    return regime_analysis

def calculate_robustness_score(stability_analysis):
    """Calculate overall robustness score based on stability metrics."""
    
    scores = []
    
    for bucket_ms, stats in stability_analysis.items():
        if stats['num_tests'] < 2:
            continue
            
        # Stability score components (lower CV = more stable = higher score)
        sharpe_stability = max(0, 1 - stats['sharpe_cv']) if stats['sharpe_cv'] != float('inf') else 0
        return_stability = max(0, 1 - stats['return_cv']) if stats['return_cv'] != float('inf') else 0
        
        # Consistency score
        consistency_score = (
            (1 if stats['all_positive_sharpe'] else 0) * 0.4 +
            (1 if stats['all_positive_return'] else 0) * 0.4 +
            (1 if stats['all_mvs_pass'] else 0) * 0.2
        )
        
        # Performance score (normalized)
        performance_score = min(1, stats['sharpe_mean'] / 2.0)  # Normalize to 2.0 Sharpe
        
        # Combined score
        bucket_score = (
            sharpe_stability * 0.3 +
            return_stability * 0.3 +
            consistency_score * 0.2 +
            performance_score * 0.2
        )
        
        scores.append({
            'bucket_ms': bucket_ms,
            'score': bucket_score,
            'sharpe_stability': sharpe_stability,
            'return_stability': return_stability,
            'consistency': consistency_score,
            'performance': performance_score
        })
    
    return sorted(scores, key=lambda x: x['score'], reverse=True)

def analyze_parameter_sensitivity():
    """Analyze sensitivity to parameter changes (based on different bucket sizes)."""
    
    results = load_all_h03b_results()
    
    # Group by dataset to see parameter sensitivity within same market conditions
    by_dataset = {}
    for result in results:
        dataset = result['test_dir']
        if dataset not in by_dataset:
            by_dataset[dataset] = []
        by_dataset[dataset].append(result)
    
    sensitivity_analysis = {}
    
    for dataset, dataset_results in by_dataset.items():
        if len(dataset_results) < 2:
            continue
            
        # Sort by bucket size
        dataset_results.sort(key=lambda x: x['bucket_ms'])
        
        # Calculate sensitivity metrics
        bucket_sizes = [r['bucket_ms'] for r in dataset_results]
        sharpes = [r['avg_oos_sharpe'] for r in dataset_results]
        returns = [r['avg_oos_return'] for r in dataset_results]
        
        # Find optimal bucket and measure degradation
        best_sharpe_idx = np.argmax(sharpes)
        best_return_idx = np.argmax(returns)
        
        sensitivity_analysis[dataset] = {
            'bucket_sizes': bucket_sizes,
            'sharpes': sharpes,
            'returns': returns,
            'best_sharpe_bucket': bucket_sizes[best_sharpe_idx],
            'best_return_bucket': bucket_sizes[best_return_idx],
            'sharpe_range': max(sharpes) - min(sharpes),
            'return_range': max(returns) - min(returns),
            'parameter_sensitive': (max(sharpes) - min(sharpes)) > 0.5  # High sensitivity threshold
        }
    
    return sensitivity_analysis

def main():
    print("📊 STATISTICAL ROBUSTNESS ANALYSIS - H03B Strategy")
    print("="*80)
    
    # Load all results
    results = load_all_h03b_results()
    
    if not results:
        print("❌ No H03B results found in outputs directory")
        return
    
    print(f"📈 DATASET OVERVIEW")
    print("-"*80)
    print(f"Total H03B Results: {len(results)}")
    
    # Group by test directory
    by_test = {}
    for result in results:
        test = result['test_dir']
        if test not in by_test:
            by_test[test] = 0
        by_test[test] += 1
    
    for test, count in by_test.items():
        print(f"{test}: {count} bucket configurations")
    print("")
    
    # Analyze performance stability
    stability_analysis = analyze_performance_stability(results)
    
    print(f"🎯 PERFORMANCE STABILITY ANALYSIS")
    print("-"*80)
    print(f"{'Bucket':<12} {'Tests':<6} {'Sharpe':<15} {'Return':<15} {'Consistency':<12}")
    print(f"{'(ms)':<12} {'#':<6} {'Mean±Std(CV)':<15} {'Mean±Std(CV)':<15} {'Flags':<12}")
    print("-"*80)
    
    for bucket_ms in sorted(stability_analysis.keys()):
        stats = stability_analysis[bucket_ms]
        
        sharpe_str = f"{stats['sharpe_mean']:.2f}±{stats['sharpe_std']:.2f}({stats['sharpe_cv']:.2f})"
        return_str = f"{stats['return_mean']:.2f}±{stats['return_std']:.2f}({stats['return_cv']:.2f})"
        
        flags = ""
        if stats['all_positive_sharpe']:
            flags += "S+"
        if stats['all_positive_return']:
            flags += "R+"
        if stats['all_mvs_pass']:
            flags += "M+"
        
        print(f"{bucket_ms:<12} {stats['num_tests']:<6} {sharpe_str:<15} {return_str:<15} {flags:<12}")
    
    print("")
    
    # Market regime analysis
    regime_analysis = analyze_market_regime_sensitivity(results)
    
    print(f"🌍 MARKET REGIME SENSITIVITY")
    print("-"*80)
    
    for regime, regime_results in regime_analysis.items():
        print(f"\n{regime.upper()}:")
        
        # Group by bucket size within regime
        by_bucket = {}
        for r in regime_results:
            bucket = r['bucket_ms']
            if bucket not in by_bucket:
                by_bucket[bucket] = []
            by_bucket[bucket].append(r)
        
        for bucket_ms in sorted(by_bucket.keys()):
            bucket_results = by_bucket[bucket_ms][0]  # Should be only one per regime
            mvs_status = "✅" if bucket_results['mvs_pass'] else "❌"
            print(f"  {bucket_ms}ms: Sharpe={bucket_results['sharpe']:.2f}, "
                  f"Return={bucket_results['return']:+.2f}%, "
                  f"Trades={bucket_results['trades']}, MVS={mvs_status}")
    
    print("")
    
    # Parameter sensitivity
    sensitivity_analysis = analyze_parameter_sensitivity()
    
    print(f"⚙️  PARAMETER SENSITIVITY ANALYSIS")
    print("-"*80)
    
    for dataset, sens in sensitivity_analysis.items():
        sensitive_flag = "⚠️  HIGH" if sens['parameter_sensitive'] else "✅ LOW"
        print(f"{dataset}:")
        print(f"  Sharpe Range: {sens['sharpe_range']:.2f} (Best: {sens['best_sharpe_bucket']}ms)")
        print(f"  Return Range: {sens['return_range']:.2f}% (Best: {sens['best_return_bucket']}ms)")
        print(f"  Sensitivity: {sensitive_flag}")
        print("")
    
    # Overall robustness score
    robustness_scores = calculate_robustness_score(stability_analysis)
    
    print(f"🏆 OVERALL ROBUSTNESS RANKING")
    print("-"*80)
    print(f"{'Rank':<5} {'Bucket(ms)':<12} {'Score':<8} {'Stability':<10} {'Consistency':<12} {'Performance'}")
    print("-"*80)
    
    for i, score_data in enumerate(robustness_scores, 1):
        print(f"{i:<5} {score_data['bucket_ms']:<12} {score_data['score']:.3f}    "
              f"{score_data['sharpe_stability']:.2f}       "
              f"{score_data['consistency']:.2f}         "
              f"{score_data['performance']:.2f}")
    
    print("")
    
    # Final assessment
    if robustness_scores:
        best_config = robustness_scores[0]
        
        print(f"🎯 STATISTICAL ROBUSTNESS ASSESSMENT")
        print("-"*80)
        
        if best_config['score'] > 0.7:
            assessment = "✅ HIGHLY ROBUST"
            recommendation = "Strategy shows excellent statistical stability"
        elif best_config['score'] > 0.5:
            assessment = "⚠️  MODERATELY ROBUST"
            recommendation = "Strategy shows acceptable stability with some concerns"
        else:
            assessment = "❌ LOW ROBUSTNESS"
            recommendation = "Strategy shows poor statistical stability"
        
        print(f"Best Configuration: {best_config['bucket_ms']}ms")
        print(f"Robustness Score: {best_config['score']:.3f}")
        print(f"Assessment: {assessment}")
        print(f"Recommendation: {recommendation}")
        
        # Specific insights
        print(f"\n📋 KEY INSIGHTS:")
        print("-"*80)
        
        # Find most stable configuration
        most_stable = min(robustness_scores, key=lambda x: stability_analysis[x['bucket_ms']]['sharpe_cv'])
        print(f"✅ Most Stable: {most_stable['bucket_ms']}ms (CV: {stability_analysis[most_stable['bucket_ms']]['sharpe_cv']:.2f})")
        
        # Find highest performance
        highest_perf = max(robustness_scores, key=lambda x: x['performance'])
        print(f"🚀 Highest Performance: {highest_perf['bucket_ms']}ms (Score: {highest_perf['performance']:.2f})")
        
        # Check for regime dependency
        regime_dependent = any(sens['parameter_sensitive'] for sens in sensitivity_analysis.values())
        if regime_dependent:
            print("⚠️  Strategy shows high parameter sensitivity across market regimes")
        else:
            print("✅ Strategy shows consistent performance across market regimes")

if __name__ == "__main__":
    main()
