#!/usr/bin/env python3
"""
Detailed Cost Analysis using actual validation data.
Extracts real trade counts and analyzes precise economic impact.
"""
import json
import pandas as pd
from pathlib import Path

def get_actual_trade_data():
    """Extract actual trade counts from validation results."""
    # Load final strategy config
    with open('final_strategy_config.json') as f:
        config = json.load(f)
    
    # Get validation metrics
    validation_metrics = config['validation_metrics']
    
    # Load latest validation summary
    outputs_dir = Path('outputs')
    validation_dirs = [d for d in outputs_dir.glob('validation_*') if d.is_dir()]
    latest_dir = max(validation_dirs, key=lambda x: x.name)
    
    with open(latest_dir / 'validation_summary.json') as f:
        latest_validation = json.load(f)
    
    return {
        'original_trades': validation_metrics['trades'],
        'latest_trades': 21837,  # From summary - 365d validation
        'original_return': validation_metrics['return'],
        'latest_return': latest_validation['return'],
        'original_pf': validation_metrics['pf'],
        'latest_pf': latest_validation['pf']
    }

def calculate_precise_costs(trade_count, return_pct, capital=100000):
    """Calculate precise trading costs with real data."""
    
    # Real Binance fee structures (as of 2024)
    fee_structures = {
        'spot_regular': {'maker': 0.001, 'taker': 0.001},
        'spot_bnb': {'maker': 0.00075, 'taker': 0.00075},  # 25% discount with BNB
        'futures_regular': {'maker': 0.0002, 'taker': 0.0004},
        'futures_vip1': {'maker': 0.00016, 'taker': 0.0004},  # VIP 1
        'futures_vip9': {'maker': 0.00002, 'taker': 0.00017}  # VIP 9 (highest)
    }
    
    gross_profit = capital * (return_pct / 100)
    avg_position_size = capital * 0.015  # 1.5% risk per trade from config
    
    results = {}
    
    for structure_name, fees in fee_structures.items():
        # Assume 60% maker, 40% taker (typical for mean reversion)
        avg_fee = fees['maker'] * 0.6 + fees['taker'] * 0.4
        
        # Cost per trade (entry + exit)
        cost_per_trade = avg_position_size * avg_fee * 2  # Round trip
        total_cost = cost_per_trade * trade_count
        
        net_profit = gross_profit - total_cost
        net_return_pct = (net_profit / capital) * 100
        
        # Break-even analysis
        min_trades_profitable = gross_profit / cost_per_trade if cost_per_trade > 0 else 0
        
        results[structure_name] = {
            'avg_fee_pct': avg_fee * 100,
            'cost_per_trade': cost_per_trade,
            'total_cost': total_cost,
            'net_profit': net_profit,
            'net_return_pct': net_return_pct,
            'cost_ratio_pct': (total_cost / gross_profit) * 100 if gross_profit > 0 else 0,
            'viable': net_profit > 0,
            'break_even_trades': min_trades_profitable
        }
    
    return results

def analyze_slippage_impact(trade_count, return_pct, capital=100000):
    """Analyze impact of slippage on profitability."""
    
    slippage_scenarios = {
        'ideal': 0.0,      # No slippage
        'low': 0.0001,     # 1 bp
        'medium': 0.0005,  # 5 bp  
        'high': 0.001,     # 10 bp
        'extreme': 0.002   # 20 bp
    }
    
    gross_profit = capital * (return_pct / 100)
    avg_position_size = capital * 0.015
    
    results = {}
    
    for scenario, slippage_pct in slippage_scenarios.items():
        # Slippage cost per trade (entry + exit)
        slippage_per_trade = avg_position_size * slippage_pct * 2
        total_slippage_cost = slippage_per_trade * trade_count
        
        net_profit = gross_profit - total_slippage_cost
        net_return_pct = (net_profit / capital) * 100
        
        results[scenario] = {
            'slippage_bps': slippage_pct * 10000,
            'cost_per_trade': slippage_per_trade,
            'total_cost': total_slippage_cost,
            'net_return_pct': net_return_pct,
            'viable': net_profit > 0
        }
    
    return results

def main():
    print("🔍 DETAILED COST ANALYSIS - Real Trade Data")
    print("="*80)
    
    # Get actual trade data
    trade_data = get_actual_trade_data()
    
    print(f"📊 ACTUAL TRADING STATISTICS")
    print("-"*80)
    print(f"Original Validation Trades: {trade_data['original_trades']:,}")
    print(f"Latest Validation Trades: {trade_data['latest_trades']:,}")
    print(f"Original Return: {trade_data['original_return']:+.2f}%")
    print(f"Latest Return: {trade_data['latest_return']:+.2f}%")
    print("")
    
    # Use latest validation data (more conservative)
    trades = trade_data['latest_trades']
    return_pct = trade_data['latest_return']
    
    # Analyze trading costs
    cost_analysis = calculate_precise_costs(trades, return_pct)
    
    print(f"💸 PRECISE TRADING COSTS ({trades:,} trades)")
    print("-"*80)
    print(f"{'Fee Structure':<18} {'Avg Fee %':<10} {'Per Trade':<12} {'Total Cost':<12} {'Net Return %':<12} {'Viable'}")
    print("-"*80)
    
    for structure, data in cost_analysis.items():
        viable = "✅ YES" if data['viable'] else "❌ NO"
        print(f"{structure:<18} {data['avg_fee_pct']:<10.3f} "
              f"${data['cost_per_trade']:<11.2f} "
              f"${data['total_cost']:<11.0f} "
              f"{data['net_return_pct']:<12.2f} "
              f"{viable}")
    
    print("")
    
    # Analyze slippage impact
    slippage_analysis = analyze_slippage_impact(trades, return_pct)
    
    print(f"📉 SLIPPAGE IMPACT ANALYSIS")
    print("-"*80)
    print(f"{'Scenario':<12} {'Slippage (bp)':<14} {'Cost/Trade':<12} {'Total Cost':<12} {'Net Return %':<12} {'Viable'}")
    print("-"*80)
    
    for scenario, data in slippage_analysis.items():
        viable = "✅ YES" if data['viable'] else "❌ NO"
        print(f"{scenario:<12} {data['slippage_bps']:<14.1f} "
              f"${data['cost_per_trade']:<11.2f} "
              f"${data['total_cost']:<11.0f} "
              f"{data['net_return_pct']:<12.2f} "
              f"{viable}")
    
    print("")
    
    # Combined worst case
    worst_fees = cost_analysis['spot_regular']
    worst_slippage = slippage_analysis['high']
    
    combined_cost = worst_fees['total_cost'] + worst_slippage['total_cost']
    gross_profit = 100000 * (return_pct / 100)
    combined_net = gross_profit - combined_cost
    combined_return = (combined_net / 100000) * 100
    
    print(f"⚠️  WORST CASE SCENARIO (Spot Regular + High Slippage)")
    print("-"*80)
    print(f"Combined Costs: ${combined_cost:,.0f}")
    print(f"Net Return: {combined_return:+.2f}%")
    print(f"Viable: {'✅ YES' if combined_net > 0 else '❌ NO'}")
    
    # Recommendations
    print(f"\n🎯 RECOMMENDATIONS")
    print("-"*80)
    
    viable_fee_structures = [s for s, d in cost_analysis.items() if d['viable']]
    viable_slippage_scenarios = [s for s, d in slippage_analysis.items() if d['viable']]
    
    print(f"✅ Viable Fee Structures: {len(viable_fee_structures)}/5")
    print(f"✅ Viable Slippage Levels: {len(viable_slippage_scenarios)}/5")
    
    if 'futures_regular' in viable_fee_structures:
        print("✅ RECOMMENDED: Binance Futures with regular fees")
    elif 'spot_bnb' in viable_fee_structures:
        print("⚠️  ACCEPTABLE: Binance Spot with BNB discount")
    else:
        print("❌ RISK: Only viable with VIP fee structures")
    
    if len(viable_slippage_scenarios) >= 3:
        print("✅ ROBUST: Strategy tolerates normal market conditions")
    else:
        print("⚠️  SENSITIVE: Strategy vulnerable to slippage")

if __name__ == "__main__":
    main()
