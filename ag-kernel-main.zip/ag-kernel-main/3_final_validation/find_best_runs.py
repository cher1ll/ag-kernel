#!/usr/bin/env python3
"""
Find best results among multiple runs of the same strategy.
"""
import json
import glob
from pathlib import Path
from collections import defaultdict

def load_all_results():
    """Load all test results and group by strategy+period."""
    results = defaultdict(list)

    for summary_file in glob.glob('outputs/**/summary.json', recursive=True):
        path = Path(summary_file)
        
        try:
            with open(summary_file) as f:
                data = json.load(f)

            strategy = data.get('strategy', 'unknown')
            
            # Extract period from path
            parts = path.parent.name.split('_')
            period = parts[-1] if parts else 'unknown'
            
            result = {
                'path': str(path.parent),
                'strategy': strategy,
                'period': period,
                'pf': data.get('avg_oos_pf', 0),
                'return': data.get('avg_oos_return', 0),
                'sharpe': data.get('avg_oos_sharpe', 0),
                'max_dd': data.get('avg_oos_max_dd', 0),
                'trades': data.get('total_oos_trades', 0),
                'consistency': data.get('consistency', 0) * 100,
                'robustness': data.get('robustness_score', 0),
                'mvs': data.get('mvs_check', False),
                'bucket_ms': data.get('bucket_ms', 0)
            }
            
            key = f"{strategy}_{period}"
            results[key].append(result)
            
        except Exception as e:
            print(f"Error loading {summary_file}: {e}")

    return results

def find_best_runs(results, metric='sharpe'):
    """Find best run for each strategy+period combination."""
    best_runs = {}
    
    for key, runs in results.items():
        if not runs:
            continue
            
        # Filter out invalid results
        valid_runs = [r for r in runs if r[metric] != 0 and not (str(r[metric]) == 'nan')]
        
        if not valid_runs:
            continue
            
        # Find best by metric
        best = max(valid_runs, key=lambda x: x[metric])
        best_runs[key] = {
            'best': best,
            'total_runs': len(runs),
            'valid_runs': len(valid_runs)
        }
    
    return best_runs

def main():
    results = load_all_results()
    
    if not results:
        print("No results found.")
        return
    
    print("="*120)
    print("BEST RUNS BY SHARPE RATIO")
    print("="*120)
    
    best_by_sharpe = find_best_runs(results, 'sharpe')
    
    print(f"{'Strategy':<15} {'Period':<12} {'Runs':<6} {'Sharpe':<8} {'Return':<9} {'PF':<7} {'MaxDD':<8} {'MVS':<5} {'Path'}")
    print("-"*120)
    
    for key in sorted(best_by_sharpe.keys()):
        data = best_by_sharpe[key]
        r = data['best']
        mvs_icon = '✅' if r['mvs'] else '❌'
        
        print(f"{r['strategy']:<15} {r['period']:<12} {data['total_runs']:<6} "
              f"{r['sharpe']:<8.2f} {r['return']:+8.2f}% {r['pf']:<7.2f} "
              f"{r['max_dd']:<7.2f}% {mvs_icon:<5} {r['path']}")
    
    print("\n" + "="*120)
    print("BEST RUNS BY RETURN")
    print("="*120)
    
    best_by_return = find_best_runs(results, 'return')
    
    print(f"{'Strategy':<15} {'Period':<12} {'Runs':<6} {'Return':<9} {'Sharpe':<8} {'PF':<7} {'MaxDD':<8} {'MVS':<5}")
    print("-"*120)
    
    for key in sorted(best_by_return.keys()):
        data = best_by_return[key]
        r = data['best']
        mvs_icon = '✅' if r['mvs'] else '❌'
        
        print(f"{r['strategy']:<15} {r['period']:<12} {data['total_runs']:<6} "
              f"{r['return']:+8.2f}% {r['sharpe']:<8.2f} {r['pf']:<7.2f} "
              f"{r['max_dd']:<7.2f}% {mvs_icon:<5}")
    
    # Show strategies with multiple runs
    print("\n" + "="*120)
    print("STRATEGIES WITH MULTIPLE RUNS")
    print("="*120)
    
    multiple_runs = {k: v for k, v in results.items() if len(v) > 1}
    
    if multiple_runs:
        for key, runs in sorted(multiple_runs.items()):
            strategy, period = key.split('_', 1)
            print(f"\n{strategy} ({period}): {len(runs)} runs")
            
            # Show all runs sorted by Sharpe
            valid_runs = [r for r in runs if r['sharpe'] != 0 and not (str(r['sharpe']) == 'nan')]
            valid_runs.sort(key=lambda x: x['sharpe'], reverse=True)
            
            for i, r in enumerate(valid_runs[:5]):  # Top 5
                rank = "🥇" if i == 0 else "🥈" if i == 1 else "🥉" if i == 2 else f"{i+1}."
                print(f"  {rank} Sharpe={r['sharpe']:.2f}, Return={r['return']:+.2f}%, PF={r['pf']:.2f} - {r['path']}")
    else:
        print("No strategies with multiple runs found.")

if __name__ == '__main__':
    main()
