#!/usr/bin/env python3
"""
Economic Stress Test for H03B Strategy
Analyzes real-world trading costs and profitability under various fee scenarios.
"""
import json
import pandas as pd
import numpy as np
from pathlib import Path

def load_validation_results():
    """Load latest validation results."""
    outputs_dir = Path('outputs')
    validation_dirs = [d for d in outputs_dir.glob('validation_*') if d.is_dir()]
    
    if not validation_dirs:
        raise FileNotFoundError("No validation results found")
    
    latest_dir = max(validation_dirs, key=lambda x: x.name)
    
    with open(latest_dir / 'validation_summary.json') as f:
        return json.load(f)

def calculate_trading_costs(trades_count, avg_trade_size_usd=1000):
    """Calculate various trading cost scenarios."""
    scenarios = {
        'binance_spot': {'maker': 0.001, 'taker': 0.001},  # 0.1%
        'binance_futures': {'maker': 0.0002, 'taker': 0.0004},  # 0.02%/0.04%
        'high_volume': {'maker': 0.00005, 'taker': 0.0001},  # VIP rates
        'retail_worst': {'maker': 0.002, 'taker': 0.002}  # 0.2% worst case
    }
    
    results = {}
    
    for scenario_name, fees in scenarios.items():
        # Assume 50/50 maker/taker split
        avg_fee = (fees['maker'] + fees['taker']) / 2
        
        total_cost_usd = trades_count * avg_trade_size_usd * avg_fee
        cost_per_trade = avg_trade_size_usd * avg_fee
        
        results[scenario_name] = {
            'avg_fee_pct': avg_fee * 100,
            'cost_per_trade_usd': cost_per_trade,
            'total_cost_usd': total_cost_usd,
            'daily_cost_estimate': total_cost_usd / 365  # Assuming 1 year of data
        }
    
    return results

def analyze_trade_frequency_risk(trades_count, period_days):
    """Analyze risks from high trading frequency."""
    trades_per_day = trades_count / period_days
    trades_per_hour = trades_per_day / 24
    
    risk_levels = {
        'low': trades_per_hour < 1,
        'medium': 1 <= trades_per_hour < 5,
        'high': 5 <= trades_per_hour < 20,
        'extreme': trades_per_hour >= 20
    }
    
    current_risk = next(level for level, condition in risk_levels.items() if condition)
    
    return {
        'trades_per_day': trades_per_day,
        'trades_per_hour': trades_per_hour,
        'risk_level': current_risk,
        'ban_risk': current_risk in ['high', 'extreme'],
        'rate_limit_risk': current_risk in ['medium', 'high', 'extreme']
    }

def calculate_net_profitability(validation_data, cost_scenarios):
    """Calculate net profitability after costs."""
    gross_return_pct = validation_data['return']
    initial_capital = 100000  # Default from config
    gross_profit_usd = initial_capital * (gross_return_pct / 100)
    
    results = {}
    
    for scenario_name, costs in cost_scenarios.items():
        net_profit_usd = gross_profit_usd - costs['total_cost_usd']
        net_return_pct = (net_profit_usd / initial_capital) * 100
        
        profit_margin = (net_profit_usd / gross_profit_usd) * 100 if gross_profit_usd > 0 else 0
        
        results[scenario_name] = {
            'net_profit_usd': net_profit_usd,
            'net_return_pct': net_return_pct,
            'profit_margin_pct': profit_margin,
            'viable': net_profit_usd > 0,
            'cost_ratio': (costs['total_cost_usd'] / gross_profit_usd) * 100 if gross_profit_usd > 0 else float('inf')
        }
    
    return results

def main():
    print("💰 ECONOMIC STRESS TEST - H03B Strategy")
    print("="*80)
    
    # Load validation data
    validation_data = load_validation_results()
    
    print(f"Strategy: {validation_data['strategy'].upper()}")
    print(f"Gross Return: {validation_data['return']:+.2f}%")
    print(f"Sharpe Ratio: {validation_data['sharpe']:.2f}")
    print(f"Profit Factor: {validation_data['pf']:.2f}")
    print("")
    
    # Estimate trade count (need to get from actual results)
    # For now, use conservative estimate based on PF and return
    estimated_trades = int(validation_data['pf'] * 100)  # Rough estimate
    period_days = 365  # Assume 1 year validation
    
    print(f"📊 TRADING ACTIVITY ANALYSIS")
    print("-"*80)
    print(f"Estimated Trades: {estimated_trades}")
    print(f"Period: {period_days} days")
    
    # Analyze trading frequency risks
    frequency_risk = analyze_trade_frequency_risk(estimated_trades, period_days)
    
    print(f"Trades per Day: {frequency_risk['trades_per_day']:.1f}")
    print(f"Trades per Hour: {frequency_risk['trades_per_hour']:.2f}")
    print(f"Risk Level: {frequency_risk['risk_level'].upper()}")
    print(f"Ban Risk: {'⚠️  HIGH' if frequency_risk['ban_risk'] else '✅ LOW'}")
    print(f"Rate Limit Risk: {'⚠️  YES' if frequency_risk['rate_limit_risk'] else '✅ NO'}")
    print("")
    
    # Calculate trading costs
    cost_scenarios = calculate_trading_costs(estimated_trades)
    
    print(f"💸 TRADING COSTS ANALYSIS")
    print("-"*80)
    print(f"{'Scenario':<15} {'Fee %':<8} {'Per Trade':<12} {'Total Cost':<12} {'Daily Cost':<12}")
    print("-"*80)
    
    for scenario, costs in cost_scenarios.items():
        print(f"{scenario:<15} {costs['avg_fee_pct']:<8.3f} "
              f"${costs['cost_per_trade_usd']:<11.2f} "
              f"${costs['total_cost_usd']:<11.0f} "
              f"${costs['daily_cost_estimate']:<11.2f}")
    
    print("")
    
    # Calculate net profitability
    net_results = calculate_net_profitability(validation_data, cost_scenarios)
    
    print(f"📈 NET PROFITABILITY ANALYSIS")
    print("-"*80)
    print(f"{'Scenario':<15} {'Net Return %':<12} {'Profit Margin %':<15} {'Cost Ratio %':<12} {'Viable':<8}")
    print("-"*80)
    
    for scenario, results in net_results.items():
        viable_status = "✅ YES" if results['viable'] else "❌ NO"
        print(f"{scenario:<15} {results['net_return_pct']:<12.2f} "
              f"{results['profit_margin_pct']:<15.1f} "
              f"{results['cost_ratio']:<12.1f} "
              f"{viable_status:<8}")
    
    print("")
    
    # Summary and recommendations
    viable_scenarios = [s for s, r in net_results.items() if r['viable']]
    
    print(f"🎯 ECONOMIC VIABILITY SUMMARY")
    print("-"*80)
    print(f"Viable Scenarios: {len(viable_scenarios)}/4")
    print(f"Best Case (High Volume): {net_results['high_volume']['net_return_pct']:+.2f}%")
    print(f"Worst Case (Retail): {net_results['retail_worst']['net_return_pct']:+.2f}%")
    print(f"Recommended: {'Binance Futures' if net_results['binance_futures']['viable'] else 'High Volume Only'}")
    
    if frequency_risk['ban_risk']:
        print("⚠️  WARNING: High trading frequency may trigger exchange limits!")
    
    if len(viable_scenarios) < 2:
        print("⚠️  RISK: Strategy may not be economically viable under normal fee conditions!")

if __name__ == "__main__":
    main()
