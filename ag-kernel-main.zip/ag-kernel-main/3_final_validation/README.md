# Final Strategy Validation

This directory contains all scripts for final strategy selection and validation.

## 📋 Workflow

### 1. Strategy Selection Phase
```bash
# Compile all strategy results
python compile_all_results.py

# Find best runs among multiple executions  
python find_best_runs.py

# Select final strategy with comprehensive scoring
python select_final_strategy.py
```

### 2. Validation Phase
```bash
# Quick validation guide
python quick_validation_guide.py

# Validate on different datasets
python validate_final_strategy.py examples/data/btcusdt_vision_90d.csv
python validate_final_strategy.py examples/data/btcusdt_vision_180d.csv
python validate_final_strategy.py examples/data/btcusdt_vision_365d.csv

# Analyze return periods
python analyze_return_periods.py
```

## 📊 Files

- `compile_all_results.py` - Compile results from all strategy runs
- `find_best_runs.py` - Find best results among multiple runs
- `select_final_strategy.py` - Select final strategy with scoring
- `validate_final_strategy.py` - Validate final strategy on new data
- `quick_validation_guide.py` - Quick validation commands guide
- `analyze_return_periods.py` - Analyze what return percentages mean

## 🎯 Current Status

Final strategy selected: **H03B** with 10-minute buckets
- Sharpe: 1.07
- Return: +4.45% per 3-day period
- Profit Factor: 11.91
- Validation: ✅ PASSED on 90d and 180d datasets

## ⚠️ Important

- Parameters are LOCKED - no further optimization allowed
- Use only for validation on unseen data
- Results represent performance per OOS window (typically 3 days)
