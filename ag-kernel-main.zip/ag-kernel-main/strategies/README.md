# Strategy Testing

## Quick Start

```bash
# Single strategy
python strategies/run_strategy.py h03

# All strategies in parallel
./strategies/run_parallel.sh
```

## run_strategy.py

```bash
python strategies/run_strategy.py <strategy> [options]

Options:
  --data PATH        Data file (default: examples/data/btcusdt_vision_30d.csv)
  --bucket-ms MS     Tick aggregation: 60000=1min, 300000=5min (default: from strategy)
  --is-days N        In-sample days (default: 7)
  --oos-days N       Out-of-sample days (default: 3)
  --step-days N      Step between windows (default: 7)
```

Examples:
```bash
python strategies/run_strategy.py h03 --bucket-ms 300000      # 5-min buckets
python strategies/run_strategy.py h02 --is-days 5 --oos-days 2  # Quick test
```

## test_buckets.sh

Tests strategies with different bucket_ms values (1min, 2min, 5min, 10min):
```bash
./strategies/test_buckets.sh
```
