#!/bin/bash
# Оптимизированный параллельный запуск стратегий

set -euo pipefail

DATA_FILE="${1:-examples/data/btcusdt_vision_30d.csv}"
MAX_JOBS="${20:-$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 20)}"

get_period() {
    local file="$1"
    [[ "$file" =~ _([0-9]+d)\.csv ]] && echo "${BASH_REMATCH[1]}" || echo "unknown"
}

get_wfa_params() {
    local period="$1"
    local days=$(echo "$period" | sed 's/d//')
    
    if [[ "$days" =~ ^[0-9]+$ ]]; then
        if (( days <= 7 )); then
            echo "--is-days 3 --oos-days 1 --step-days 1"
        elif (( days <= 15 )); then
            echo "--is-days 3 --oos-days 2 --step-days 1"
        elif (( days <= 30 )); then
            echo "--is-days 5 --oos-days 3 --step-days 2"
        elif (( days <= 90 )); then
            echo "--is-days 7 --oos-days 3 --step-days 7"
        else
            echo "--is-days 14 --oos-days 7 --step-days 14"
        fi
    else
        echo "--is-days 7 --oos-days 3 --step-days 7"  # default
    fi
}

[[ -f "$DATA_FILE" ]] || { echo "Error: $DATA_FILE not found!"; exit 1; }

PERIOD=$(get_period "$DATA_FILE")
WFA_PARAMS=$(get_wfa_params "$PERIOD")
OUT_DIR="outputs/parallel_${PERIOD}_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT_DIR"

STRATEGIES=(h01 h02 h03 h03a h03b h03c h03d h03e h04 h07 h08 h09 h10 h11 h14 h15 h16 h17)

echo "=== Optimized Parallel Run ==="
echo "Data: $DATA_FILE ($PERIOD)"
echo "WFA: $WFA_PARAMS"
echo "Jobs: $MAX_JOBS cores"
echo "Strategies: ${#STRATEGIES[@]}"
echo ""

run_strategy() {
    local s="$1"
    local output="$OUT_DIR/${s}_${PERIOD}"
    
    printf "%-4s: Starting...\n" "$s"
    
    if result=$(.venv/bin/python strategies/run_strategy.py "$s" \
        --data "$DATA_FILE" --output "$output" $WFA_PARAMS 2>&1); then
        
        if [[ "$result" =~ RESULT:.*PF=([0-9.]+|nan).*Return=([+-]?[0-9.]+|nan)%.*Sharpe=([0-9.]+|nan).*Trades=([0-9]+) ]]; then
            printf "%-4s: ✓ PF=%s Return=%s%% Sharpe=%s Trades=%s\n" \
                "$s" "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}" "${BASH_REMATCH[4]}"
        else
            printf "%-4s: ✓ Completed\n" "$s"
        fi
    else
        printf "%-4s: ✗ Failed\n" "$s"
        echo "$result" > "$OUT_DIR/${s}_error.log"
    fi
}

export -f run_strategy
export DATA_FILE OUT_DIR PERIOD

# Параллельный запуск с ограничением по количеству процессов
printf '%s\n' "${STRATEGIES[@]}" | xargs -n1 -P"$MAX_JOBS" -I{} bash -c 'run_strategy "$@"' _ {}

echo ""
echo "✓ All strategies completed"
echo "Results: $OUT_DIR"
