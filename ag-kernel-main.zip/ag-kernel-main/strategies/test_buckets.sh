#!/bin/bash
# Test strategies with different bucket_ms values using run_strategy.py

DATA="${1:-examples/data/btcusdt_vision_90d.csv}"
STRATEGIES=("h03b")
BUCKETS=(600000 3600000 14400000 86400000)  # 10m 1h 4h 24h

# Создаем папку для результатов
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
DATA_NAME=$(basename "$DATA" .csv)
OUTPUT_DIR="outputs/bucket_test_${DATA_NAME}_${TIMESTAMP}"

# Создаем лог файл
mkdir -p "$OUTPUT_DIR"
LOG_FILE="$OUTPUT_DIR/execution.log"

echo "=== Parallel Bucket Size Test (using run_strategy.py) ===" | tee "$LOG_FILE"
echo "Strategies: ${STRATEGIES[*]}" | tee -a "$LOG_FILE"
echo "Buckets: ${BUCKETS[*]} ms" | tee -a "$LOG_FILE"
echo "Output: $OUTPUT_DIR" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

for s in "${STRATEGIES[@]}"; do
    echo "--- $s ---" | tee -a "$LOG_FILE"
    echo "Running bucket analysis..." | tee -a "$LOG_FILE"
    
    # Используем run_strategy.py для bucket анализа
    .venv/bin/python strategies/run_strategy.py "$s" \
        --data "$DATA" \
        --bucket-analysis \
        --buckets "${BUCKETS[@]}" \
        --output "$OUTPUT_DIR" \
        --is-days 5 \
        --oos-days 2 \
        --step-days 7 2>&1 | tee -a "$LOG_FILE"
    
    echo "" | tee -a "$LOG_FILE"
done

echo "=== Summary ===" | tee -a "$LOG_FILE"
echo "All tests completed. Results in: $OUTPUT_DIR" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"
echo "Generated files:" | tee -a "$LOG_FILE"
echo "  • {strategy}_bucket_{size}ms/wfa_results.json - Full WFA results" | tee -a "$LOG_FILE"
echo "  • {strategy}_bucket_{size}ms/summary.json - Key metrics summary" | tee -a "$LOG_FILE"
echo "  • {strategy}_bucket_comparison.json - Comparison across buckets" | tee -a "$LOG_FILE"
echo "  • execution.log - Full execution log" | tee -a "$LOG_FILE"
