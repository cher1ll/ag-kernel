#!/usr/bin/env python3
"""Test H01 with single parameter combination"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).parent.parent / "python"))

from hypotheses.h01_bollinger_reversion import BollingerReversionStrategy
from framework.backtest_engine import BacktestEngine
from framework.metrics import calculate_basic_metrics

def main():
    print("Testing H01 with single params...")

    strategy = BollingerReversionStrategy()
    data_path = 'examples/data/btcusdt_vision_30d.csv'

    # Use backtest engine directly (non-WFA)
    engine_bt = BacktestEngine(data_path)
    engine_bt.load_data()

    # Aggregate ticks
    print(f"Aggregating ticks...")
    engine_bt.aggregate_ticks(bucket_ms=5000)
    print(f"  Generated {len(engine_bt.ticks)} ticks")

    # Init engine
    engine_bt.init_engine()
    print(f"  Engine initialized")

    # Run strategy
    params = strategy.get_default_params()
    print(f"  Running strategy with params: {params}")

    result = engine_bt.run_strategy(
        strategy.generate_logic(),
        params
    )

    # Calculate metrics
    metrics = calculate_basic_metrics(result['trades_log'], result['snapshots'])

    print(f"\n{'='*60}")
    print("RESULTS")
    print(f"{'='*60}")
    print(f"Snapshots: {len(result['snapshots'])}")
    if result['snapshots']:
        print(f"  Initial equity: ${result['snapshots'][0].equity:,.2f}")
        print(f"  Final equity: ${result['snapshots'][-1].equity:,.2f}")
    print(f"Trades (log): {metrics['total_trades']}")
    print(f"Profit Factor: {metrics['profit_factor']:.2f}")
    print(f"Return: {metrics['return_pct']:.2f}%")
    print(f"Sharpe: {metrics['sharpe_ratio']:.2f}")
    print(f"{'='*60}")

if __name__ == '__main__':
    main()
