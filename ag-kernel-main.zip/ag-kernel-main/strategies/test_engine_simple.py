#!/usr/bin/env python3
"""Simple test to check if Engine processes orders correctly"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "python"))

from ag_backtester import Engine, EngineConfig
from ag_backtester.engine import Tick, Order

def test_simple_trade():
    """Test that Engine processes a simple buy-sell correctly"""

    # Create engine
    config = EngineConfig(
        initial_cash=100_000.0,
        tick_size=0.01,
        maker_fee=0.0001,
        taker_fee=0.0002,
        spread_bps=0.0
    )
    engine = Engine(config)

    print(f"Initial state:")
    snap0 = engine.get_snapshot()
    print(f"  Cash: ${snap0.cash:,.2f}")
    print(f"  Position: {snap0.position}")
    print(f"  Equity: ${snap0.equity:,.2f}")

    # Create some ticks
    price_btc = 100_000.0  # $100k BTC
    tick_size = 0.01
    price_ticks = int(price_btc / tick_size)

    # Tick 1: BUY at $100k
    tick1 = Tick(
        ts_ms=1000,
        price_tick_i64=price_ticks,
        qty=1.0,
        side='BUY'
    )
    engine.step_tick(tick1)

    # Place BUY order for 0.1 BTC
    print(f"\nPlacing BUY order: 0.1 BTC at ${price_btc:,.0f}")
    engine.place_order(Order(
        order_type='MARKET',
        side='BUY',
        qty=0.1
    ))

    # Step a few more ticks
    for i in range(2, 5):
        tick = Tick(
            ts_ms=i*1000,
            price_tick_i64=price_ticks,
            qty=1.0,
            side='BUY'
        )
        engine.step_tick(tick)

    snap1 = engine.get_snapshot()
    print(f"\nAfter BUY:")
    print(f"  Cash: ${snap1.cash:,.2f}")
    print(f"  Position: {snap1.position} BTC")
    print(f"  Avg Entry: ${snap1.avg_entry_price:,.2f}")
    print(f"  Equity: ${snap1.equity:,.2f}")

    # Sell at higher price
    new_price = 101_000.0  # +$1k
    new_price_ticks = int(new_price / tick_size)

    tick5 = Tick(
        ts_ms=5000,
        price_tick_i64=new_price_ticks,
        qty=1.0,
        side='SELL'
    )
    engine.step_tick(tick5)

    print(f"\nPlacing SELL order: 0.1 BTC at ${new_price:,.0f}")
    engine.place_order(Order(
        order_type='MARKET',
        side='SELL',
        qty=0.1
    ))

    # Step more ticks
    for i in range(6, 10):
        tick = Tick(
            ts_ms=i*1000,
            price_tick_i64=new_price_ticks,
            qty=1.0,
            side='SELL'
        )
        engine.step_tick(tick)

    snap2 = engine.get_snapshot()
    print(f"\nAfter SELL:")
    print(f"  Cash: ${snap2.cash:,.2f}")
    print(f"  Position: {snap2.position} BTC")
    print(f"  Realized PnL: ${snap2.realized_pnl:,.2f}")
    print(f"  Equity: ${snap2.equity:,.2f}")

    # Check results
    snapshots = engine.get_history()
    print(f"\n{'='*50}")
    print(f"Total snapshots: {len(snapshots)}")
    print(f"Initial equity: ${snapshots[0].equity:,.2f}")
    print(f"Final equity: ${snapshots[-1].equity:,.2f}")
    print(f"Return: {(snapshots[-1].equity / snapshots[0].equity - 1) * 100:.2f}%")
    print(f"{'='*50}")

    if snapshots[-1].equity > snapshots[0].equity:
        print("✅ SUCCESS: Equity increased!")
    else:
        print("❌ FAIL: Equity did not change!")


if __name__ == '__main__':
    test_simple_trade()
