#!/usr/bin/env python3
"""
Quick test of WFA on a single hypothesis.
Uses 30-day data for speed.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from framework import WalkForwardAnalyzer
from hypotheses.h01_bollinger_reversion import BollingerReversionStrategy

def main():
    print("="*60)
    print("QUICK WFA TEST - H01 BOLLINGER REVERSION")
    print("="*60)

    # Use 30-day data for quick test
    data_path = 'examples/data/btcusdt_vision_30d.csv'

    strategy = BollingerReversionStrategy()

    print(f"\nStrategy: {strategy.get_name()}")
    print(f"Data: {data_path}")
    print(f"Parameters to optimize: {strategy.get_param_grid()}")

    # Initialize WFA with small windows for quick test
    wfa = WalkForwardAnalyzer(
        data_path=data_path,
        is_days=15,  # Smaller for quick test
        oos_days=7,
        step_days=5
    )

    wfa.prepare_windows()

    # Run WFA
    results = wfa.run_full_wfa(
        strategy_logic=strategy.generate_logic(),
        param_grid=strategy.get_param_grid(),
        bucket_ms=strategy.get_default_params()['bucket_ms']
    )

    # Save results
    wfa.save_results(results, 'outputs/wfa_test_h01.json')

    print("\nTest complete!")
    print(f"Robustness Score: {results['summary']['robustness_score']:.2f}")
    print(f"MVS Pass: {results['summary']['mvs_check']['passes']}")


if __name__ == '__main__':
    main()
