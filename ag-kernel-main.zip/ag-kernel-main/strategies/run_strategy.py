#!/usr/bin/env python3
"""Run single strategy WFA with optional bucket analysis."""
import sys
import argparse
import json
import numpy as np
from pathlib import Path
from datetime import datetime
sys.path.insert(0, 'strategies')

from framework import WalkForwardAnalyzer
from hypotheses.batch_strategies import get_batch_strategy, BATCH_STRATEGIES

def run_single_strategy(strategy_name, data_path, is_days, oos_days, step_days, bucket_ms, output_dir=None, generate_tearsheet_flag=True):
    """Run WFA for a single strategy and bucket size."""
    strategy = get_batch_strategy(strategy_name)
    
    if bucket_ms is None:
        bucket_ms = strategy.get_default_params().get('bucket_ms', 60000)
    
    # Print configuration details
    bucket_hours = bucket_ms / 3600000
    bucket_mins = bucket_ms / 60000
    
    print(f"=== Strategy Configuration ===")
    print(f"Strategy: {strategy_name} ({strategy.get_name()})")
    print(f"Data: {data_path}")
    print(f"Bucket: {bucket_ms}ms ({bucket_hours:.1f}h / {bucket_mins:.0f}min)")
    print(f"WFA: IS={is_days}d, OOS={oos_days}d, Step={step_days}d")
    if output_dir:
        print(f"Output: {output_dir}")
    print("")
    
    wfa = WalkForwardAnalyzer(data_path, is_days=is_days, oos_days=oos_days, step_days=step_days)
    wfa.prepare_windows()
    results = wfa.run_full_wfa(
        strategy_logic=strategy.generate_logic(),
        param_grid=strategy.get_param_grid(),
        bucket_ms=bucket_ms
    )
    
    summary = results['summary']
    
    # Enhanced result output
    print(f"\n=== Final Results ===")
    print(f"Strategy: {strategy_name} | Bucket: {bucket_ms}ms ({bucket_hours:.1f}h)")
    print(f"Profit Factor: {summary['avg_oos_pf']:.2f}")
    print(f"Return: {summary['avg_oos_return']:+.2f}%")
    print(f"Sharpe Ratio: {summary['avg_oos_sharpe']:.2f}")
    print(f"Max Drawdown: {summary['avg_oos_max_dd']:.1f}%")
    print(f"Total Trades: {summary['total_oos_trades']}")
    print(f"Consistency: {summary['consistency']*100:.0f}% ({summary['num_windows']} windows)")
    print(f"Robustness: {summary['robustness_score']:.2f}")
    print(f"MVS Check: {'PASS' if summary['mvs_check']['passes'] else 'FAIL'}")
    
    # Save results if output directory specified
    if output_dir:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Save full WFA results
        with open(output_path / 'wfa_results.json', 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        # Save summary
        bucket_summary = {
            'strategy': strategy_name,
            'strategy_name': strategy.get_name(),
            'bucket_ms': bucket_ms,
            'bucket_hours': bucket_hours,
            'bucket_minutes': bucket_mins,
            'data_path': data_path,
            'wfa_config': {
                'is_days': is_days,
                'oos_days': oos_days,
                'step_days': step_days,
                'num_windows': summary['num_windows']
            },
            'avg_oos_pf': summary['avg_oos_pf'],
            'avg_oos_return': summary['avg_oos_return'],
            'avg_oos_sharpe': summary['avg_oos_sharpe'],
            'avg_oos_max_dd': summary['avg_oos_max_dd'],
            'total_oos_trades': summary['total_oos_trades'],
            'consistency': summary['consistency'],
            'robustness_score': summary['robustness_score'],
            'mvs_check': summary['mvs_check']['passes'],
            'timestamp': datetime.now().isoformat()
        }
        
        with open(output_path / 'summary.json', 'w') as f:
            json.dump(bucket_summary, f, indent=2)
        
        # Generate tearsheet from WFA results
        if generate_tearsheet_flag:
            try:
                print("Generating tearsheet...")
                generate_wfa_tearsheet(results, output_path / 'report.png', strategy_name, bucket_ms)
                print("✓ Tearsheet generated")
            except Exception as e:
                print(f"⚠ Tearsheet generation failed: {e}")
        else:
            print("Tearsheet generation skipped")
        
        print(f"Results saved to: {output_dir}")
    
    return results, summary

def generate_wfa_tearsheet(wfa_results, output_path, strategy_name, bucket_ms):
    """
    Generate tearsheet from WFA results using approximated equity curve.
    
    Note: Since WFA returns only aggregated metrics, this creates an approximated
    equity curve based on window returns. This is for visualization purposes only
    and may not reflect the actual tick-by-tick performance.
    """
    import pandas as pd
    import numpy as np
    from ag_backtester.viz.tearsheet import generate_tearsheet
    
    summary = wfa_results['summary']
    windows = wfa_results.get('windows', [])
    
    if not windows:
        raise ValueError("No window data available for tearsheet")
    
    print("⚠️  Note: Creating approximated equity curve from WFA window results")
    print("   This is for visualization only and may not reflect actual performance")
    
    # Create approximated equity curve from window results
    snapshots = []
    all_trades = []
    
    current_equity = 100000.0  # Starting equity
    current_time = pd.Timestamp.now().timestamp()
    time_step = 86400  # 1 day in seconds
    
    # Add initial snapshot
    snapshots.append({
        'timestamp': current_time,
        'equity': current_equity,
        'cash': current_equity,
        'position': 0.0
    })
    
    trade_id = 0
    
    for i, window in enumerate(windows):
        oos_metrics = window.get('oos_metrics', {})
        
        # Calculate window return
        window_return = oos_metrics.get('return_pct', 0) / 100
        window_trades = oos_metrics.get('total_trades', 0)
        
        # Approximate equity progression over window period
        window_days = 7  # Approximate window duration
        daily_return = window_return / window_days if window_days > 0 else 0
        
        for day in range(window_days):
            current_time += time_step
            
            # Add realistic volatility based on strategy performance
            daily_vol = min(0.02, abs(daily_return) * 2)  # Cap volatility at 2%
            noise = np.random.normal(0, daily_vol)
            day_return = daily_return + noise * 0.5  # Reduce noise impact
            
            current_equity *= (1 + day_return)
            
            snapshots.append({
                'timestamp': current_time,
                'equity': current_equity,
                'cash': current_equity * 0.8,  # Assume 80% cash, 20% position
                'position': current_equity * 0.2
            })
            
            # Add approximated trades based on window metrics
            if window_trades > 0 and day % 3 == 0:  # Every 3rd day
                trade_pnl = (current_equity - snapshots[-2]['equity']) if len(snapshots) > 1 else 0
                
                # Estimate trade price based on typical crypto prices
                base_price = 45000 + i * 1000  # Varying base price
                trade_price = base_price + np.random.normal(0, 500)
                
                all_trades.append({
                    'timestamp': current_time,
                    'side': 'buy' if trade_pnl > 0 else 'sell',
                    'price': trade_price,
                    'pnl': trade_pnl,
                    'qty': 0.1
                })
                trade_id += 1
    
    # Generate tearsheet with approximated data
    generate_tearsheet(
        snapshots=snapshots,
        trades=all_trades,
        output_path=str(output_path)
    )
    
    # Save equity curve with disclaimer
    equity_df = pd.DataFrame(snapshots)
    equity_df['datetime'] = pd.to_datetime(equity_df['timestamp'], unit='s')
    
    # Add disclaimer to CSV
    disclaimer = pd.DataFrame([{
        'timestamp': 0,
        'equity': 0,
        'cash': 0,
        'position': 0,
        'datetime': 'DISCLAIMER: This is an approximated equity curve based on WFA window results'
    }])
    
    final_df = pd.concat([disclaimer, equity_df], ignore_index=True)
    final_df.to_csv(output_path.parent / 'equity_approximated.csv', index=False)

def run_bucket_analysis(strategy_name, data_path, is_days, oos_days, step_days, buckets, output_dir, generate_tearsheet_flag=True):
    """Run bucket analysis for multiple bucket sizes."""
    print(f"=== Bucket Analysis for {strategy_name} ===")
    print(f"Data: {data_path}")
    print(f"WFA Config: IS={is_days}d, OOS={oos_days}d, Step={step_days}d")
    print(f"Buckets: {buckets} ms")
    bucket_hours = [f"{b/3600000:.1f}h" for b in buckets]
    print(f"Timeframes: {bucket_hours}")
    print(f"Output: {output_dir}")
    print("")
    
    results = {}
    
    for bucket_ms in buckets:
        bucket_hours = bucket_ms / 3600000
        bucket_mins = bucket_ms / 60000
        print(f"--- Testing {bucket_ms}ms ({bucket_hours:.1f}h / {bucket_mins:.0f}min) ---")
        
        bucket_output_dir = Path(output_dir) / f"{strategy_name}_bucket_{bucket_ms}ms"
        
        try:
            wfa_results, summary = run_single_strategy(
                strategy_name, data_path, is_days, oos_days, step_days, 
                bucket_ms, bucket_output_dir, generate_tearsheet_flag
            )
            
            results[bucket_ms] = summary
            
            print(f"✓ {bucket_ms}ms: PF={summary['avg_oos_pf']:.2f} Return={summary['avg_oos_return']:+.2f}% "
                  f"Sharpe={summary['avg_oos_sharpe']:.2f} DD={summary['avg_oos_max_dd']:.1f}% "
                  f"Trades={summary['total_oos_trades']} Consistency={summary['consistency']*100:.0f}%")
        
        except Exception as e:
            print(f"✗ {bucket_ms}ms: ERROR - {e}")
            results[bucket_ms] = {'error': str(e)}
        
        print("")
    
    # Save comparison results
    comparison_file = Path(output_dir) / f"{strategy_name}_bucket_comparison.json"
    with open(comparison_file, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    # Print summary table
    print("=== Bucket Comparison Summary ===")
    print(f"{'Bucket':<12} {'Timeframe':<10} {'PF':<6} {'Return':<8} {'Sharpe':<7} {'DD':<6} {'Trades':<7} {'Consistency':<11}")
    print("-" * 80)
    
    for bucket_ms in sorted(buckets):
        if bucket_ms in results and 'error' not in results[bucket_ms]:
            s = results[bucket_ms]
            bucket_hours = bucket_ms / 3600000
            print(f"{bucket_ms:<12} {bucket_hours:<10.1f}h {s['avg_oos_pf']:<6.2f} {s['avg_oos_return']:<+8.1f}% "
                  f"{s['avg_oos_sharpe']:<7.2f} {s['avg_oos_max_dd']:<6.1f}% {s['total_oos_trades']:<7} "
                  f"{s['consistency']*100:<11.0f}%")
        else:
            bucket_hours = bucket_ms / 3600000
            print(f"{bucket_ms:<12} {bucket_hours:<10.1f}h ERROR")
    
    print(f"\nBucket analysis complete. Results saved to: {output_dir}")
    return results

def main():
    p = argparse.ArgumentParser(description="Run strategy WFA with optional bucket analysis")
    p.add_argument('strategy', choices=list(BATCH_STRATEGIES.keys()), help='Strategy to run')
    p.add_argument('--data', default='examples/data/btcusdt_vision_30d.csv', help='Data file path')
    p.add_argument('--is-days', type=int, default=7, help='In-sample days')
    p.add_argument('--oos-days', type=int, default=3, help='Out-of-sample days')
    p.add_argument('--step-days', type=int, default=7, help='Step days')
    p.add_argument('--bucket-ms', type=int, default=None, help='Single bucket size in ms')
    p.add_argument('--bucket-analysis', action='store_true', help='Run bucket analysis with multiple sizes')
    p.add_argument('--buckets', nargs='+', type=int, 
                   default=[600000, 3600000, 14400000, 86400000],
                   help='Bucket sizes for analysis (ms)')
    p.add_argument('--output', help='Output directory for results')
    p.add_argument('--quiet', action='store_true', help='Only print final result')
    p.add_argument('--no-tearsheet', action='store_true', help='Skip tearsheet generation')
    
    args = p.parse_args()
    
    # Generate output directory if not specified
    if args.output is None and (args.bucket_analysis or args.bucket_ms):
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        if args.bucket_analysis:
            args.output = f"outputs/bucket_analysis_{args.strategy}_{timestamp}"
        else:
            args.output = f"outputs/strategy_{args.strategy}_{timestamp}"
    
    if args.bucket_analysis:
        # Run bucket analysis
        run_bucket_analysis(
            args.strategy, args.data, args.is_days, args.oos_days, 
            args.step_days, args.buckets, args.output, not args.no_tearsheet
        )
    else:
        # Run single strategy
        results, summary = run_single_strategy(
            args.strategy, args.data, args.is_days, args.oos_days, 
            args.step_days, args.bucket_ms, args.output, not args.no_tearsheet
        )
        
        if not args.quiet:
            # Enhanced console output
            bucket_hours = args.bucket_ms / 3600000 if args.bucket_ms else summary.get('bucket_ms', 60000) / 3600000
            bucket_ms_used = args.bucket_ms or summary.get('bucket_ms', 60000)
            
            print(f"\n=== FINAL RESULT ===")
            print(f"Strategy: {args.strategy} | Bucket: {bucket_ms_used}ms ({bucket_hours:.1f}h)")
            print(f"RESULT: PF={summary['avg_oos_pf']:.2f} Return={summary['avg_oos_return']:.2f}% "
                  f"Sharpe={summary['avg_oos_sharpe']:.2f} DD={summary['avg_oos_max_dd']:.1f}% "
                  f"Trades={summary['total_oos_trades']} Consistency={summary['consistency']*100:.0f}%")
        else:
            # Quiet mode - just the result line for parsing
            bucket_ms_used = args.bucket_ms or summary.get('bucket_ms', 60000)
            bucket_hours = bucket_ms_used / 3600000
            print(f"RESULT: PF={summary['avg_oos_pf']:.2f} Return={summary['avg_oos_return']:.2f}% "
                  f"Sharpe={summary['avg_oos_sharpe']:.2f} Trades={summary['total_oos_trades']} "
                  f"Bucket={bucket_ms_used}ms({bucket_hours:.1f}h)")
        
        if args.output:
            print(f"Results saved to: {args.output}")

if __name__ == '__main__':
    main()
