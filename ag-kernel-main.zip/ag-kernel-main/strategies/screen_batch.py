#!/usr/bin/env python3
"""
Fast screening of all batch strategies.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from framework import WalkForwardAnalyzer
from hypotheses.batch_strategies import BATCH_STRATEGIES, get_batch_strategy


def screen_all_strategies(data_path: str, is_days: int = 7, oos_days: int = 3, step_days: int = 7):
    """Screen all batch strategies on given data."""
    
    print(f"\n{'='*70}")
    print(f"FAST STRATEGY SCREENING")
    print(f"{'='*70}")
    print(f"Data: {data_path}")
    print(f"WFA: IS={is_days}d, OOS={oos_days}d, Step={step_days}d")
    print(f"Strategies: {list(BATCH_STRATEGIES.keys())}")
    
    results = {}
    total_start = time.time()
    
    for name, strategy_cls in BATCH_STRATEGIES.items():
        print(f"\n{'─'*70}")
        print(f"Testing {name.upper()}...")
        
        strategy = strategy_cls()
        wfa = WalkForwardAnalyzer(data_path, is_days=is_days, oos_days=oos_days, step_days=step_days)
        wfa.prepare_windows()
        
        start = time.time()
        try:
            wfa_results = wfa.run_full_wfa(
                strategy_logic=strategy.generate_logic(),
                param_grid=strategy.get_param_grid(),
                bucket_ms=strategy.get_default_params().get('bucket_ms', 5000)
            )
            elapsed = time.time() - start
            
            results[name] = {
                'time': elapsed,
                'avg_oos_pf': wfa_results['summary']['avg_oos_pf'],
                'avg_oos_return': wfa_results['summary']['avg_oos_return'],
                'avg_oos_sharpe': wfa_results['summary']['avg_oos_sharpe'],
                'total_trades': wfa_results['summary']['total_oos_trades'],
                'consistency': wfa_results['summary']['consistency'],
                'mvs_pass': wfa_results['summary']['mvs_check']['passes']
            }
            
            print(f"  ✓ {name}: PF={results[name]['avg_oos_pf']:.2f}, Return={results[name]['avg_oos_return']:.2f}%, Time={elapsed:.1f}s")
            
        except Exception as e:
            print(f"  ✗ {name} failed: {e}")
            results[name] = {'error': str(e)}
    
    total_time = time.time() - total_start
    
    # Summary
    print(f"\n{'='*70}")
    print(f"SCREENING RESULTS (Total: {total_time:.1f}s)")
    print(f"{'='*70}")
    print(f"{'Strategy':<12} {'PF':>8} {'Return':>10} {'Sharpe':>8} {'Trades':>8} {'Time':>8}")
    print(f"{'─'*70}")
    
    for name, r in sorted(results.items(), key=lambda x: x[1].get('avg_oos_pf', 0), reverse=True):
        if 'error' in r:
            print(f"{name:<12} {'ERROR':>8}")
        else:
            print(f"{name:<12} {r['avg_oos_pf']:>8.2f} {r['avg_oos_return']:>9.2f}% {r['avg_oos_sharpe']:>8.2f} {r['total_trades']:>8} {r['time']:>7.1f}s")
    
    return results


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='examples/data/btcusdt_vision_30d.csv')
    parser.add_argument('--is-days', type=int, default=7)
    parser.add_argument('--oos-days', type=int, default=3)
    parser.add_argument('--step-days', type=int, default=7)
    args = parser.parse_args()
    
    screen_all_strategies(args.data, args.is_days, args.oos_days, args.step_days)
