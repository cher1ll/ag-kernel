#!/bin/bash
# Запуск стратегий для конкретного периода

PERIOD="${1:-90d}"
DATA_FILE="examples/data/btcusdt_vision_${PERIOD}.csv"

if [[ ! -f "$DATA_FILE" ]]; then
    echo "Error: Data file $DATA_FILE not found!"
    echo "Available periods: 7d, 30d, 90d, 180d, 365d"
    exit 1
fi

echo "Running strategies for $PERIOD period..."
./strategies/run_parallel.sh "$DATA_FILE"
