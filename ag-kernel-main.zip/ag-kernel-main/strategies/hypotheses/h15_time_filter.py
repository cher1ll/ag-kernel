#!/usr/bin/env python3
"""
H15: Time-of-Day Filter Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H15TimeFilterBatch(BatchStrategy):
    """Time-of-Day Filter - Avoid low volatility hours (Asian session)"""
    
    def get_name(self) -> str:
        return "H15_Time_Filter"
    
    def get_default_params(self) -> Dict:
        return {'avoid_start': 0, 'avoid_end': 8, 'rsi_period': 14, 'oversold': 35, 'overbought': 65, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 60000}
    
    def get_param_grid(self) -> Dict:
        return {'avoid_start': [0], 'avoid_end': [6, 8], 'rsi_period': [14], 'oversold': [30, 35], 'overbought': [65, 70], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.rsi(df, params['rsi_period'])
        df['hour'] = pd.to_datetime(df['timestamp'], unit='ms').dt.hour
        # Avoid Asian session (low liquidity)
        df['in_session'] = ~((df['hour'] >= params['avoid_start']) & (df['hour'] < params['avoid_end']))
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        os, ob = params['oversold'], params['overbought']
        buy_cond = df['in_session'] & (df['rsi'] < os)
        sell_cond = df['in_session'] & (df['rsi'] > ob)
        df.loc[buy_cond & ~buy_cond.shift(1).fillna(False), 'signal'] = 1
        df.loc[sell_cond & ~sell_cond.shift(1).fillna(False), 'signal'] = -1
        return df
