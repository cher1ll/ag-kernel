#!/usr/bin/env python3
"""
H08: Volume Breakout Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H08VolumeBreakoutBatch(BatchStrategy):
    """Volume Breakout - Breakout with volume confirmation"""
    
    def get_name(self) -> str:
        return "H08_Volume_Breakout"
    
    def get_default_params(self) -> Dict:
        return {'lookback': 50, 'vol_mult': 2.0, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 60000}
    
    def get_param_grid(self) -> Dict:
        return {'lookback': [30, 50, 100], 'vol_mult': [1.5, 2.0, 3.0], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        lb = params['lookback']
        df['high_n'] = df['price'].rolling(lb).max()
        df['low_n'] = df['price'].rolling(lb).min()
        df['vol_avg'] = df['qty'].rolling(lb).mean()
        df['vol_spike'] = df['qty'] > df['vol_avg'] * params['vol_mult']
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        # BUY: price breaks above recent high + volume spike
        buy_cond = (df['price'] >= df['high_n'].shift(1)) & df['vol_spike']
        df.loc[buy_cond & ~buy_cond.shift(1).fillna(False), 'signal'] = 1
        # SELL: price breaks below recent low + volume spike
        sell_cond = (df['price'] <= df['low_n'].shift(1)) & df['vol_spike']
        df.loc[sell_cond & ~sell_cond.shift(1).fillna(False), 'signal'] = -1
        return df
