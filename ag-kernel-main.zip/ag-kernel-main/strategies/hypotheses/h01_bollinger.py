#!/usr/bin/env python3
"""
H01: Bollinger Bands Mean Reversion Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H01BollingerBatch(BatchStrategy):
    """Bollinger Bands Mean Reversion"""
    
    def get_name(self) -> str:
        return "H01_Bollinger_Batch"
    
    def get_default_params(self) -> Dict:
        return {'bb_period': 20, 'bb_std': 2.0, 'risk_percent': 0.01, 'reward_ratio': 1.5, 'position_size': 0.05, 'bucket_ms': 60000}
    
    def get_param_grid(self) -> Dict:
        return {'bb_period': [15, 20, 30], 'bb_std': [1.5, 2.0, 2.5], 'risk_percent': [0.01, 0.015], 'reward_ratio': [1.5, 2.0], 'position_size': [0.05]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        return BatchIndicators.bollinger_bands(df, params['bb_period'], params['bb_std'])
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0

        # Edge detection: signal only on first tick of crossing
        # BUY: price crosses BELOW lower band (was above, now below)
        df['below_lower'] = df['price'] <= df['bb_lower']
        df['was_above_lower'] = df['price'].shift(1) > df['bb_lower'].shift(1)
        df.loc[df['below_lower'] & df['was_above_lower'], 'signal'] = 1

        # SELL: price crosses ABOVE upper band (was below, now above)
        df['above_upper'] = df['price'] >= df['bb_upper']
        df['was_below_upper'] = df['price'].shift(1) < df['bb_upper'].shift(1)
        df.loc[df['above_upper'] & df['was_below_upper'], 'signal'] = -1

        return df
