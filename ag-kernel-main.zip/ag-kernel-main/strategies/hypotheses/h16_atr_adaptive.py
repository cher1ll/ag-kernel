#!/usr/bin/env python3
"""
H16: ATR-Adaptive Stops Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H16ATRAdaptiveBatch(BatchStrategy):
    """ATR-Adaptive Stops - Dynamic SL/TP based on volatility"""
    
    def get_name(self) -> str:
        return "H16_ATR_Adaptive"
    
    def get_default_params(self) -> Dict:
        return {'atr_period': 14, 'sl_mult': 1.5, 'tp_mult': 3.0, 'rsi_period': 14, 'oversold': 35, 'overbought': 65, 'position_size': 0.05, 'bucket_ms': 60000}
    
    def get_param_grid(self) -> Dict:
        return {'atr_period': [14, 20], 'rsi_period': [14], 'oversold': [30, 35], 'overbought': [65, 70], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.atr(df, params['atr_period'])
        df = BatchIndicators.rsi(df, params['rsi_period'])
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        buy_cond = df['rsi'] < params.get('oversold', 30)
        sell_cond = df['rsi'] > params.get('overbought', 70)
        df.loc[buy_cond & ~buy_cond.shift(1).fillna(False), 'signal'] = 1
        df.loc[sell_cond & ~sell_cond.shift(1).fillna(False), 'signal'] = -1
        return df
