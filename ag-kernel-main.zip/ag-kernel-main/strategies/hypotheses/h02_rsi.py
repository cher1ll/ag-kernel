#!/usr/bin/env python3
"""
H02: RSI Extreme Reversal Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H02RSIBatch(BatchStrategy):
    """RSI Extreme Reversal"""
    
    def get_name(self) -> str:
        return "H02_RSI_Batch"
    
    def get_default_params(self) -> Dict:
        return {'rsi_period': 14, 'oversold': 30, 'overbought': 70, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 120000}
    
    def get_param_grid(self) -> Dict:
        return {'rsi_period': [10, 14, 20], 'oversold': [25, 30, 35], 'overbought': [65, 70, 75], 'risk_percent': [0.01, 0.015], 'reward_ratio': [1.5, 2.0], 'position_size': [0.05]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        return BatchIndicators.rsi(df, params['rsi_period'])
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0

        # Edge detection: signal only when crossing thresholds
        # BUY: RSI crosses below oversold level
        df['is_oversold'] = df['rsi'] < params['oversold']
        df['was_not_oversold'] = df['rsi'].shift(1) >= params['oversold']
        df.loc[df['is_oversold'] & df['was_not_oversold'], 'signal'] = 1

        # SELL: RSI crosses above overbought level
        df['is_overbought'] = df['rsi'] > params['overbought']
        df['was_not_overbought'] = df['rsi'].shift(1) <= params['overbought']
        df.loc[df['is_overbought'] & df['was_not_overbought'], 'signal'] = -1

        return df
