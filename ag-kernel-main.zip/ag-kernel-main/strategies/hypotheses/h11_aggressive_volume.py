#!/usr/bin/env python3
"""
H11: Aggressive Volume Ratio Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H11AggressiveVolumeBatch(BatchStrategy):
    """Aggressive Volume Ratio - Market order flow tracking"""
    
    def get_name(self) -> str:
        return "H11_Aggressive_Volume"
    
    def get_default_params(self) -> Dict:
        return {'lookback': 30, 'ratio_threshold': 0.6, 'risk_percent': 0.01, 'reward_ratio': 1.5, 'position_size': 0.02, 'bucket_ms': 120000}
    
    def get_param_grid(self) -> Dict:
        return {'lookback': [20, 30, 50], 'ratio_threshold': [0.58, 0.62, 0.66], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0], 'position_size': [0.02]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        lb = params['lookback']
        df['agg_buy'] = (df['qty'] * (1 - df['side'])).rolling(lb).sum()
        df['agg_sell'] = (df['qty'] * df['side']).rolling(lb).sum()
        df['total_vol'] = df['agg_buy'] + df['agg_sell']
        df['buy_ratio'] = df['agg_buy'] / df['total_vol']
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        t = params['ratio_threshold']
        buy_cond = df['buy_ratio'] > t
        df.loc[buy_cond & ~buy_cond.shift(1).fillna(False), 'signal'] = 1
        sell_cond = df['buy_ratio'] < (1 - t)
        df.loc[sell_cond & ~sell_cond.shift(1).fillna(False), 'signal'] = -1
        return df
