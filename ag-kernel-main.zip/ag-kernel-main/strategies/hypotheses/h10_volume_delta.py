#!/usr/bin/env python3
"""
H10: Volume Delta Momentum Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H10VolumeDeltaBatch(BatchStrategy):
    """Volume Delta Momentum"""
    
    def get_name(self) -> str:
        return "H10_VolumeDelta_Batch"
    
    def get_default_params(self) -> Dict:
        return {'delta_period': 20, 'delta_threshold': 0.6, 'risk_percent': 0.01, 'reward_ratio': 1.5, 'position_size': 0.02, 'bucket_ms': 120000}
    
    def get_param_grid(self) -> Dict:
        return {'delta_period': [20, 30, 50], 'delta_threshold': [0.55, 0.6, 0.65], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0], 'position_size': [0.02]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['buy_vol'] = df['qty'].where(df['side'] == 0, 0)
        df['sell_vol'] = df['qty'].where(df['side'] == 1, 0)
        df['delta'] = df['buy_vol'].rolling(params['delta_period']).sum() - df['sell_vol'].rolling(params['delta_period']).sum()
        df['total_vol'] = df['qty'].rolling(params['delta_period']).sum()
        df['delta_ratio'] = df['delta'] / df['total_vol']
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        t = params['delta_threshold']
        df['is_bullish'] = df['delta_ratio'] > t
        df['was_not_bullish'] = df['delta_ratio'].shift(1) <= t
        df.loc[df['is_bullish'] & df['was_not_bullish'], 'signal'] = 1
        df['is_bearish'] = df['delta_ratio'] < -t
        df['was_not_bearish'] = df['delta_ratio'].shift(1) >= -t
        df.loc[df['is_bearish'] & df['was_not_bearish'], 'signal'] = -1
        return df
