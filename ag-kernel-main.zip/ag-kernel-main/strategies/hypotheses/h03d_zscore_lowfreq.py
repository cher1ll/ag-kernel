#!/usr/bin/env python3
"""
H03D: Low-Frequency Z-Score Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
import numpy as np
from typing import Dict, List
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H03dZScoreLowFreqBatch(BatchStrategy):
    """H03D: Low-Frequency Z-Score Strategy - Addresses operational risk from high trade frequency"""
    
    def get_name(self) -> str:
        return "H03d_ZScore_LowFreq"
    
    def get_default_params(self) -> Dict:
        return {
            'ma_period': 100, 'z_base_threshold': 2.5, 'atr_period': 10, 
            'volatility_multiplier': 0.5, 'risk_percent': 0.025, 'reward_ratio': 2.0,
            'min_profit_threshold': 0.5, 'cooldown_periods': 3, 'bucket_ms': 600000
        }
    
    def get_param_grid(self) -> Dict:
        return {
            'ma_period': [80, 100, 120], 'z_base_threshold': [2.5, 3.0, 3.5],
            'atr_period': [10, 15], 'volatility_multiplier': [0.4, 0.5, 0.6],
            'risk_percent': [0.02, 0.025, 0.03], 'reward_ratio': [2.0, 2.5],
            'min_profit_threshold': [0.4, 0.5, 0.6], 'cooldown_periods': [2, 3, 4]
        }
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.sma(df, params['ma_period'])
        df = BatchIndicators.atr(df, params['atr_period'])
        
        # Z-Score with higher threshold for fewer signals
        df['price_zscore'] = (df['price'] - df[f'sma_{params["ma_period"]}']) / df['atr']
        
        # Adaptive threshold based on volatility
        df['vol_adj_threshold'] = params['z_base_threshold'] * (1 + df['atr'] * params['volatility_multiplier'])
        
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        """Generate trading signals with higher thresholds and cooldown"""
        df['signal'] = 0
        
        # Calculate adaptive threshold
        threshold = df['vol_adj_threshold']
        
        # BUY: Z-score < -threshold (more conservative)
        df['is_oversold'] = df['price_zscore'] < -threshold
        df['was_not_oversold'] = df['price_zscore'].shift(1) >= -threshold.shift(1)
        df.loc[df['is_oversold'] & df['was_not_oversold'], 'signal'] = 1
        
        # SELL: Z-score > +threshold (more conservative)  
        df['is_overbought'] = df['price_zscore'] > threshold
        df['was_not_overbought'] = df['price_zscore'].shift(1) <= threshold.shift(1)
        df.loc[df['is_overbought'] & df['was_not_overbought'], 'signal'] = -1
        
        return df
