#!/usr/bin/env python3
"""
H03: Z-Score Mean Reversion Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H03ZScoreBatch(BatchStrategy):
    """Z-Score Mean Reversion"""
    
    def get_name(self) -> str:
        return "H03_ZScore_Batch"
    
    def get_default_params(self) -> Dict:
        return {'ma_period': 100, 'z_threshold': 2.0, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 180000}
    
    def get_param_grid(self) -> Dict:
        return {'ma_period': [50, 100, 200], 'z_threshold': [1.5, 2.0, 2.5], 'risk_percent': [0.01, 0.015], 'reward_ratio': [1.5, 2.0], 'position_size': [0.05]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        return BatchIndicators.zscore(df, params['ma_period'])
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        z = params['z_threshold']

        # Edge detection: signal only when crossing thresholds
        # BUY: zscore crosses below -threshold (oversold)
        df['is_oversold'] = df['zscore'] < -z
        df['was_not_oversold'] = df['zscore'].shift(1) >= -z
        df.loc[df['is_oversold'] & df['was_not_oversold'], 'signal'] = 1

        # SELL: zscore crosses above +threshold (overbought)
        df['is_overbought'] = df['zscore'] > z
        df['was_not_overbought'] = df['zscore'].shift(1) <= z
        df.loc[df['is_overbought'] & df['was_not_overbought'], 'signal'] = -1

        return df
