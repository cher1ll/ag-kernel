#!/usr/bin/env python3
"""
H03C: Z-Score with Partial Exits Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
import numpy as np
from typing import Dict, List, Any
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H03cZScoreScalingBatch(BatchStrategy):
    """Z-Score with Partial Exits - Scales out at multiple profit targets"""

    def get_name(self) -> str:
        return "H03c_ZScore_Scaling"

    def get_default_params(self) -> Dict:
        return {'ma_period': 100, 'z_threshold': 2.0, 'risk_percent': 0.01, 'target1_ratio': 0.75, 'target2_ratio': 1.5, 'target3_ratio': 3.0, 'position_size': 0.05, 'bucket_ms': 600000}

    def get_param_grid(self) -> Dict:
        return {'ma_period': [50, 100, 200], 'z_threshold': [1.5, 2.0, 2.5], 'risk_percent': [0.01, 0.015], 'target1_ratio': [0.5, 0.75, 1.0], 'target2_ratio': [1.5, 2.0], 'target3_ratio': [2.5, 3.0, 4.0], 'position_size': [0.05]}

    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        return BatchIndicators.zscore(df, params['ma_period'])

    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        z = params['z_threshold']

        # BUY: Z-score crosses below -threshold
        df['is_oversold'] = df['zscore'] < -z
        df['was_not_oversold'] = df['zscore'].shift(1) >= -z
        df.loc[df['is_oversold'] & df['was_not_oversold'], 'signal'] = 1

        # SELL: Z-score crosses above +threshold
        df['is_overbought'] = df['zscore'] > z
        df['was_not_overbought'] = df['zscore'].shift(1) <= z
        df.loc[df['is_overbought'] & df['was_not_overbought'], 'signal'] = -1

        return df

    def generate_logic(self):
        """Custom logic with partial exits at multiple targets."""
        def batch_logic(data: Dict[str, np.ndarray], engine, params: Dict, tick_size: float) -> List[Dict[str, Any]]:
            from ag_backtester.engine import Order, Tick

            prices = data['price_ticks'] * tick_size
            df = pd.DataFrame({'timestamp': data['timestamp'], 'price': prices, 'qty': data['qty'], 'side': data['side']})
            df = self.compute_indicators(df, params)
            df = self.generate_signals(df, params)

            risk_pct = params['risk_percent']
            t1, t2, t3 = params['target1_ratio'], params['target2_ratio'], params['target3_ratio']
            position_size = params['position_size']
            trades_log, position = [], None

            for i in range(len(df)):
                tick = Tick(ts_ms=int(data['timestamp'][i]), price_tick_i64=int(data['price_ticks'][i]), qty=float(data['qty'][i]), side='SELL' if data['side'][i] == 1 else 'BUY')
                engine.step_tick(tick)

                sig, price = df['signal'].iloc[i], df['price'].iloc[i]

                if position is None:
                    if sig == 1:  # Only LONG for this strategy
                        engine.place_order(Order(order_type='MARKET', side='BUY', qty=position_size))
                        stop_distance = price * risk_pct
                        sl = price - stop_distance
                        target1 = price + (stop_distance * t1)
                        target2 = price + (stop_distance * t2)
                        target3 = price + (stop_distance * t3)
                        position = {'entry_idx': i, 'entry_price': price, 'qty': position_size, 'remaining_qty': position_size, 'sl': sl, 'target1': target1, 'target2': target2, 'target3': target3, 'target1_hit': False, 'target2_hit': False}
                else:
                    should_exit, exit_reason, exit_qty = False, '', 0

                    # Check stop loss
                    if price <= position['sl']:
                        should_exit, exit_reason, exit_qty = True, 'STOP_LOSS', position['remaining_qty']
                    # Check targets
                    elif not position['target1_hit'] and price >= position['target1']:
                        should_exit, exit_reason, exit_qty = True, 'TARGET_1', position_size * 0.33
                        position['target1_hit'] = True
                    elif position['target1_hit'] and not position['target2_hit'] and price >= position['target2']:
                        should_exit, exit_reason, exit_qty = True, 'TARGET_2', position_size * 0.33
                        position['target2_hit'] = True
                    elif position['target2_hit'] and price >= position['target3']:
                        should_exit, exit_reason, exit_qty = True, 'TARGET_3', position['remaining_qty']

                    if should_exit:
                        engine.place_order(Order(order_type='MARKET', side='SELL', qty=exit_qty))
                        pnl = (price - position['entry_price']) * exit_qty
                        trades_log.append({'entry_tick': position['entry_idx'], 'exit_tick': i, 'side': 'LONG', 'entry_price': position['entry_price'], 'exit_price': price, 'qty': exit_qty, 'pnl': pnl, 'pnl_pct': (pnl / (position['entry_price'] * exit_qty)) * 100, 'exit_reason': exit_reason})
                        position['remaining_qty'] -= exit_qty
                        if position['remaining_qty'] <= 0.001:  # Close position completely
                            position = None

            if position and position['remaining_qty'] > 0.001:
                price = df['price'].iloc[-1]
                engine.place_order(Order(order_type='MARKET', side='SELL', qty=position['remaining_qty']))
                pnl = (price - position['entry_price']) * position['remaining_qty']
                trades_log.append({'entry_tick': position['entry_idx'], 'exit_tick': len(df) - 1, 'side': 'LONG', 'entry_price': position['entry_price'], 'exit_price': price, 'qty': position['remaining_qty'], 'pnl': pnl, 'pnl_pct': (pnl / (position['entry_price'] * position['remaining_qty'])) * 100, 'exit_reason': 'FINAL_CLOSE'})

            return trades_log
        return batch_logic
