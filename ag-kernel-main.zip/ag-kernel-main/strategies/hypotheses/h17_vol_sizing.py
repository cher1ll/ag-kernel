#!/usr/bin/env python3
"""
H17: Volatility-Adjusted Sizing Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
import numpy as np
from typing import Dict, List, Any
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H17VolSizingBatch(BatchStrategy):
    """Volatility-Adjusted Sizing - Position size based on volatility"""
    
    def get_name(self) -> str:
        return "H17_Vol_Sizing"
    
    def get_default_params(self) -> Dict:
        return {'base_size': 0.05, 'atr_period': 14, 'rsi_period': 14, 'oversold': 30, 'overbought': 70, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 120000}
    
    def get_param_grid(self) -> Dict:
        return {'base_size': [0.03, 0.05], 'atr_period': [14, 30], 'rsi_period': [14], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.atr(df, params['atr_period'])
        df = BatchIndicators.rsi(df, params['rsi_period'])
        df['atr_avg'] = df['atr'].rolling(params['atr_period'] * 2).mean()
        df['vol_ratio'] = df['atr_avg'] / df['atr']  # Higher when vol is low
        df['vol_ratio'] = df['vol_ratio'].clip(0.5, 2.0)  # Limit sizing
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        buy_cond = df['rsi'] < params.get('oversold', 30)
        sell_cond = df['rsi'] > params.get('overbought', 70)
        df.loc[buy_cond & ~buy_cond.shift(1).fillna(False), 'signal'] = 1
        df.loc[sell_cond & ~sell_cond.shift(1).fillna(False), 'signal'] = -1
        return df
    
    def generate_logic(self):
        """Custom logic with volatility-adjusted position sizing."""
        def batch_logic(data: Dict[str, np.ndarray], engine, params: Dict, tick_size: float) -> List[Dict[str, Any]]:
            from ag_backtester.engine import Order, Tick
            
            prices = data['price_ticks'] * tick_size
            df = pd.DataFrame({'timestamp': data['timestamp'], 'price': prices, 'qty': data['qty'], 'side': data['side']})
            df = self.compute_indicators(df, params)
            df = self.generate_signals(df, params)
            
            base_size = params['base_size']
            risk_pct, rr = params['risk_percent'], params['reward_ratio']
            trades_log, position = [], None
            
            for i in range(len(df)):
                tick = Tick(ts_ms=int(data['timestamp'][i]), price_tick_i64=int(data['price_ticks'][i]), qty=float(data['qty'][i]), side='SELL' if data['side'][i] == 1 else 'BUY')
                engine.step_tick(tick)
                
                sig, price = df['signal'].iloc[i], df['price'].iloc[i]
                vol_ratio = df['vol_ratio'].iloc[i] if not pd.isna(df['vol_ratio'].iloc[i]) else 1.0
                adj_size = base_size * vol_ratio
                
                if position is None:
                    if sig != 0:
                        side = 'BUY' if sig == 1 else 'SELL'
                        engine.place_order(Order(order_type='MARKET', side=side, qty=adj_size))
                        sl = price * (1 - risk_pct) if side == 'BUY' else price * (1 + risk_pct)
                        tp = price * (1 + risk_pct * rr) if side == 'BUY' else price * (1 - risk_pct * rr)
                        position = {'side': side, 'entry_idx': i, 'entry_price': price, 'qty': adj_size, 'sl': sl, 'tp': tp}
                else:
                    should_exit, exit_reason = False, ''
                    if position['side'] == 'BUY':
                        if price <= position['sl']: should_exit, exit_reason = True, 'STOP_LOSS'
                        elif price >= position['tp']: should_exit, exit_reason = True, 'TAKE_PROFIT'
                    else:
                        if price >= position['sl']: should_exit, exit_reason = True, 'STOP_LOSS'
                        elif price <= position['tp']: should_exit, exit_reason = True, 'TAKE_PROFIT'
                    
                    if should_exit:
                        close_side = 'SELL' if position['side'] == 'BUY' else 'BUY'
                        engine.place_order(Order(order_type='MARKET', side=close_side, qty=position['qty']))
                        pnl = (price - position['entry_price']) * position['qty'] * (1 if position['side'] == 'BUY' else -1)
                        trades_log.append({'entry_tick': position['entry_idx'], 'exit_tick': i, 'side': position['side'], 'entry_price': position['entry_price'], 'exit_price': price, 'qty': position['qty'], 'pnl': pnl, 'pnl_pct': (pnl / (position['entry_price'] * position['qty'])) * 100, 'exit_reason': exit_reason})
                        position = None
            
            if position:
                price = df['price'].iloc[-1]
                close_side = 'SELL' if position['side'] == 'BUY' else 'BUY'
                engine.place_order(Order(order_type='MARKET', side=close_side, qty=position['qty']))
                pnl = (price - position['entry_price']) * position['qty'] * (1 if position['side'] == 'BUY' else -1)
                trades_log.append({'entry_tick': position['entry_idx'], 'exit_tick': len(df) - 1, 'side': position['side'], 'entry_price': position['entry_price'], 'exit_price': price, 'qty': position['qty'], 'pnl': pnl, 'pnl_pct': (pnl / (position['entry_price'] * position['qty'])) * 100, 'exit_reason': 'FINAL_CLOSE'})
            
            return trades_log
        return batch_logic
