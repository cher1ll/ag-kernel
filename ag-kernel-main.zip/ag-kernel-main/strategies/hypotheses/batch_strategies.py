#!/usr/bin/env python3
"""
Batch versions of all hypothesis strategies.
Uses vectorized pandas/numpy for 10-20x speedup.

DEPRECATED: This file has been split into individual strategy files.
Import from the individual files or use the registry in __init__.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import all strategies from individual files
from . import BATCH_STRATEGIES, get_batch_strategy

# Re-export for backward compatibility
from .h01_bollinger import H01BollingerBatch
from .h02_rsi import H02RSIBatch
from .h03_zscore import H03ZScoreBatch
from .h03a_zscore_volume import H03aZScoreVolumeBatch
from .h03b_zscore_adaptive import H03bZScoreAdaptiveBatch
from .h03c_zscore_scaling import H03cZScoreScalingBatch
from .h03d_zscore_lowfreq import H03dZScoreLowFreqBatch
from .h03e_zscore_antipattern import H03eZScoreAntiPatternBatch
from .h04_ema_pullback import H04EMAPullbackBatch
from .h07_squeeze import H07SqueezeBatch
from .h08_volume_breakout import H08VolumeBreakoutBatch
from .h09_atr_expansion import H09ATRExpansionBatch
from .h10_volume_delta import H10VolumeDeltaBatch
from .h11_aggressive_volume import H11AggressiveVolumeBatch
from .h14_regime_switch import H14RegimeSwitchBatch
from .h15_time_filter import H15TimeFilterBatch
from .h16_atr_adaptive import H16ATRAdaptiveBatch
from .h17_vol_sizing import H17VolSizingBatch

# Keep the old class names for backward compatibility
H07SqueezeBatch = H07SqueezeBatch
H10VolumeDeltaBatch = H10VolumeDeltaBatch
H04EMAPullbackBatch = H04EMAPullbackBatch
H08VolumeBreakoutBatch = H08VolumeBreakoutBatch
H09ATRExpansionBatch = H09ATRExpansionBatch
H11AggressiveVolumeBatch = H11AggressiveVolumeBatch
H14RegimeSwitchBatch = H14RegimeSwitchBatch
H15TimeFilterBatch = H15TimeFilterBatch
H16ATRAdaptiveBatch = H16ATRAdaptiveBatch
H17VolSizingBatch = H17VolSizingBatch
