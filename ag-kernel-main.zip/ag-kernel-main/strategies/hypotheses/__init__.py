#!/usr/bin/env python3
"""
Registry of all batch strategies.
Imports individual strategy classes from separate files.
"""
from .h01_bollinger import H01BollingerBatch
from .h02_rsi import H02RSIBatch
from .h03_zscore import H03ZScoreBatch
from .h03a_zscore_volume import H03aZScoreVolumeBatch
from .h03b_zscore_adaptive import H03bZScoreAdaptiveBatch
from .h03c_zscore_scaling import H03cZScoreScalingBatch
from .h03d_zscore_lowfreq import H03dZScoreLowFreqBatch
from .h03e_zscore_antipattern import H03eZScoreAntiPatternBatch
from .h04_ema_pullback import H04EMAPullbackBatch
from .h07_squeeze import H07SqueezeBatch
from .h08_volume_breakout import H08VolumeBreakoutBatch
from .h09_atr_expansion import H09ATRExpansionBatch
from .h10_volume_delta import H10VolumeDeltaBatch
from .h11_aggressive_volume import H11AggressiveVolumeBatch
from .h14_regime_switch import H14RegimeSwitchBatch
from .h15_time_filter import H15TimeFilterBatch
from .h16_atr_adaptive import H16ATRAdaptiveBatch
from .h17_vol_sizing import H17VolSizingBatch

from framework.batch_strategy import BatchStrategy


# Registry of all batch strategies
BATCH_STRATEGIES = {
    'h01': H01BollingerBatch,
    'h02': H02RSIBatch,
    'h03': H03ZScoreBatch,
    'h03a': H03aZScoreVolumeBatch,
    'h03b': H03bZScoreAdaptiveBatch,
    'h03c': H03cZScoreScalingBatch,
    'h03d': H03dZScoreLowFreqBatch,
    'h03e': H03eZScoreAntiPatternBatch,
    'h04': H04EMAPullbackBatch,
    'h07': H07SqueezeBatch,
    'h08': H08VolumeBreakoutBatch,
    'h09': H09ATRExpansionBatch,
    'h10': H10VolumeDeltaBatch,
    'h11': H11AggressiveVolumeBatch,
    'h14': H14RegimeSwitchBatch,
    'h15': H15TimeFilterBatch,
    'h16': H16ATRAdaptiveBatch,
    'h17': H17VolSizingBatch,
}


def get_batch_strategy(name: str) -> BatchStrategy:
    """Get batch strategy by name."""
    if name.lower() in BATCH_STRATEGIES:
        return BATCH_STRATEGIES[name.lower()]()
    raise ValueError(f"Unknown strategy: {name}. Available: {list(BATCH_STRATEGIES.keys())}")
