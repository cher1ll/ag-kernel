#!/usr/bin/env python3
"""
H03E: Anti-Pattern Z-Score Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
import numpy as np
from typing import Dict, List
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H03eZScoreAntiPatternBatch(BatchStrategy):
    """H03E: Anti-Pattern Z-Score Strategy - Randomized timing to avoid detection"""
    
    def get_name(self) -> str:
        return "H03e_ZScore_AntiPattern"
    
    def get_default_params(self) -> Dict:
        return {
            'ma_period': 100, 'z_base_threshold': 2.0, 'atr_period': 10,
            'volatility_multiplier': 0.5, 'risk_percent': 0.015, 'reward_ratio': 1.5,
            'random_delay_max': 5, 'pattern_break_prob': 0.3, 'bucket_ms': 600000
        }
    
    def get_param_grid(self) -> Dict:
        return {
            'ma_period': [80, 100, 120], 'z_base_threshold': [1.8, 2.0, 2.2],
            'atr_period': [8, 10, 12], 'volatility_multiplier': [0.4, 0.5, 0.6],
            'risk_percent': [0.01, 0.015, 0.02], 'reward_ratio': [1.5, 2.0],
            'random_delay_max': [3, 5, 7], 'pattern_break_prob': [0.2, 0.3, 0.4]
        }
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.sma(df, params['ma_period'])
        df = BatchIndicators.atr(df, params['atr_period'])
        
        # Z-Score calculation
        df['price_zscore'] = (df['price'] - df[f'sma_{params["ma_period"]}']) / df['atr']
        
        # Add randomization seed based on timestamp
        np.random.seed(42)  # Fixed seed for reproducibility
        df['random_delay'] = np.random.randint(0, params['random_delay_max'] + 1, len(df))
        df['pattern_break'] = np.random.random(len(df)) < params['pattern_break_prob']
        
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        """Generate trading signals with anti-pattern randomization"""
        df['signal'] = 0
        
        # BUY: Z-score < -threshold, but with pattern breaking
        df['buy_condition'] = df['price_zscore'] < -params['z_base_threshold']
        df['buy_signal'] = df['buy_condition'] & ~df['pattern_break']
        df['was_not_buy'] = ~df['buy_condition'].shift(1).fillna(True)
        df.loc[df['buy_signal'] & df['was_not_buy'], 'signal'] = 1
        
        # SELL: Z-score > +threshold, but with pattern breaking
        df['sell_condition'] = df['price_zscore'] > params['z_base_threshold']
        df['sell_signal'] = df['sell_condition'] & ~df['pattern_break']
        df['was_not_sell'] = ~df['sell_condition'].shift(1).fillna(True)
        df.loc[df['sell_signal'] & df['was_not_sell'], 'signal'] = -1
        
        return df

