#!/usr/bin/env python3
"""
H07: Bollinger Squeeze Breakout Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H07SqueezeBatch(BatchStrategy):
    """Bollinger Squeeze Breakout"""
    
    def get_name(self) -> str:
        return "H07_Squeeze_Batch"
    
    def get_default_params(self) -> Dict:
        return {'bb_period': 20, 'bb_std': 2.0, 'squeeze_threshold': 0.02, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 120000}
    
    def get_param_grid(self) -> Dict:
        return {'bb_period': [15, 20, 30], 'bb_std': [2.0], 'squeeze_threshold': [0.015, 0.02, 0.025], 'risk_percent': [0.01, 0.015], 'reward_ratio': [1.5, 2.0], 'position_size': [0.05]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.bollinger_bands(df, params['bb_period'], params['bb_std'])
        df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_sma']
        df['squeeze'] = df['bb_width'] < params['squeeze_threshold']
        df['breakout_up'] = (df['price'] > df['bb_upper']) & df['squeeze'].shift(1)
        df['breakout_down'] = (df['price'] < df['bb_lower']) & df['squeeze'].shift(1)
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        df.loc[df['breakout_up'], 'signal'] = 1
        df.loc[df['breakout_down'], 'signal'] = -1
        return df
