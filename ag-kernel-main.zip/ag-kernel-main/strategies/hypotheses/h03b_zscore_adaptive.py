#!/usr/bin/env python3
"""
H03B: Z-Score with Adaptive Threshold Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H03bZScoreAdaptiveBatch(BatchStrategy):
    """Z-Score with Adaptive Threshold - Adjusts threshold based on ATR volatility"""

    def get_name(self) -> str:
        return "H03b_ZScore_Adaptive"

    def get_default_params(self) -> Dict:
        return {'ma_period': 100, 'z_base_threshold': 2.0, 'atr_period': 14, 'volatility_multiplier': 0.5, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 600000}

    def get_param_grid(self) -> Dict:
        return {'ma_period': [50, 100, 200], 'z_base_threshold': [1.5, 2.0, 2.5], 'atr_period': [10, 14, 20], 'volatility_multiplier': [0.3, 0.5, 0.8], 'risk_percent': [0.01, 0.015], 'reward_ratio': [1.5, 2.0]}

    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.zscore(df, params['ma_period'])
        df = BatchIndicators.atr(df, params['atr_period'])

        # Calculate normalized volatility and adaptive threshold
        df['normalized_volatility'] = df['atr'] / df['price']
        df['adaptive_threshold'] = params['z_base_threshold'] * (1 + df['normalized_volatility'] * params['volatility_multiplier'] * 100)

        return df

    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0

        # BUY: Z-score < -adaptive_threshold
        df['is_oversold'] = df['zscore'] < -df['adaptive_threshold']
        df['was_not_oversold'] = df['zscore'].shift(1) >= -df['adaptive_threshold'].shift(1)
        df.loc[df['is_oversold'] & df['was_not_oversold'], 'signal'] = 1

        # SELL: Z-score > +adaptive_threshold
        df['is_overbought'] = df['zscore'] > df['adaptive_threshold']
        df['was_not_overbought'] = df['zscore'].shift(1) <= df['adaptive_threshold'].shift(1)
        df.loc[df['is_overbought'] & df['was_not_overbought'], 'signal'] = -1

        return df
