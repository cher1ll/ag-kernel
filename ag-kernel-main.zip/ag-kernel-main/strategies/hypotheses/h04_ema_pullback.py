#!/usr/bin/env python3
"""
H04: EMA Crossover Pullback Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H04EMAPullbackBatch(BatchStrategy):
    """EMA Crossover Pullback - Trend following with pullbacks"""
    
    def get_name(self) -> str:
        return "H04_EMA_Pullback"
    
    def get_default_params(self) -> Dict:
        return {'fast_ema': 20, 'slow_ema': 50, 'pullback_pct': 0.005, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 120000}
    
    def get_param_grid(self) -> Dict:
        return {'fast_ema': [10, 20], 'slow_ema': [50, 100], 'pullback_pct': [0.003, 0.005, 0.01], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.ema(df, params['fast_ema'], name='ema_fast')
        df = BatchIndicators.ema(df, params['slow_ema'], name='ema_slow')
        df['uptrend'] = df['ema_fast'] > df['ema_slow']
        df['pullback_to_ema'] = (df['price'] - df['ema_fast']).abs() / df['ema_fast']
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        pb = params['pullback_pct']
        # BUY: uptrend + price pulled back to fast EMA
        buy_cond = df['uptrend'] & (df['pullback_to_ema'] < pb) & (df['price'] > df['ema_fast'])
        df.loc[buy_cond & ~buy_cond.shift(1).fillna(False), 'signal'] = 1
        # SELL: downtrend + price pulled back to fast EMA
        sell_cond = ~df['uptrend'] & (df['pullback_to_ema'] < pb) & (df['price'] < df['ema_fast'])
        df.loc[sell_cond & ~sell_cond.shift(1).fillna(False), 'signal'] = -1
        return df
