#!/usr/bin/env python3
"""
H14: Regime Switching Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H14RegimeSwitchBatch(BatchStrategy):
    """Regime Switching - Adaptive strategy based on ADX"""
    
    def get_name(self) -> str:
        return "H14_Regime_Switch"
    
    def get_default_params(self) -> Dict:
        return {'adx_period': 14, 'trend_threshold': 25, 'bb_period': 20, 'bb_std': 2.0, 'risk_percent': 0.01, 'reward_ratio': 1.5, 'position_size': 0.05, 'bucket_ms': 120000}
    
    def get_param_grid(self) -> Dict:
        return {'adx_period': [14, 20], 'trend_threshold': [20, 25, 30], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        # Simplified ADX: directional movement ratio
        period = params['adx_period']
        df['price_change'] = df['price'].diff()
        df['abs_change'] = df['price_change'].abs().rolling(period).mean()
        df['dir_change'] = df['price_change'].rolling(period).mean().abs()
        df['adx'] = (df['dir_change'] / df['abs_change'] * 100).fillna(0)
        # Bollinger for mean reversion in ranging
        df = BatchIndicators.bollinger_bands(df, params.get('bb_period', 20), params.get('bb_std', 2.0))
        df['trending'] = df['adx'] > params['trend_threshold']
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        # Trending: follow momentum
        trend_buy = df['trending'] & (df['price_change'] > 0)
        trend_sell = df['trending'] & (df['price_change'] < 0)
        # Ranging: mean reversion
        range_buy = ~df['trending'] & (df['price'] < df['bb_lower'])
        range_sell = ~df['trending'] & (df['price'] > df['bb_upper'])
        # Combine
        buy_cond = trend_buy | range_buy
        sell_cond = trend_sell | range_sell
        df.loc[buy_cond & ~buy_cond.shift(1).fillna(False), 'signal'] = 1
        df.loc[sell_cond & ~sell_cond.shift(1).fillna(False), 'signal'] = -1
        return df
