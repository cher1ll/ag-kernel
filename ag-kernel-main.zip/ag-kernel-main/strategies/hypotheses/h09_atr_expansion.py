#!/usr/bin/env python3
"""
H09: ATR Expansion Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H09ATRExpansionBatch(BatchStrategy):
    """ATR Expansion - Trade volatility expansion"""
    
    def get_name(self) -> str:
        return "H09_ATR_Expansion"
    
    def get_default_params(self) -> Dict:
        return {'atr_period': 14, 'expansion_ratio': 1.5, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 120000}
    
    def get_param_grid(self) -> Dict:
        return {'atr_period': [14, 20], 'expansion_ratio': [1.3, 1.5, 2.0], 'risk_percent': [0.01], 'reward_ratio': [1.5, 2.0]}
    
    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.atr(df, params['atr_period'])
        df['atr_avg'] = df['atr'].rolling(params['atr_period'] * 2).mean()
        df['atr_expansion'] = df['atr'] / df['atr_avg']
        df['price_change'] = df['price'].diff()
        return df
    
    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        exp = params['expansion_ratio']
        # BUY: ATR expansion + price moving up
        buy_cond = (df['atr_expansion'] > exp) & (df['price_change'] > 0)
        df.loc[buy_cond & ~buy_cond.shift(1).fillna(False), 'signal'] = 1
        # SELL: ATR expansion + price moving down
        sell_cond = (df['atr_expansion'] > exp) & (df['price_change'] < 0)
        df.loc[sell_cond & ~sell_cond.shift(1).fillna(False), 'signal'] = -1
        return df
