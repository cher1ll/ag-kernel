#!/usr/bin/env python3
"""
H03A: Z-Score with Volume Confirmation Strategy
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from typing import Dict
from framework.batch_strategy import BatchStrategy, BatchIndicators


class H03aZScoreVolumeBatch(BatchStrategy):
    """Z-Score with Volume Confirmation - Only enter on Z-score extreme + volume spike"""

    def get_name(self) -> str:
        return "H03a_ZScore_Volume"

    def get_default_params(self) -> Dict:
        return {'ma_period': 100, 'z_threshold': 2.0, 'volume_lookback': 20, 'volume_threshold': 1.5, 'risk_percent': 0.01, 'reward_ratio': 2.0, 'position_size': 0.05, 'bucket_ms': 600000}

    def get_param_grid(self) -> Dict:
        return {'ma_period': [50, 100, 200], 'z_threshold': [1.5, 2.0, 2.5], 'volume_lookback': [10, 20, 30], 'volume_threshold': [1.3, 1.5, 2.0], 'risk_percent': [0.01, 0.015], 'reward_ratio': [1.5, 2.0]}

    def compute_indicators(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df = BatchIndicators.zscore(df, params['ma_period'])
        df['volume_avg'] = df['qty'].rolling(params['volume_lookback']).mean()
        df['volume_ratio'] = df['qty'] / df['volume_avg']
        return df

    def generate_signals(self, df: pd.DataFrame, params: Dict) -> pd.DataFrame:
        df['signal'] = 0
        z = params['z_threshold']
        vol = params['volume_threshold']

        # BUY: Z-score < -threshold AND volume spike
        df['is_oversold'] = (df['zscore'] < -z) & (df['volume_ratio'] > vol)
        df['was_not_oversold'] = ~((df['zscore'].shift(1) < -z) & (df['volume_ratio'].shift(1) > vol))
        df.loc[df['is_oversold'] & df['was_not_oversold'], 'signal'] = 1

        # SELL: Z-score > +threshold AND volume spike
        df['is_overbought'] = (df['zscore'] > z) & (df['volume_ratio'] > vol)
        df['was_not_overbought'] = ~((df['zscore'].shift(1) > z) & (df['volume_ratio'].shift(1) > vol))
        df.loc[df['is_overbought'] & df['was_not_overbought'], 'signal'] = -1

        return df
