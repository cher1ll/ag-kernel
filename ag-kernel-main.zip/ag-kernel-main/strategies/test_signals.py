#!/usr/bin/env python3
"""Test signal generation logic"""
import sys
from pathlib import Path
import pandas as pd
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).parent.parent / "python"))

from hypotheses.batch_strategies import H01BollingerBatch
from framework.batch_strategy import BatchIndicators

def test_signal_logic():
    # Create simple test data
    np.random.seed(42)
    n = 100

    # Simulate price that crosses bands
    price = 100 + np.cumsum(np.random.randn(n) * 0.5)

    df = pd.DataFrame({
        'timestamp': range(n),
        'price': price,
        'qty': np.ones(n),
        'side': np.zeros(n)
    })

    # Compute BB
    params = {'bb_period': 20, 'bb_std': 2.0}
    df = BatchIndicators.bollinger_bands(df, params['bb_period'], params['bb_std'])

    # Generate signals using H01 logic
    strategy = H01BollingerBatch()
    df = strategy.generate_signals(df, params)

    # Print first 50 rows
    print("First 50 rows:")
    print(df[['price', 'bb_lower', 'bb_upper', 'signal']].head(50).to_string())

    # Count signals
    num_buy = (df['signal'] == 1).sum()
    num_sell = (df['signal'] == -1).sum()

    print(f"\nTotal signals: {num_buy} BUY, {num_sell} SELL out of {n} ticks")

    # Check edge detection
    print("\nBUY signal ticks:")
    buy_idx = df[df['signal'] == 1].index.tolist()
    print(buy_idx)

    for idx in buy_idx[:5]:  # Show first 5
        if idx > 0:
            print(f"  Tick {idx}: price={df.loc[idx, 'price']:.2f}, bb_lower={df.loc[idx, 'bb_lower']:.2f}")
            print(f"    Previous: price={df.loc[idx-1, 'price']:.2f}, bb_lower={df.loc[idx-1, 'bb_lower']:.2f}")
            print(f"    Is below lower? {df.loc[idx, 'price'] <= df.loc[idx, 'bb_lower']}")
            print(f"    Was above lower? {df.loc[idx-1, 'price'] > df.loc[idx-1, 'bb_lower']}")

if __name__ == '__main__':
    test_signal_logic()
