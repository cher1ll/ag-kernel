#!/usr/bin/env python3
"""
Walk-Forward Analysis (WFA) framework.
Handles parameter optimization on IS and validation on OOS data.
"""
import sys
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from itertools import product
from multiprocessing import Pool
import pandas as pd
import numpy as np
import hashlib
import time

sys.path.insert(0, str(Path(__file__).parent))

# Global cache for processed data
_DATA_CACHE = {}

def _get_data_cache_key(df: pd.DataFrame, bucket_ms: int) -> str:
    """Generate cache key for DataFrame and bucket_ms combination."""
    # Create hash from DataFrame content and bucket_ms
    df_hash = hashlib.md5(pd.util.hash_pandas_object(df).values).hexdigest()
    return f"{df_hash}_{bucket_ms}"

def _get_cached_data(df: pd.DataFrame, bucket_ms: int) -> Optional[Tuple]:
    """Get cached processed data if available."""
    cache_key = _get_data_cache_key(df, bucket_ms)
    return _DATA_CACHE.get(cache_key)

def _cache_data(df: pd.DataFrame, bucket_ms: int, ticks, tick_size):
    """Cache processed data."""
    cache_key = _get_data_cache_key(df, bucket_ms)
    _DATA_CACHE[cache_key] = (ticks, tick_size)

def clear_data_cache():
    """Clear the global data cache to free memory."""
    global _DATA_CACHE
    _DATA_CACHE.clear()

from backtest_engine import BacktestEngine, split_data_by_dates
from metrics import (
    calculate_basic_metrics,
    calculate_robustness_score,
    calculate_consistency,
    calculate_final_robustness_score,
    passes_mvs_aggregate
)
from monte_carlo import comprehensive_significance_test


class WalkForwardAnalyzer:
    """
    Performs walk-forward analysis on a strategy.

    Process:
    1. Split data into IS/OOS windows
    2. For each window:
       a. Optimize parameters on IS data (grid search)
       b. Test best parameters on OOS data
    3. Aggregate OOS results
    4. Calculate robustness metrics
    """

    def __init__(self,
                 data_path: str,
                 is_days: int = 30,
                 oos_days: int = 15,
                 step_days: int = 10,
                 verbose: bool = False):
        """
        Initialize WFA analyzer.

        Args:
            data_path: Path to aggTrades CSV
            is_days: In-sample period in days
            oos_days: Out-of-sample period in days
            step_days: Step size for sliding window
            verbose: Enable verbose output
        """
        self.data_path = data_path
        self.is_days = is_days
        self.oos_days = oos_days
        self.step_days = step_days
        self.verbose = verbose
        self.windows = None

    def prepare_windows(self) -> List[Dict]:
        """
        Split data into walk-forward windows.

        Returns:
            List of window dictionaries
        """
        self.windows = split_data_by_dates(
            self.data_path,
            is_days=self.is_days,
            oos_days=self.oos_days,
            step_days=self.step_days
        )
        return self.windows

    def optimize_parameters(self,
                           strategy_logic,
                           param_grid: Dict,
                           is_df: pd.DataFrame,
                           bucket_ms: int = 2000,
                           max_combinations: int = 50,
                           window: Dict = None) -> Tuple[Dict, Dict]:
        """
        Optimize strategy parameters on in-sample data using grid search.

        Args:
            strategy_logic: Strategy logic function
            param_grid: Dictionary of parameter lists to try
            is_df: In-sample dataframe
            bucket_ms: Bucket size for tick aggregation
            max_combinations: Maximum parameter combinations to test

        Returns:
            (best_params, best_metrics) tuple
        """
        # Generate all parameter combinations
        keys = list(param_grid.keys())
        values = list(param_grid.values())
        combinations = list(product(*values))

        # Limit combinations to avoid overfitting
        if len(combinations) > max_combinations:
            print(f"  Warning: {len(combinations)} combinations, limiting to {max_combinations}")
            import random
            random.seed(42)
            combinations = random.sample(combinations, max_combinations)

        print(f"  Testing {len(combinations)} parameter combinations on IS...")

        # Always use batch processing for speed
        from ag_backtester.data.optimized_loader import load_data_optimized
        from ag_backtester.userland import calculate_auto_ticksize
        import tempfile
        import os
        
        # Get tick_size from first price
        first_price = is_df['price'].iloc[0]
        tick_size = calculate_auto_ticksize(first_price, target_ticks=200)
        
        # Save DataFrame to temp file for batch loader
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp:
            is_df.to_csv(tmp.name, index=False)
            temp_path = tmp.name
        
        batch_data, _ = load_data_optimized(
            data_path=temp_path,
            tick_size=tick_size,
            bucket_ms=bucket_ms,
            auto_convert=False,  # Don't cache temp files
            verbose=False
        )
        os.unlink(temp_path)
        
        # Check if strategy supports batch processing natively
        import inspect
        strategy_sig = inspect.signature(strategy_logic)
        supports_batch = 'data' in strategy_sig.parameters
        
        # Pre-convert to ticks once if needed (avoid creating objects in loop)
        if not supports_batch:
            from ag_backtester.data.feeds import Tick
            cached_ticks = [
                Tick(
                    ts_ms=int(batch_data['timestamp'][j]),
                    price_tick_i64=int(batch_data['price_ticks'][j]),
                    qty=float(batch_data['qty'][j]),
                    side='SELL' if batch_data['side'][j] == 1 else 'BUY'
                )
                for j in range(len(batch_data['timestamp']))
            ]
            print(f"  Using BATCH mode 🚀 (converted {len(cached_ticks)} ticks)")
        else:
            cached_ticks = None
            print(f"  Using BATCH processing mode 🚀")
        
        best_score = -np.inf
        best_params = None
        best_metrics = None

        for i, combo in enumerate(combinations):
            params = dict(zip(keys, combo))
            params['bucket_ms'] = bucket_ms

            try:
                print(f"    [{i+1}/{len(combinations)}] Testing {params}...")
                
                # Create fresh engine
                from ag_backtester import Engine, EngineConfig
                engine_config = EngineConfig(
                    initial_cash=100_000.0,
                    tick_size=tick_size,
                    maker_fee=0.0001,
                    taker_fee=0.0002,
                    spread_bps=0.0
                )
                engine = Engine(engine_config)
                
                if supports_batch:
                    # Native batch strategy
                    trades_log = strategy_logic(
                        data=batch_data,
                        engine=engine,
                        params=params,
                        tick_size=tick_size
                    )
                else:
                    # Use pre-converted ticks (no engine.step_tick - strategy handles it)
                    trades_log = strategy_logic(
                        ticks=cached_ticks,
                        engine=engine,
                        params=params,
                        tick_size=tick_size
                    )
                
                snapshots = engine.get_history()

                # DEBUG: Check snapshots
                if snapshots and len(snapshots) > 0:
                    print(f"      DEBUG: {len(snapshots)} snapshots, Initial equity: ${snapshots[0].equity:.2f}, Final equity: ${snapshots[-1].equity:.2f}")
                else:
                    print(f"      DEBUG: NO SNAPSHOTS!")

                result = {
                    'snapshots': snapshots,
                    'trades_log': trades_log,
                    'params': params,
                    'tick_size': tick_size,
                    'num_ticks': len(batch_data['timestamp'])
                }

                # Calculate metrics
                metrics = calculate_basic_metrics(
                    result['trades_log'],
                    result['snapshots']
                )

                print(f"      → Return: {metrics.get('return_pct', 0):.2f}%, PF: {metrics.get('profit_factor', 0):.2f}, Trades: {metrics.get('total_trades', 0)}")

                # Score: prioritize profit factor and return
                # Skip if no trades or losing
                if metrics['total_trades'] == 0 or metrics['profit_factor'] <= 1.0:
                    print(f"      ✗ Skipped (no trades or losing)")
                    continue

                score = (metrics['profit_factor'] * 0.5 +
                        max(metrics['return_pct'], 0) * 0.3 +
                        metrics['sharpe_ratio'] * 0.2)

                if score > best_score:
                    best_score = score
                    best_params = params.copy()
                    best_metrics = metrics.copy()
                    print(f"      ★ New best! Score: {score:.2f}")

            except Exception as e:
                print(f"      ✗ Failed: {e}")
                import traceback
                traceback.print_exc()
                continue

        print(f"  Optimization complete. Best score: {best_score:.2f}")
        
        if best_params is None:
            print("  Warning: No profitable parameter combination found on IS")
            # Return default params
            best_params = {k: v[0] for k, v in param_grid.items()}
            best_params['bucket_ms'] = bucket_ms
            best_metrics = {
                'total_trades': 0,
                'profit_factor': 0,
                'return_pct': 0,
                'sharpe_ratio': 0
            }

        return best_params, best_metrics

    def validate_on_oos(self,
                       strategy_logic,
                       params: Dict,
                       oos_df: pd.DataFrame) -> Tuple[Dict, List]:
        """
        Validate strategy with given parameters on out-of-sample data.
        """
        bucket_ms = params.get('bucket_ms', 2000)

        try:
            # Always use batch processing
            from ag_backtester.data.optimized_loader import load_data_optimized
            from ag_backtester.userland import calculate_auto_ticksize
            from ag_backtester import Engine, EngineConfig
            import tempfile
            import os
            
            first_price = oos_df['price'].iloc[0]
            tick_size = calculate_auto_ticksize(first_price, target_ticks=200)
            
            # Create cache-friendly filename for OOS data
            data_path_obj = Path(self.data_path)
            oos_start = oos_df['timestamp'].iloc[0]
            oos_end = oos_df['timestamp'].iloc[-1]
            cache_key = f"{data_path_obj.stem}_oos_{oos_start}_{oos_end}"
            cache_name = f"{cache_key}_b{bucket_ms}ms_t{tick_size:.1f}".replace('.', 'p') + ".parquet"
            cache_file = data_path_obj.parent / cache_name
            
            # Check if cached version exists
            if cache_file.exists() and cache_file.stat().st_mtime >= data_path_obj.stat().st_mtime:
                if self.verbose:
                    print(f"Using OOS cache: {cache_file.name}")
                from ag_backtester.data.optimized_loader import OptimizedDataLoader
                cache_loader = OptimizedDataLoader(cache_file, tick_size=tick_size, verbose=False)
                batch_data, _ = cache_loader.load_for_batch_processing(bucket_ms=bucket_ms)
            else:
                with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp:
                    oos_df.to_csv(tmp.name, index=False)
                    temp_path = tmp.name
                
                batch_data, _ = load_data_optimized(
                    data_path=temp_path,
                    tick_size=tick_size,
                    bucket_ms=bucket_ms,
                    auto_convert=False,
                    verbose=False
                )
                os.unlink(temp_path)
                
                # Save to cache
                try:
                    from ag_backtester.data.converter import convert_to_parquet
                    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp:
                        oos_df.to_csv(tmp.name, index=False)
                        convert_to_parquet(tmp.name, cache_file, compression='zstd')
                        os.unlink(tmp.name)
                except Exception:
                    pass
            
            engine_config = EngineConfig(
                initial_cash=100_000.0,
                tick_size=tick_size,
                maker_fee=0.0001,
                taker_fee=0.0002,
                spread_bps=0.0
            )
            engine = Engine(engine_config)
            
            # Check if strategy supports batch processing
            import inspect
            strategy_sig = inspect.signature(strategy_logic)
            supports_batch = 'data' in strategy_sig.parameters
            
            if supports_batch:
                trades_log = strategy_logic(
                    data=batch_data,
                    engine=engine,
                    params=params,
                    tick_size=tick_size
                )
            else:
                # Convert to ticks
                from ag_backtester.data.feeds import Tick
                ticks = [
                    Tick(
                        ts_ms=int(batch_data['timestamp'][j]),
                        price_tick_i64=int(batch_data['price_ticks'][j]),
                        qty=float(batch_data['qty'][j]),
                        side='SELL' if batch_data['side'][j] == 1 else 'BUY'
                    )
                    for j in range(len(batch_data['timestamp']))
                ]
                
                trades_log = strategy_logic(
                    ticks=ticks,
                    engine=engine,
                    params=params,
                    tick_size=tick_size
                )
            
            snapshots = engine.get_history()

            metrics = calculate_basic_metrics(trades_log, snapshots)

            print(f"  OOS Results → Return: {metrics.get('return_pct', 0):.2f}%, PF: {metrics.get('profit_factor', 0):.2f}, Trades: {metrics.get('total_trades', 0)}")

            return metrics, trades_log

        except Exception as e:
            print(f"  OOS validation failed: {e}")
            import traceback
            traceback.print_exc()
            return {
                'total_trades': 0,
                'profit_factor': 0,
                'return_pct': 0,
                'sharpe_ratio': 0,
                'max_drawdown_pct': 0
            }, []

    def run_single_window(self,
                         window: Dict,
                         strategy_logic,
                         param_grid: Dict,
                         bucket_ms: int = 2000) -> Dict:
        """
        Run WFA on a single window.

        Args:
            window: Window dictionary with is_df and oos_df
            strategy_logic: Strategy logic function
            param_grid: Parameter grid for optimization
            bucket_ms: Bucket size

        Returns:
            Dictionary with window results
        """
        print(f"\nWindow {window['window_id']}: IS {window['is_period']} -> OOS {window['oos_period']}")
        print(f"  IS data: {len(window['is_df'])} rows, OOS data: {len(window['oos_df'])} rows")

        # Optimize on IS
        print(f"  Starting parameter optimization...")
        start_time = time.time()
        best_params, is_metrics = self.optimize_parameters(
            strategy_logic,
            param_grid,
            window['is_df'],
            bucket_ms=bucket_ms,
            window=window
        )
        opt_time = time.time() - start_time

        print(f"  ✓ Optimization completed in {opt_time:.2f}s")
        print(f"  ✓ Best IS params: {best_params}")
        print(f"  ✓ IS metrics: PF={is_metrics.get('profit_factor', 0):.2f}, "
              f"Return={is_metrics.get('return_pct', 0):.2f}%, "
              f"Trades={is_metrics.get('total_trades', 0)}")

        # Validate on OOS
        print(f"  Starting OOS validation...")
        start_time = time.time()
        oos_metrics, oos_trades_log = self.validate_on_oos(
            strategy_logic,
            best_params,
            window['oos_df']
        )
        oos_time = time.time() - start_time

        print(f"  ✓ OOS validation completed in {oos_time:.2f}s")
        print(f"  ✓ OOS metrics: PF={oos_metrics.get('profit_factor', 0):.2f}, "
              f"Return={oos_metrics.get('return_pct', 0):.2f}%, "
              f"Trades={oos_metrics.get('total_trades', 0)}")

        # Calculate robustness
        robustness = calculate_robustness_score(is_metrics, oos_metrics)

        return {
            'window_id': window['window_id'],
            'is_period': window['is_period'],
            'oos_period': window['oos_period'],
            'best_params': best_params,
            'is_metrics': is_metrics,
            'oos_metrics': oos_metrics,
            'robustness': robustness,
            'oos_trades_log': oos_trades_log
        }

    def run_full_wfa(self,
                    strategy_logic,
                    param_grid: Dict,
                    bucket_ms: int = 2000) -> Dict:
        """
        Run complete walk-forward analysis across all windows.

        Args:
            strategy_logic: Strategy logic function
            param_grid: Parameter grid for optimization
            bucket_ms: Bucket size

        Returns:
            Complete WFA results dictionary
        """
        if self.windows is None:
            self.prepare_windows()

        print(f"\n{'='*60}")
        print(f"WALK-FORWARD ANALYSIS")
        print(f"{'='*60}")
        print(f"Total windows: {len(self.windows)}")
        print(f"IS period: {self.is_days} days")
        print(f"OOS period: {self.oos_days} days")

        window_results = []
        total_start_time = time.time()

        for i, window in enumerate(self.windows):
            print(f"\n[{i+1}/{len(self.windows)}] Processing window...")
            result = self.run_single_window(
                window,
                strategy_logic,
                param_grid,
                bucket_ms=bucket_ms
            )
            window_results.append(result)

        total_time = time.time() - total_start_time
        print(f"\n✓ All windows completed in {total_time:.2f}s")

        # Aggregate results
        oos_results = [w['oos_metrics'] for w in window_results]

        # Calculate aggregate metrics
        consistency = calculate_consistency(oos_results)
        robustness_score = calculate_final_robustness_score(oos_results)
        mvs_check = passes_mvs_aggregate(oos_results)

        # Combine all OOS trades for Monte Carlo
        all_oos_trades = []
        for w in window_results:
            all_oos_trades.extend(w.get('oos_trades_log', []))

        if all_oos_trades:
            mc_results = comprehensive_significance_test(all_oos_trades)
        else:
            mc_results = {'overall_significant': False, 'summary': {'conclusion': 'No trades'}}

        # Summary
        if oos_results:
            avg_oos_return = np.mean([r.get('return_pct', 0) for r in oos_results])
            avg_oos_pf = np.mean([r.get('profit_factor', 0) for r in oos_results])
            avg_oos_sharpe = np.mean([r.get('sharpe_ratio', 0) for r in oos_results])
            avg_oos_max_dd = np.mean([r.get('max_drawdown_pct', 0) for r in oos_results])
            total_oos_trades = sum([r.get('total_trades', 0) for r in oos_results])
        else:
            avg_oos_return = 0.0
            avg_oos_pf = 0.0
            avg_oos_sharpe = 0.0
            avg_oos_max_dd = 0.0
            total_oos_trades = 0
        
        summary = {
            'num_windows': len(window_results),
            'consistency': consistency,
            'robustness_score': robustness_score,
            'mvs_check': mvs_check,
            'monte_carlo': mc_results,
            'avg_oos_return': avg_oos_return,
            'avg_oos_pf': avg_oos_pf,
            'avg_oos_sharpe': avg_oos_sharpe,
            'avg_oos_max_dd': avg_oos_max_dd,
            'total_oos_trades': total_oos_trades
        }

        print(f"\n{'='*60}")
        print("AGGREGATE RESULTS")
        print(f"{'='*60}")
        print(f"Consistency:        {consistency*100:.1f}%")
        print(f"Robustness Score:   {robustness_score:.2f}")
        print(f"Avg OOS Return:     {summary['avg_oos_return']:.2f}%")
        print(f"Avg OOS PF:         {summary['avg_oos_pf']:.2f}")
        print(f"Avg OOS Sharpe:     {summary['avg_oos_sharpe']:.2f}")
        print(f"Avg OOS Max DD:     {summary['avg_oos_max_dd']:.2f}%")
        print(f"Total OOS Trades:   {summary['total_oos_trades']}")
        print(f"\nMVS Check:          {'PASS' if mvs_check['passes'] else 'FAIL'}")
        if not mvs_check['passes']:
            print(f"Failed checks: {', '.join(mvs_check['failed_checks'])}")
        print(f"\nMonte Carlo:        {mc_results['summary']['conclusion']}")
        print(f"{'='*60}")

        # Clear data cache to free memory
        clear_data_cache()

        return {
            'windows': window_results,
            'summary': summary
        }

    def save_results(self, results: Dict, output_path: str):
        """
        Save WFA results to JSON file.

        Args:
            results: WFA results dictionary
            output_path: Path to save JSON
        """
        # Convert numpy types to native Python for JSON serialization
        def convert_types(obj):
            if isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.bool_):
                return bool(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, dict):
                return {k: convert_types(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_types(v) for v in obj]
            return obj

        results_clean = convert_types(results)

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w') as f:
            json.dump(results_clean, f, indent=2)

        print(f"\nResults saved to: {output_path}")
