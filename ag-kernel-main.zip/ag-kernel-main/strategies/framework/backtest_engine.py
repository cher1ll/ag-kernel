#!/usr/bin/env python3
"""
Modular backtesting engine for all strategies.
Separates data loading, tick aggregation, and strategy execution.
"""
import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import pandas as pd
import numpy as np
from collections import deque

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from ag_backtester import Engine, EngineConfig
from ag_backtester.data.optimized_loader import load_data_optimized
from ag_backtester.engine import Order
from ag_backtester.userland import calculate_auto_ticksize


class BacktestEngine:
    """
    Reusable backtesting engine that can run any strategy.
    Handles data loading, aggregation, and execution.
    """

    def __init__(self, data_path: str, initial_cash: float = 100_000.0):
        self.data_path = data_path
        self.initial_cash = initial_cash
        self.trades_df = None
        self.ticks = None
        self.tick_size = None
        self.engine = None
        self.snapshots = []
        self.trades_executed = []

    def load_data(self, start_date: Optional[datetime] = None,
                  end_date: Optional[datetime] = None) -> pd.DataFrame:
        """
        Load aggTrades CSV data, optionally filtering by date range.

        Args:
            start_date: Optional start datetime for filtering
            end_date: Optional end datetime for filtering

        Returns:
            DataFrame with filtered trades
        """
        df = pd.read_csv(self.data_path)

        # Convert timestamp to datetime if filtering needed
        if start_date or end_date:
            df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')

            if start_date:
                df = df[df['datetime'] >= start_date]
            if end_date:
                df = df[df['datetime'] < end_date]

            # Drop datetime column after filtering
            df = df.drop('datetime', axis=1)

        self.trades_df = df
        return df

    def aggregate_ticks(self, bucket_ms: int = 2000) -> List:
        """
        Aggregate trades into OHLCV ticks using optimized batch processing.

        Args:
            bucket_ms: Bucket size in milliseconds

        Returns:
            List of aggregated ticks
        """
        import tempfile
        import os

        if self.trades_df is None:
            raise ValueError("Must call load_data() first")

        # Calculate tick size from first price
        first_price = self.trades_df['price'].iloc[0]
        self.tick_size = calculate_auto_ticksize(first_price, target_ticks=200)

        # Save DataFrame to temporary CSV if needed
        if self.data_path is None:
            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp:
                self.trades_df.to_csv(tmp.name, index=False)
                temp_path = tmp.name
        else:
            temp_path = self.data_path

        # Use optimized loader with Parquet caching and batch processing
        data, metrics = load_data_optimized(
            data_path=temp_path,
            tick_size=self.tick_size,
            bucket_ms=bucket_ms,
            auto_convert=True,  # Enable Parquet caching
            verbose=False  # Reduce output noise
        )
        
        # Convert batch data back to Tick objects for compatibility
        from ag_backtester.data.feeds import Tick
        self.ticks = []
        
        timestamps = data['timestamp']
        price_ticks = data['price_ticks'] 
        qtys = data['qty']
        sides = data['side']
        
        for i in range(len(timestamps)):
            side_str = 'SELL' if sides[i] == 1 else 'BUY'
            tick = Tick(
                ts_ms=int(timestamps[i]),
                price_tick_i64=int(price_ticks[i]),
                qty=float(qtys[i]),
                side=side_str
            )
            self.ticks.append(tick)

        # Clean up temp file if created
        if self.data_path is None:
            os.unlink(temp_path)

        return self.ticks

    def init_engine(self, maker_fee: float = 0.0001,
                    taker_fee: float = 0.0002,
                    slippage_bps: float = 0.0) -> Engine:
        """
        Initialize the backtesting engine.

        Args:
            maker_fee: Maker fee (default 0.01%)
            taker_fee: Taker fee (default 0.02%)
            slippage_bps: Slippage in basis points

        Returns:
            Initialized Engine instance
        """
        if self.tick_size is None:
            raise ValueError("Must call aggregate_ticks() first")

        engine_config = EngineConfig(
            initial_cash=self.initial_cash,
            tick_size=self.tick_size,
            maker_fee=maker_fee,
            taker_fee=taker_fee,
            spread_bps=slippage_bps,
        )

        self.engine = Engine(engine_config)
        return self.engine

    def run_strategy(self, strategy_logic, strategy_params: dict) -> Dict:
        """
        Run a strategy through the ticks.

        Args:
            strategy_logic: Function that generates trading signals
                           Signature: (ticks, engine, params) -> trades_log
            strategy_params: Dictionary of strategy parameters

        Returns:
            Dictionary with results: snapshots, trades, trades_log, metrics
        """
        if self.engine is None:
            raise ValueError("Must call init_engine() first")

        if self.ticks is None:
            raise ValueError("Must call aggregate_ticks() first")

        # Run the strategy logic
        trades_log = strategy_logic(
            ticks=self.ticks,
            engine=self.engine,
            params=strategy_params,
            tick_size=self.tick_size
        )

        # Get results from engine
        self.snapshots = self.engine.get_history()
        self.trades_executed = self.engine.get_trades()

        return {
            'snapshots': self.snapshots,
            'trades': self.trades_executed,
            'trades_log': trades_log,
            'params': strategy_params,
            'tick_size': self.tick_size,
            'num_ticks': len(self.ticks)
        }

    def run_strategy_batch(self, strategy_logic, strategy_params: dict) -> Dict:
        """
        Run a strategy using optimized batch processing.
        
        Args:
            strategy_logic: Function that generates trading signals for batch processing
                           Signature: (data_arrays, engine, params) -> trades_log
            strategy_params: Dictionary of strategy parameters
            
        Returns:
            Dictionary with results: snapshots, trades, trades_log, metrics
        """
        if self.engine is None:
            raise ValueError("Must call init_engine() first")
            
        # Get batch data directly from optimized loader
        temp_path = self.data_path
        if temp_path is None:
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp:
                self.trades_df.to_csv(tmp.name, index=False)
                temp_path = tmp.name
        
        # Load data optimized for batch processing
        data, metrics = load_data_optimized(
            data_path=temp_path,
            tick_size=self.tick_size,
            bucket_ms=strategy_params.get('bucket_ms', 2000),
            auto_convert=True,
            verbose=False
        )
        
        # Run strategy with batch data
        trades_log = strategy_logic(
            data=data,
            engine=self.engine,
            params=strategy_params,
            tick_size=self.tick_size
        )
        
        # Process all ticks at once using step_batch
        self.engine.step_batch(
            data['timestamp'],
            data['price_ticks'], 
            data['qty'],
            data['side']
        )
        
        # Clean up temp file if created
        if self.data_path is None:
            import os
            os.unlink(temp_path)
        
        # Get results from engine
        self.snapshots = self.engine.get_history()
        self.trades_executed = self.engine.get_trades()

        return {
            'snapshots': self.snapshots,
            'trades': self.trades_executed,
            'trades_log': trades_log,
            'params': strategy_params,
            'tick_size': self.tick_size,
            'num_ticks': len(data['timestamp']),
            'load_metrics': metrics
        }

    @classmethod
    def from_dataframe(cls, df: pd.DataFrame, initial_cash: float = 100_000.0):
        """
        Create BacktestEngine from an already-loaded DataFrame.
        Useful for walk-forward analysis with pre-split data.

        Args:
            df: DataFrame with aggTrades data
            initial_cash: Initial cash for backtesting

        Returns:
            BacktestEngine instance
        """
        engine = cls(data_path=None, initial_cash=initial_cash)
        engine.trades_df = df
        return engine


def split_data_by_dates(data_path: str,
                        is_days: int = 30,
                        oos_days: int = 15,
                        step_days: int = 10) -> List[Tuple[pd.DataFrame, pd.DataFrame]]:
    """
    Split data into walk-forward windows (In-Sample, Out-of-Sample pairs).

    Args:
        data_path: Path to aggTrades CSV
        is_days: In-sample period in days
        oos_days: Out-of-sample period in days
        step_days: Step size for sliding window

    Returns:
        List of (is_df, oos_df) tuples
    """
    # Load full dataset
    df = pd.read_csv(data_path)
    df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')

    start_date = df['datetime'].min()
    end_date = df['datetime'].max()
    total_days = (end_date - start_date).days

    print(f"Data range: {start_date.date()} to {end_date.date()} ({total_days} days)")

    windows = []
    offset = 0

    while offset + is_days + oos_days <= total_days:
        is_start = start_date + timedelta(days=offset)
        is_end = is_start + timedelta(days=is_days)
        oos_start = is_end
        oos_end = oos_start + timedelta(days=oos_days)

        # Filter data for this window
        is_df = df[(df['datetime'] >= is_start) & (df['datetime'] < is_end)].copy()
        oos_df = df[(df['datetime'] >= oos_start) & (df['datetime'] < oos_end)].copy()

        # Drop datetime column (no longer needed)
        is_df = is_df.drop('datetime', axis=1)
        oos_df = oos_df.drop('datetime', axis=1)

        windows.append({
            'window_id': len(windows),
            'is_period': f"{is_start.date()} to {is_end.date()}",
            'oos_period': f"{oos_start.date()} to {oos_end.date()}",
            'is_df': is_df,
            'oos_df': oos_df
        })

        offset += step_days

    print(f"Created {len(windows)} walk-forward windows")
    return windows
