#!/usr/bin/env python3
"""
Monte Carlo permutation tests for statistical significance.
Tests whether strategy results are better than random chance.
"""
import numpy as np
import random
from typing import List, Dict


def monte_carlo_permutation(trades_log: List[Dict],
                           n_simulations: int = 1000,
                           seed: int = 42) -> Dict:
    """
    Monte Carlo permutation test on trade sequence.

    Randomly shuffles the order of trades and calculates return distribution.
    Compares actual return to random distribution to determine if results
    are statistically significant or just luck.

    Args:
        trades_log: List of trade dictionaries with 'pnl' and 'pnl_pct' keys
        n_simulations: Number of random permutations (default 1000)
        seed: Random seed for reproducibility

    Returns:
        Dictionary with:
        - real_return: Actual cumulative return %
        - mean_random: Mean of random returns
        - std_random: Std dev of random returns
        - p_value: Probability that random is >= real (lower is better)
        - significant: True if p_value < 0.05
    """
    if not trades_log:
        return {
            'real_return': 0,
            'mean_random': 0,
            'std_random': 0,
            'p_value': 1.0,
            'significant': False,
            'note': 'No trades to analyze'
        }

    random.seed(seed)
    np.random.seed(seed)

    # Calculate real cumulative return
    real_return = sum([t['pnl_pct'] for t in trades_log])

    # Run permutations
    random_returns = []
    for _ in range(n_simulations):
        # Shuffle trade order
        shuffled = trades_log.copy()
        random.shuffle(shuffled)

        # Calculate return with shuffled order
        random_return = sum([t['pnl_pct'] for t in shuffled])
        random_returns.append(random_return)

    # Calculate statistics
    mean_random = np.mean(random_returns)
    std_random = np.std(random_returns)

    # P-value: what % of random simulations are >= real result?
    better_count = sum(1 for r in random_returns if r >= real_return)
    p_value = better_count / n_simulations

    return {
        'real_return': real_return,
        'mean_random': mean_random,
        'std_random': std_random,
        'p_value': p_value,
        'significant': p_value < 0.05,
        'z_score': (real_return - mean_random) / std_random if std_random > 0 else 0,
        'percentile': (1 - p_value) * 100  # Real result is in Xth percentile
    }


def monte_carlo_random_entry(ticks: List,
                             strategy_exit_logic,
                             n_simulations: int = 500,
                             trades_per_sim: int = 50,
                             seed: int = 42) -> Dict:
    """
    Monte Carlo test with random entry timing.

    Enters at random times but uses actual strategy exit logic (SL/TP).
    Tests if strategy's entry timing is better than random.

    Args:
        ticks: List of price ticks
        strategy_exit_logic: Function(entry_price, entry_idx, ticks) -> (exit_idx, pnl_pct)
        n_simulations: Number of random simulations
        trades_per_sim: Number of trades per simulation
        seed: Random seed

    Returns:
        Dictionary with comparison statistics
    """
    random.seed(seed)
    np.random.seed(seed)

    if len(ticks) < trades_per_sim * 10:
        return {
            'note': 'Not enough ticks for random entry test',
            'significant': False
        }

    random_returns = []

    for _ in range(n_simulations):
        sim_returns = []

        # Generate random entry points
        entry_indices = random.sample(range(len(ticks) - 10), trades_per_sim)

        for entry_idx in entry_indices:
            entry_price = ticks[entry_idx].price_tick_i64  # Assuming tick structure

            # Use strategy's exit logic from this random entry
            exit_idx, pnl_pct = strategy_exit_logic(entry_price, entry_idx, ticks)
            sim_returns.append(pnl_pct)

        random_returns.append(sum(sim_returns))

    mean_random = np.mean(random_returns)
    std_random = np.std(random_returns)

    return {
        'mean_random_entry_return': mean_random,
        'std_random_entry_return': std_random,
        'note': 'Compare strategy return to mean_random_entry_return'
    }


def monte_carlo_bootstrap(trades_log: List[Dict],
                         n_simulations: int = 1000,
                         sample_size: int = None,
                         seed: int = 42) -> Dict:
    """
    Bootstrap resampling to estimate confidence intervals.

    Randomly samples trades WITH replacement to build distribution
    of possible returns. Used to estimate 95% confidence interval.

    Args:
        trades_log: List of trade dictionaries
        n_simulations: Number of bootstrap samples
        sample_size: Size of each sample (default: same as original)
        seed: Random seed

    Returns:
        Dictionary with confidence intervals
    """
    if not trades_log:
        return {
            'note': 'No trades to bootstrap',
            'ci_lower': 0,
            'ci_upper': 0
        }

    random.seed(seed)
    np.random.seed(seed)

    if sample_size is None:
        sample_size = len(trades_log)

    bootstrap_returns = []

    for _ in range(n_simulations):
        # Sample with replacement
        sample = random.choices(trades_log, k=sample_size)
        sample_return = sum([t['pnl_pct'] for t in sample])
        bootstrap_returns.append(sample_return)

    # Calculate 95% confidence interval
    ci_lower = np.percentile(bootstrap_returns, 2.5)
    ci_upper = np.percentile(bootstrap_returns, 97.5)
    mean_bootstrap = np.mean(bootstrap_returns)

    return {
        'mean_bootstrap': mean_bootstrap,
        'ci_95_lower': ci_lower,
        'ci_95_upper': ci_upper,
        'contains_zero': ci_lower <= 0 <= ci_upper  # If True, not significantly profitable
    }


def comprehensive_significance_test(trades_log: List[Dict],
                                    n_simulations: int = 1000) -> Dict:
    """
    Run comprehensive battery of statistical tests.

    Args:
        trades_log: List of trade dictionaries
        n_simulations: Number of Monte Carlo simulations

    Returns:
        Dictionary with all test results
    """
    results = {}

    # 1. Permutation test
    perm_test = monte_carlo_permutation(trades_log, n_simulations=n_simulations)
    results['permutation'] = perm_test

    # 2. Bootstrap confidence intervals
    bootstrap = monte_carlo_bootstrap(trades_log, n_simulations=n_simulations)
    results['bootstrap'] = bootstrap

    # 3. Overall significance
    is_significant = (
        perm_test.get('significant', False) and
        not bootstrap.get('contains_zero', True)
    )

    results['overall_significant'] = is_significant
    results['summary'] = {
        'permutation_p_value': perm_test.get('p_value', 1.0),
        'bootstrap_95_ci': f"[{bootstrap.get('ci_95_lower', 0):.2f}%, {bootstrap.get('ci_95_upper', 0):.2f}%]",
        'conclusion': 'Statistically significant' if is_significant else 'Not statistically significant'
    }

    return results
