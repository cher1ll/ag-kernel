#!/usr/bin/env python3
"""
Enhanced metrics for strategy evaluation.
Includes robustness scoring and MVS (Minimum Viable Strategy) filtering.
"""
import numpy as np
from typing import Dict, List


def calculate_basic_metrics(trades_log: List[Dict], snapshots: List) -> Dict:
    """
    Calculate basic trading metrics from trades log.

    Args:
        trades_log: List of trade dictionaries with pnl, pnl_pct, etc.
        snapshots: List of equity snapshots from engine

    Returns:
        Dictionary of metrics
    """
    metrics = {}

    if not trades_log:
        return {
            'total_trades': 0,
            'wins': 0,
            'losses': 0,
            'win_rate': 0,
            'avg_win': 0,
            'avg_loss': 0,
            'profit_factor': 0,
            'max_drawdown_pct': 0,
            'sharpe_ratio': 0,
            'return_pct': 0,
            'avg_trade_size_usd': 0,
            'total_volume_usd': 0,
            'avg_trade_duration_minutes': 0,
            'trades_per_day': 0
        }

    # Win/Loss metrics
    wins = [t for t in trades_log if t['pnl'] > 0]
    losses = [t for t in trades_log if t['pnl'] <= 0]

    total_trades = len(trades_log)
    num_wins = len(wins)
    num_losses = len(losses)

    metrics['total_trades'] = total_trades
    metrics['wins'] = num_wins
    metrics['losses'] = num_losses
    metrics['win_rate'] = (num_wins / total_trades * 100) if total_trades > 0 else 0

    # Average Win/Loss
    if wins:
        metrics['avg_win'] = np.mean([t['pnl'] for t in wins])
        metrics['avg_win_pct'] = np.mean([t['pnl_pct'] for t in wins])
    else:
        metrics['avg_win'] = 0
        metrics['avg_win_pct'] = 0

    if losses:
        metrics['avg_loss'] = np.mean([t['pnl'] for t in losses])
        metrics['avg_loss_pct'] = np.mean([t['pnl_pct'] for t in losses])
    else:
        metrics['avg_loss'] = 0
        metrics['avg_loss_pct'] = 0

    # Profit Factor
    total_wins = sum([t['pnl'] for t in wins]) if wins else 0
    total_losses = abs(sum([t['pnl'] for t in losses])) if losses else 0
    metrics['profit_factor'] = (total_wins / total_losses) if total_losses > 0 else 0

    # Max Drawdown
    if snapshots and len(snapshots) > 0:
        equity_curve = [s.equity for s in snapshots]
        peak = equity_curve[0]
        max_dd = 0

        for equity in equity_curve:
            if equity > peak:
                peak = equity
            dd = (peak - equity) / peak
            if dd > max_dd:
                max_dd = dd

        metrics['max_drawdown_pct'] = max_dd * 100

        # Return - calculate from actual PnL, not equity changes
        total_pnl = sum([t['pnl'] for t in trades_log]) if trades_log else 0
        initial_equity = snapshots[0].equity
        metrics['return_pct'] = (total_pnl / initial_equity) * 100
    else:
        metrics['max_drawdown_pct'] = 0
        metrics['return_pct'] = 0

    # Sharpe Ratio (annualized)
    if snapshots and len(snapshots) > 1:
        returns = []
        for i in range(1, len(snapshots)):
            ret = (snapshots[i].equity / snapshots[i-1].equity - 1)
            returns.append(ret)

        if returns and len(returns) > 1:
            avg_return = np.mean(returns)
            std_return = np.std(returns)
            # Annualized Sharpe (assuming tick frequency)
            sharpe = (avg_return / std_return * np.sqrt(len(returns))) if std_return > 0 else 0
            metrics['sharpe_ratio'] = sharpe
        else:
            metrics['sharpe_ratio'] = 0
    else:
        metrics['sharpe_ratio'] = 0

    # Additional trading metrics for cost analysis
    if trades_log and snapshots:
        # Average trade size in USD (using initial equity as proxy for capital)
        initial_equity = snapshots[0].equity
        trade_sizes = []
        
        for trade in trades_log:
            # Estimate trade size from PnL and percentage
            if trade.get('pnl_pct', 0) != 0:
                estimated_size = abs(trade['pnl'] / (trade['pnl_pct'] / 100))
                trade_sizes.append(estimated_size)
        
        metrics['avg_trade_size_usd'] = np.mean(trade_sizes) if trade_sizes else 0
        metrics['total_volume_usd'] = sum(trade_sizes) if trade_sizes else 0
        
        # Trading frequency analysis
        if len(snapshots) > 1:
            # Calculate time span in days
            first_time = snapshots[0].ts_ms
            last_time = snapshots[-1].ts_ms
            time_span_days = (last_time - first_time) / (1000 * 60 * 60 * 24)
            
            metrics['trades_per_day'] = len(trades_log) / time_span_days if time_span_days > 0 else 0
            
            # Average trade duration (rough estimate)
            if len(trades_log) > 1:
                avg_duration_ms = time_span_days * 24 * 60 * 1000 / len(trades_log)  # ms per trade
                metrics['avg_trade_duration_minutes'] = avg_duration_ms / (1000 * 60)
            else:
                metrics['avg_trade_duration_minutes'] = 0
        else:
            metrics['trades_per_day'] = 0
            metrics['avg_trade_duration_minutes'] = 0
    else:
        metrics['avg_trade_size_usd'] = 0
        metrics['total_volume_usd'] = 0
        metrics['avg_trade_duration_minutes'] = 0
        metrics['trades_per_day'] = 0

    return metrics


def calculate_trading_costs(metrics: Dict, fee_maker: float = 0.0002, fee_taker: float = 0.0004, 
                          slippage_bps: float = 1.0) -> Dict:
    """
    Calculate precise trading costs based on actual metrics.
    
    Args:
        metrics: Trading metrics from calculate_basic_metrics
        fee_maker: Maker fee (default: 0.02% Binance futures)
        fee_taker: Taker fee (default: 0.04% Binance futures)
        slippage_bps: Slippage in basis points (default: 1bp)
    
    Returns:
        Dictionary with cost analysis
    """
    if metrics['total_trades'] == 0:
        return {
            'total_fee_cost': 0,
            'total_slippage_cost': 0,
            'total_trading_cost': 0,
            'cost_per_trade': 0,
            'net_return_pct': metrics['return_pct'],
            'cost_ratio_pct': 0,
            'economically_viable': True
        }
    
    # Assume 60% maker, 40% taker (typical for mean reversion strategies)
    avg_fee = fee_maker * 0.6 + fee_taker * 0.4
    
    # Calculate costs
    avg_trade_size = metrics['avg_trade_size_usd']
    total_trades = metrics['total_trades']
    
    # Fee costs (round trip: entry + exit)
    fee_per_trade = avg_trade_size * avg_fee * 2
    total_fee_cost = fee_per_trade * total_trades
    
    # Slippage costs (round trip)
    slippage_per_trade = avg_trade_size * (slippage_bps / 10000) * 2
    total_slippage_cost = slippage_per_trade * total_trades
    
    # Total costs
    total_trading_cost = total_fee_cost + total_slippage_cost
    cost_per_trade = total_trading_cost / total_trades
    
    # Net return calculation
    gross_return_pct = metrics['return_pct']
    initial_capital = 100000  # Standard assumption
    gross_profit = initial_capital * (gross_return_pct / 100)
    
    net_profit = gross_profit - total_trading_cost
    net_return_pct = (net_profit / initial_capital) * 100
    
    cost_ratio_pct = (total_trading_cost / gross_profit) * 100 if gross_profit > 0 else float('inf')
    
    return {
        'total_fee_cost': total_fee_cost,
        'total_slippage_cost': total_slippage_cost,
        'total_trading_cost': total_trading_cost,
        'cost_per_trade': cost_per_trade,
        'net_return_pct': net_return_pct,
        'cost_ratio_pct': cost_ratio_pct,
        'economically_viable': net_return_pct > 0,
        'fee_per_trade': fee_per_trade,
        'slippage_per_trade': slippage_per_trade
    }


def calculate_robustness_score(is_metrics: Dict, oos_metrics: Dict) -> Dict:
    """
    Calculate robustness score comparing IS vs OOS performance.

    Args:
        is_metrics: In-sample metrics dict
        oos_metrics: Out-of-sample metrics dict

    Returns:
        Dictionary with robustness metrics
    """
    robustness = {}

    # IS vs OOS degradation
    if is_metrics.get('profit_factor', 0) > 0:
        pf_degradation = oos_metrics.get('profit_factor', 0) / is_metrics['profit_factor']
    else:
        pf_degradation = 0

    if is_metrics.get('sharpe_ratio', 0) > 0:
        sharpe_degradation = oos_metrics.get('sharpe_ratio', 0) / is_metrics['sharpe_ratio']
    else:
        sharpe_degradation = 0

    robustness['pf_degradation'] = pf_degradation
    robustness['sharpe_degradation'] = sharpe_degradation

    # Composite robustness score
    # Score = (PF_oos × 0.3) + (Sharpe_oos × 0.2) + ((1 - MaxDD_oos) × 0.2) + (Consistency × 0.3)
    # Note: Consistency is calculated across multiple windows, so we omit it here
    pf_score = min(oos_metrics.get('profit_factor', 0), 2.0) / 2.0  # Normalize to 0-1
    sharpe_score = min(max(oos_metrics.get('sharpe_ratio', 0), 0), 2.0) / 2.0  # Normalize to 0-1
    dd_score = max(1 - (oos_metrics.get('max_drawdown_pct', 0) / 100), 0)  # 1 - DD%

    base_score = (pf_score * 0.4) + (sharpe_score * 0.3) + (dd_score * 0.3)
    robustness['base_score'] = base_score

    return robustness


def calculate_consistency(oos_results: List[Dict]) -> float:
    """
    Calculate consistency score across multiple OOS windows.

    Args:
        oos_results: List of OOS metrics dictionaries

    Returns:
        Consistency score (0-1), representing % of profitable OOS windows
    """
    if not oos_results:
        return 0

    profitable_count = sum(1 for r in oos_results if r.get('return_pct', 0) > 0)
    consistency = profitable_count / len(oos_results)

    return consistency


def calculate_final_robustness_score(oos_results: List[Dict]) -> float:
    """
    Calculate final composite robustness score across all OOS windows.

    Score = (Avg_PF_oos × 0.3) + (Avg_Sharpe_oos × 0.2) +
            ((1 - Avg_MaxDD_oos) × 0.2) + (Consistency × 0.3)

    Args:
        oos_results: List of OOS metrics dictionaries

    Returns:
        Final robustness score (0-1)
    """
    if not oos_results:
        return 0

    # Average metrics across OOS windows
    avg_pf = np.mean([r.get('profit_factor', 0) for r in oos_results])
    avg_sharpe = np.mean([r.get('sharpe_ratio', 0) for r in oos_results])
    avg_dd = np.mean([r.get('max_drawdown_pct', 0) for r in oos_results])

    # Consistency
    consistency = calculate_consistency(oos_results)

    # Normalize components to 0-1
    pf_component = min(avg_pf, 2.0) / 2.0
    sharpe_component = min(max(avg_sharpe, 0), 2.0) / 2.0
    dd_component = max(1 - (avg_dd / 100), 0)

    # Weighted average
    robustness_score = (
        pf_component * 0.3 +
        sharpe_component * 0.2 +
        dd_component * 0.2 +
        consistency * 0.3
    )

    return robustness_score


def passes_mvs_filter(oos_metrics: Dict, trades_per_month: float = 30) -> bool:
    """
    Check if strategy passes Minimum Viable Strategy (MVS) filter.

    Criteria (all must pass):
    - Profit Factor OOS > 1.2
    - Sharpe Ratio OOS > 0.5
    - Max Drawdown OOS < 15%
    - Trades per month > 30 (for statistical significance)

    Args:
        oos_metrics: Out-of-sample metrics dictionary
        trades_per_month: Number of trades per month

    Returns:
        True if strategy passes all MVS criteria
    """
    pf_pass = oos_metrics.get('profit_factor', 0) > 1.2
    sharpe_pass = oos_metrics.get('sharpe_ratio', 0) > 0.5
    dd_pass = oos_metrics.get('max_drawdown_pct', 100) < 15
    trades_pass = trades_per_month >= 30

    return pf_pass and sharpe_pass and dd_pass and trades_pass


def passes_mvs_aggregate(oos_results: List[Dict],
                        consistency_threshold: float = 0.6,
                        robustness_threshold: float = 0.7) -> Dict:
    """
    Check if strategy passes aggregate MVS criteria across all OOS windows.

    Args:
        oos_results: List of OOS metrics dictionaries
        consistency_threshold: Minimum consistency score (default 0.6 = 60%)
        robustness_threshold: Minimum robustness score (default 0.7)

    Returns:
        Dictionary with pass/fail status and reasons
    """
    if not oos_results:
        return {'passes': False, 'reason': 'No OOS results', 'failed_checks': ['No OOS results']}

    # Calculate aggregate metrics
    consistency = calculate_consistency(oos_results)
    robustness = calculate_final_robustness_score(oos_results)

    avg_pf = np.mean([r.get('profit_factor', 0) for r in oos_results])
    avg_sharpe = np.mean([r.get('sharpe_ratio', 0) for r in oos_results])
    avg_dd = np.mean([r.get('max_drawdown_pct', 0) for r in oos_results])

    # Check individual criteria
    checks = {
        'avg_profit_factor > 1.2': avg_pf > 1.2,
        'avg_sharpe_ratio > 0.5': avg_sharpe > 0.5,
        'avg_max_drawdown < 15%': avg_dd < 15,
        f'consistency > {consistency_threshold}': consistency > consistency_threshold,
        f'robustness_score > {robustness_threshold}': robustness > robustness_threshold
    }

    passes = all(checks.values())

    failed_checks = [k for k, v in checks.items() if not v]

    return {
        'passes': passes,
        'consistency': consistency,
        'robustness_score': robustness,
        'avg_profit_factor': avg_pf,
        'avg_sharpe_ratio': avg_sharpe,
        'avg_max_drawdown': avg_dd,
        'failed_checks': failed_checks if not passes else []
    }
