#!/usr/bin/env python3
"""
Base class for all trading strategies.
Provides common interface and utilities.
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Tuple
import numpy as np


class BaseStrategy(ABC):
    """
    Abstract base class for all trading strategies.

    Subclasses must implement:
    - get_name(): Return strategy name
    - get_param_grid(): Return parameter grid for optimization
    - generate_logic(): Return the strategy logic function
    """

    def __init__(self, params: Dict = None):
        """
        Initialize strategy with parameters.

        Args:
            params: Dictionary of strategy parameters
        """
        self.params = params or self.get_default_params()

    @abstractmethod
    def get_name(self) -> str:
        """Return strategy name (e.g., 'H01_Bollinger_Reversion')"""
        pass

    @abstractmethod
    def get_default_params(self) -> Dict:
        """Return default parameter values"""
        pass

    @abstractmethod
    def get_param_grid(self) -> Dict:
        """
        Return parameter grid for optimization.

        Example:
        {
            'bb_period': [10, 20, 30],
            'bb_std': [1.5, 2.0, 2.5],
            'bucket_ms': [2000, 5000, 10000]
        }
        """
        pass

    @abstractmethod
    def generate_logic(self):
        """
        Generate strategy logic function.

        Returns:
            Function with signature: (ticks, engine, params, tick_size) -> trades_log
        """
        pass

    def validate_params(self, params: Dict) -> bool:
        """
        Validate parameter values.

        Args:
            params: Parameters to validate

        Returns:
            True if valid, raises ValueError if invalid
        """
        # Override in subclass for custom validation
        return True

    def get_description(self) -> str:
        """Return human-readable strategy description"""
        return f"{self.get_name()} - No description provided"


class StrategyHelpers:
    """
    Static helper methods for common strategy operations.
    """

    @staticmethod
    def calculate_sma(prices: List[float], period: int) -> float:
        """Calculate Simple Moving Average"""
        if len(prices) < period:
            return None
        return np.mean(prices[-period:])

    @staticmethod
    def calculate_ema(prices: List[float], period: int, previous_ema: float = None) -> float:
        """Calculate Exponential Moving Average"""
        if len(prices) == 0:
            return None

        if previous_ema is None:
            # First EMA is SMA
            if len(prices) < period:
                return None
            return np.mean(prices[-period:])

        # EMA = Price(t) × k + EMA(y) × (1 − k)
        # k = 2 / (N + 1)
        k = 2 / (period + 1)
        return prices[-1] * k + previous_ema * (1 - k)

    @staticmethod
    def calculate_bollinger_bands(prices: List[float],
                                  period: int,
                                  std_dev: float = 2.0) -> Tuple[float, float, float]:
        """
        Calculate Bollinger Bands.

        Returns:
            (middle_band, upper_band, lower_band) or (None, None, None) if not enough data
        """
        if len(prices) < period:
            return None, None, None

        window = prices[-period:]
        middle = np.mean(window)
        std = np.std(window)

        upper = middle + (std * std_dev)
        lower = middle - (std * std_dev)

        return middle, upper, lower

    @staticmethod
    def calculate_rsi(prices: List[float], period: int = 14) -> float:
        """
        Calculate Relative Strength Index.

        Returns:
            RSI value (0-100) or None if not enough data
        """
        if len(prices) < period + 1:
            return None

        # Calculate price changes
        deltas = np.diff(prices[-period-1:])

        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)

        avg_gain = np.mean(gains)
        avg_loss = np.mean(losses)

        if avg_loss == 0:
            return 100

        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))

        return rsi

    @staticmethod
    def calculate_atr(high_prices: List[float],
                     low_prices: List[float],
                     close_prices: List[float],
                     period: int = 14) -> float:
        """
        Calculate Average True Range.

        Note: For tick data without H/L, can use close prices as approximation.

        Returns:
            ATR value or None if not enough data
        """
        if len(close_prices) < period + 1:
            return None

        true_ranges = []

        for i in range(len(close_prices) - period, len(close_prices)):
            if i == 0:
                tr = high_prices[i] - low_prices[i]
            else:
                tr = max(
                    high_prices[i] - low_prices[i],
                    abs(high_prices[i] - close_prices[i-1]),
                    abs(low_prices[i] - close_prices[i-1])
                )
            true_ranges.append(tr)

        return np.mean(true_ranges)

    @staticmethod
    def calculate_atr_simple(prices: List[float], period: int = 14) -> float:
        """
        Simplified ATR using only close prices (price changes).

        Returns:
            Average of absolute price changes
        """
        if len(prices) < period + 1:
            return None

        changes = np.abs(np.diff(prices[-period-1:]))
        return np.mean(changes)

    @staticmethod
    def calculate_adx(high_prices: List[float],
                     low_prices: List[float],
                     close_prices: List[float],
                     period: int = 14) -> float:
        """
        Calculate Average Directional Index (trend strength).

        Returns:
            ADX value (0-100) or None if not enough data
            Higher values = stronger trend
        """
        if len(close_prices) < period + 1:
            return None

        # Simplified ADX calculation
        # For full implementation, would need +DI, -DI, etc.
        # This is a placeholder - implement full logic if needed

        # For now, return simplified trend strength based on price momentum
        changes = np.diff(close_prices[-period-1:])
        avg_abs_change = np.mean(np.abs(changes))
        avg_change = np.abs(np.mean(changes))

        if avg_abs_change == 0:
            return 0

        # Ratio of directional movement to total movement
        directional_ratio = avg_change / avg_abs_change
        adx = directional_ratio * 100

        return min(adx, 100)

    @staticmethod
    def calculate_zscore(prices: List[float], period: int = 50) -> float:
        """
        Calculate Z-Score of current price relative to recent mean.

        Returns:
            Z-score (standard deviations from mean) or None
        """
        if len(prices) < period:
            return None

        window = prices[-period:]
        mean = np.mean(window)
        std = np.std(window)

        if std == 0:
            return 0

        current_price = prices[-1]
        zscore = (current_price - mean) / std

        return zscore
