"""
Trading Strategy Framework for Robust Backtesting

Modules:
- backtest_engine: Modular backtesting engine
- base_strategy: Base class for all strategies
- metrics: Robustness metrics and MVS filtering
- monte_carlo: Statistical significance testing
- walk_forward: Walk-forward analysis

Usage:
    from framework import WalkForwardAnalyzer, BaseStrategy
    from framework.metrics import calculate_basic_metrics
"""

from .backtest_engine import BacktestEngine, split_data_by_dates
from .base_strategy import BaseStrategy, StrategyHelpers
from .batch_strategy import BatchStrategy, BatchIndicators
from .metrics import (
    calculate_basic_metrics,
    calculate_robustness_score,
    calculate_consistency,
    calculate_final_robustness_score,
    passes_mvs_filter,
    passes_mvs_aggregate
)
from .monte_carlo import (
    monte_carlo_permutation,
    monte_carlo_bootstrap,
    comprehensive_significance_test
)
from .walk_forward import WalkForwardAnalyzer, clear_data_cache

__all__ = [
    'BacktestEngine',
    'split_data_by_dates',
    'BaseStrategy',
    'StrategyHelpers',
    'BatchStrategy',
    'BatchIndicators',
    'calculate_basic_metrics',
    'calculate_robustness_score',
    'calculate_consistency',
    'calculate_final_robustness_score',
    'passes_mvs_filter',
    'passes_mvs_aggregate',
    'monte_carlo_permutation',
    'monte_carlo_bootstrap',
    'comprehensive_significance_test',
    'WalkForwardAnalyzer',
    'clear_data_cache'
]
