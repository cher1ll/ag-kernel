#!/usr/bin/env python3
"""Quick test of H01 with fixed signal generation"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).parent.parent / "python"))

from hypotheses.batch_strategies import H01BollingerBatch
from framework.backtest_engine import BacktestEngine
from framework.metrics import calculate_basic_metrics

def main():
    print("Testing H01 with edge detection fix...")

    strategy = H01BollingerBatch()
    data_path = 'examples/data/btcusdt_vision_30d.csv'

    # Use first 7 days only
    import pandas as pd
    from datetime import datetime, timedelta

    # Load with date filtering
    engine_bt = BacktestEngine(data_path)
    df = engine_bt.load_data()

    # Get first 7 days
    df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
    start = df['datetime'].min()
    end = start + timedelta(days=7)
    df = df[df['datetime'] < end]

    print(f"Using {len(df)} rows from {start.date()} to {end.date()}")

    # Save filtered data back
    df = df.drop('datetime', axis=1)
    engine_bt.trades_df = df

    # Aggregate ticks
    print(f"Aggregating ticks...")
    engine_bt.aggregate_ticks(bucket_ms=5000)
    print(f"  Generated {len(engine_bt.ticks)} ticks")

    # Init engine
    engine_bt.init_engine()

    # Test ONE parameter combination with LARGER bucket_ms
    params = {
        'bb_period': 20,
        'bb_std': 2.0,
        'risk_percent': 0.01,
        'reward_ratio': 1.5,
        'position_size': 0.05,
        'bucket_ms': 300000  # 5 minutes (300 seconds)
    }

    print(f"\nTesting params: {params}")
    result = engine_bt.run_strategy_batch(
        strategy.generate_logic(),
        params
    )

    # Calculate metrics
    metrics = calculate_basic_metrics(result['trades_log'], result['snapshots'])

    print(f"\n{'='*60}")
    print("RESULTS")
    print(f"{'='*60}")
    print(f"Snapshots: {len(result['snapshots'])}")
    if result['snapshots']:
        print(f"  Initial equity: ${result['snapshots'][0].equity:,.2f}")
        print(f"  Final equity: ${result['snapshots'][-1].equity:,.2f}")
    print(f"Trades (log): {metrics['total_trades']}")
    print(f"Profit Factor: {metrics['profit_factor']:.2f}")
    print(f"Return: {metrics['return_pct']:.2f}%")
    print(f"Sharpe: {metrics['sharpe_ratio']:.2f}")

    # Check if reasonable
    if metrics['total_trades'] < 100:
        print(f"\n✅ Good: Reasonable number of trades (<100)")
    else:
        print(f"\n⚠️  Warning: Still many trades (>{metrics['total_trades']})")

    print(f"{'='*60}")

if __name__ == '__main__':
    main()
